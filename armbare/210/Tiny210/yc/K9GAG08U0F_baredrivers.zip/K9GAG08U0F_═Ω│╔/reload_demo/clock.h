void clock_init(void);
