#define	NFCONF  (*(volatile unsigned int *)0xB0E00000) 
#define	NFCONT  (*(volatile unsigned int *)0xB0E00004) 	
#define	NFCMMD  (*(volatile unsigned char *)0xB0E00008) 
#define	NFADDR  (*(volatile unsigned char *)0xB0E0000C)
#define	NFDATA  (*(volatile unsigned char *)0xB0E00010)
#define	NFSTAT  (*(volatile unsigned int *)0xB0E00028)

#define	MP0_3CON  (*(volatile unsigned int *)0xE0200320)
#define   MP0_1CON  (*(volatile unsigned int *)0xE02002E0)
		
#define PAGE_SIZE	2048
#define NAND_SECTOR_SIZE_LP    2048

#define CFG_PHY_UBOOT_BASE	0x36000000

#define NAND_DISABLE_CE()	(NFCONT |= (1 << 1))
#define NAND_ENABLE_CE()	(NFCONT &= ~(1 << 1))
#define NF_TRANSRnB()		do { while(!(NFSTAT & (1 << 0))); } while(0)

#define NAND_CMD_RESET		0xff
#define NAND_CMD_READID		0x90
#define NAND_CMD_READ0		0
#define NAND_CMD_READSTART	0x30

void wait_idle(void)
{
	int i;
	while(!(NFSTAT&(1<<0)));
	for(i=0; i<10; i++);
}

void nand_select_chip(void)
{
	int i;
	NFCONT &= ~(1<<1);
	for(i=0; i<10; i++);
}

void nand_deselect_chip(void)
{
	NFCONT |= (1<<1);
}

void write_cmd(int cmd)
{
	NFCMMD = cmd;
}

void write_addr(unsigned int addr)
{
	int i;
	NFADDR = (addr>>0) & 0xFF;
	wait_idle();
	NFADDR = (addr>>8) & 0x3F;
	wait_idle();
	NFADDR = (addr>>14) & 0xFF;
	wait_idle();
	NFADDR = (addr>>22) & 0xFF;
	wait_idle();
	NFADDR = (addr>>30) & 0xF;
	wait_idle();
}

unsigned char read_data(void)
{
	return NFDATA;
}

static void nand_reset(void)
{
    nand_select_chip();
    write_cmd(0xff);  // ��λ����
    wait_idle();
    nand_deselect_chip();
}

void nand_init(void)
{
	/* 
	 * ����ʱ�����(HCLK_PSYS = 667MHz/5 = 133MHz)
	 * TACLS[15:12]: TACLS  = 1 	1/133Mhz  = 7.5ns
	 * TWRPH0[11:8]: TWRPH0 = 1 	7.5ns * 2 = 15ns
	 * TWRPH1 [7:4]: TWRPH1 = 1	7.5ns * 2 = 15ns
	 * AddrCycle[1]: 1 = ָ����ַ����Ϊ5�Σ�����Ǻ�2440������
	 */
	NFCONF |= 1<<12 | 1<<8 | 1<<4|1<<3|0<<2;
	NFCONF |= 1<<1;

	/*
	 * ʹ��NAND������
	 * �ر�Ƭѡ�ź�
	 */
	NFCONT |= (1<<0)|(1<<1); 

	/*
	 * ������Ӧ�ܽ�����Nand Flash������
	 */
	MP0_3CON = 0x22222222;

	/* ��λNAND Flash */
	nand_reset();

	return;
}

/* ��ID */
void nand_read_id(char id[])
{
	int i;
	
	nand_select_chip();
	write_cmd(0x90);
	write_addr(0x00);

	for (i = 0; i < 5; i++)
		id[i] = read_data();

	nand_deselect_chip();
}

/* ��һҳ�ĺ��� */
void nand_read(unsigned char *buf, unsigned long start_addr, int size)
{
	int i, j;

	/* ѡ��оƬ */
	nand_select_chip();

	for(i=start_addr; i < (start_addr + size);) {
		/* ����READ0���� */
		write_cmd(0);

		/* Write Address */
		write_addr(i);
		write_cmd(0x30);		
		wait_idle();

		for(j=0; j < NAND_SECTOR_SIZE_LP; j++, i++) {
			*buf = read_data();
			buf++;
		}
	}

	/* ȡ��Ƭѡ�ź� */
	nand_deselect_chip();
}

void nand_write(int sdram_addr, int nand_addr, int size)
{

}

static int nandll_read_page (unsigned char *buf, unsigned long addr, int large_block)
{
	int i;
	int page_size = 512;

	if (large_block==2)
	    page_size = 8192;

	NAND_ENABLE_CE();  // ѡ��nand

	NFCMMD = NAND_CMD_READ0;

	/* Write Address */
	NFADDR = 0;

	if (large_block)
	    NFADDR = 0;

	NFADDR = (addr) & 0xff;
	NFADDR = (addr >> 8) & 0xff;
	NFADDR = (addr >> 16) & 0xff;

	if (large_block)
	    NFCMMD = NAND_CMD_READSTART;

	NF_TRANSRnB();

	for(i=0; i < page_size; i++) {
	    *buf++ = NFDATA;
	}

	NAND_DISABLE_CE();

	return 0;
}

static int nandll_read_blocks (unsigned long dst_addr, unsigned long size, int large_block)
{
	int i;
	unsigned int page_shift = 9;
	unsigned char *buf = (unsigned char *)dst_addr;  // Ŀ�ĵ�ַ����Ҫ�������ڴ��е��ĸ���ַ?

	if(large_block==2)
	{
		page_shift = 13;
	}

	if(large_block == 2)
	{
		/* Read pages */
		for (i = 0; i < 4; i++, buf+=4096){
			nandll_read_page(buf, i, large_block);
		}

		/* Read pages */
		for (i = 4; i < (0x3c000>>page_shift); i++, buf+=8192) {
			nandll_read_page(buf, i, large_block);
		}
	}

	return 0;
}

int copy_uboot_to_ram(void)
{
	int i;
	int large_block = 0;
	unsigned char id;

	NAND_ENABLE_CE();  // Enable chip select ---- NFCONT_REG &= ~(1 << 1)
	NFCMMD =NAND_CMD_RESET;  // ����λ����0xff
	NF_TRANSRnB();  // �ж�nand�Ƿ�æ

	NFCMMD = NAND_CMD_READID;  // ����ID����
	NFADDR =  0x00;  // ���ݶ�ID��ʱ���֪: �ȷ���ID��������ŷ�0x00��ַ,Ȼ��Ϳ�ʼ��ID��

	NF_TRANSRnB();  // �ж�nand�Ƿ�æ

	/* wait for a while */
	for (i=0; i<200; i++);

	int factory = NFDATA;  // Maker Code = ECh
	id = NFDATA;  // Device Code = D5H

	int cellinfo=NFDATA;  // 94h
	int tmp= NFDATA;  // 76h

	int childType=cellinfo; //Page size

	if(id == 0xd5 && childType==0x94 )//K9GAG08U0F
	{
		large_block = 2;
	}

	return nandll_read_blocks(CFG_PHY_UBOOT_BASE, 0x3c000, large_block);
}
