void led_init(void);
void led_water(void);

