void delay(void);
void putchar_hex(char c);
int putchar(int c);
int puts(const char * s);
void putint_hex(int a);
char * itoa(int a, char * buf);
int wy_printf(const char * format, ...);
