/********************************************************************************
* 
*	Project Name : S3C6400 Validation
*
*	Copyright 2006 by Samsung Electronics, Inc.
*	All rights reserved.
*
*	Project Description :
*		This software is only for verifying functions of the S3C6410.
*		Anybody can use this software without our permission.
*  
*--------------------------------------------------------------------------------
* 
*	File Name : PCM_test.c
*  
*	File Description : Test for PCM I/F 
*
*	Author	: Sung-Hyun, Na
*	Dept. : AP Development Team
*	Created Date : 2008/03/03
*	Version : 0.1 
* 
*	History
*	- Version 0.1 (2007/03/16)
*	  -> Available with AK2440 PCM Codec.
*  
********************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "def.h"
#include "option.h"
#include "library.h"
#include "sfr6410.h"
#include "system.h"
#include "gpio.h"
#include "intc.h"
#include "dma.h"

#include "ac97.h"
#include "pcm.h"
#include "i2s.h"
#include "audio.h"

void PCM_Test(void);
void PCM_Configuration(AUDIO_PORT);
static void PCM_DataInPolling(AUDIO_PORT);
static void PCM_DataOutPolling(AUDIO_PORT);

static void PCM_DataInDMA(AUDIO_PORT);
static void PCM_DataOutDMA(AUDIO_PORT);

static void PCM_DataIn2Port(AUDIO_PORT ePort);
static void PCM_DataOut2Port(AUDIO_PORT ePort);


static void PCM_ByPassPolling(AUDIO_PORT ePort);
static void PCM_BypassDMA(AUDIO_PORT ePort);




void PCMConf_SetPCMCLKSource(AUDIO_PORT);
void PCMConf_SetPCMSCLK(AUDIO_PORT);
void PCMConf_SetPCMSync(AUDIO_PORT);
void PCMConf_MSBPosition(AUDIO_PORT);
void PCMConf_Interrupt(AUDIO_PORT);
void PCMConf_DMAUnit(AUDIO_PORT);
void PCMConf_DMAUnitChanne(AUDIO_PORT);
void PCMConf_Addr(AUDIO_PORT);
void PCMConf_Codec(AUDIO_PORT ePort);

AUDIO_PORT PCM_SelectPort(void);


static void PCMInOutInt(AUDIO_PORT);

static void PCMInAC97Out(AUDIO_PORT);
static void AC97InPCMOut(AUDIO_PORT);

static void PCM_InterruptTest(AUDIO_PORT ePort);

volatile u32 g_isrTest = 0;

void PCM_Test(void)
{	
	const PCMtestFuncMenu pcm_function[]=
	{
		0,         					"Exit\n",
		PCM_Configuration,		"Configuration\n",
				
		PCM_DataInPolling,			"Polling Mode Data In",
		PCM_DataOutPolling,		"Polling Mode Dta Out\n",
		
		PCM_DataInDMA,			"DMA Mode Test for Data In(Recoding)",
		PCM_DataOutDMA,			"DMA Mode Test for Data Out(Playing)\n",

		PCM_DataIn2Port,			"Dual Port Data In",
		PCM_DataOut2Port,		"Dual Port Data Out\n",	

		PCM_ByPassPolling,		"Bypass Polling Mode",
		PCM_BypassDMA,			"Bypass DMA Mode\n",		

		PCMInOutInt,				"PCM In/Out Interrupt Test\n",

		//PCMInAC97Out,			"PCM IN/AC97 OUT Test",
		//AC97InPCMOut,			"AC97 IN/PCM OUT Test\n",

		PCM_InterruptTest,			"Interrupt Test\n",
		0,					0
	};
	u32 uCountFunc = 0;	
	AUDIO_PORT ePCMPort = AUDIO_PORT0;
	PCM_Infor* pInfor;
	//Test SFR
	//TestSFR();
	
	PCM_Init(AUDIO_PORT0);
	PCM_Init(AUDIO_PORT1);	
	
	while (1)
	{
		u32 i, nSel;		
		UART_Printf("\n");
		UART_Printf("================================================================================\n");	
		UART_Printf("PCM Configuration\n");
		for (uCountFunc = 0; uCountFunc < AUDIO_NUM; uCountFunc++)
		{	
			pInfor = PCM_GetInfor((AUDIO_PORT) uCountFunc);
			PCM_InitPort((AUDIO_PORT) uCountFunc);
			UART_Printf("\n");
			UART_Printf("Port : %d\t\t",uCountFunc);			
			UART_Printf("Audio Codec : ");
			if (pInfor->m_uCodec == AK2430 )			UART_Printf("AK2430\n");
			else if (pInfor->m_uCodec == WM9713 )	UART_Printf("WM9713\n");
			else if (pInfor->m_uCodec == WM8753 )	UART_Printf("WM8753\n");
			else if (pInfor->m_uCodec == STAC9767 )	UART_Printf("STAC9767\n");
			else if (pInfor->m_uCodec == WM8580 )	UART_Printf("WM8580\n");
			else if (pInfor->m_uCodec == WM8990 )	UART_Printf("WM8990\n");			
			UART_Printf("TX Interface Data Format : ");
			if ( pInfor->m_eTXMSBPosition==  AFTER_PCMSYNC_HIGH)			UART_Printf("After SYNC High Format \n");
			else if ( pInfor->m_eTXMSBPosition==  DURING_PCMSYNC_HIGH)	UART_Printf("During SYNC High Format \n");		
			
			UART_Printf("RX Interface Data Format : ");
			if ( pInfor->m_eRXMSBPosition==  AFTER_PCMSYNC_HIGH)			UART_Printf("After SYNC High Format \n");
			else if ( pInfor->m_eRXMSBPosition==  DURING_PCMSYNC_HIGH)	UART_Printf("During SYNC High Format \n");	
			
			UART_Printf("Clock Source : ");
			if ( pInfor->m_ePCMClkSrc==  PCM_MOUT_EPLL)					UART_Printf("EPLL Out\n");
			else if ( pInfor->m_ePCMClkSrc==  PCM_PCLK)					UART_Printf("PCLK\n");
			else if ( pInfor->m_ePCMClkSrc==  PCM_MOUT_EPLL)				UART_Printf("MPLL Out\n");
			else if ( pInfor->m_ePCMClkSrc==  PCM_FIN_EPLL)				UART_Printf("System External CLK\n");
			else if ( pInfor->m_ePCMClkSrc==  PCM_PCMCDCLK)				UART_Printf("PCM External CLK\n");			
			UART_Printf("PCMSCLK Frequency : %3.1fKHz\t",(double)(pInfor->m_uPCMSClk)/1000);			
			UART_Printf("PCMSYNC Frequency : %3.1fKHz\n",(double)(pInfor->m_uSamplingRate)/1000);			
		}		
		UART_Printf("================================================================================\n");	
		UART_Printf("Current PCM Port : %d\n",ePCMPort);
		
		for (i=0; (int)(pcm_function[i].desc)!=0; i++)
		{
			UART_Printf("%2d: %s\n", i,pcm_function[i].desc);
		}
		UART_Printf("%2d: PCM Port Selection\n",i++);				
		UART_Printf("\nSelect the function to test : ");
		nSel = UART_GetIntNum();
		UART_Printf("\n");
		if (nSel == 0)
			break;
		if (nSel>0 && nSel<(sizeof(pcm_function)/8-1))
			 (pcm_function[nSel].func)(ePCMPort);
		else if ( nSel == (sizeof(pcm_function)/8-1) )
			ePCMPort = PCM_SelectPort();
	}
}

AUDIO_PORT PCM_SelectPort(void)
{
	u8 selTemp;	
	UART_Printf("Select PCM PORT\n");
	UART_Printf("0. PORT0[D]			1. PORT1\n");
	selTemp = UART_GetIntNum();	
	if (selTemp == 1)		return AUDIO_PORT1;
	else					return AUDIO_PORT0;	
}

void PCM_Configuration(AUDIO_PORT ePort)
{
	const PCMtestFuncMenu PCM_Configuration_function[]=
	{
		0,         						"Exit\n",
		//DMA Controller for PCM
		PCMConf_Codec,				"Select Audio Codec",
		PCMConf_Addr,					"Set the Memory address",
		PCMConf_DMAUnit,			"Select DMA",
		PCMConf_DMAUnitChanne,	"Select DMA Channel\n",
		PCMConf_SetPCMSync,		"PCMSYNC Frequency(Sampling rate)",
		PCMConf_SetPCMSCLK,		"PCMSCLK Frequency",		
		PCMConf_SetPCMCLKSource,	"PCMCLK Source Selecte\n",		
		PCMConf_MSBPosition,			"MSB Position",
		PCMConf_Interrupt,			"Interrupt Condition",
		
		0,							 0
	};
	while (1)
	{
		u32 i, nSel;
		UART_Printf("\n");
		for (i=0; (int)(PCM_Configuration_function[i].desc)!=0; i++)
		{
			UART_Printf("%2d: %s\n", i,PCM_Configuration_function[i].desc);
		}
		UART_Printf("\nSelect the function : ");
		nSel = UART_GetIntNum();
		UART_Printf("\n");
		if (nSel == 0)
		{
			PCMCTL_PutData(ePort);
			break;
		}
		if (nSel>0 && nSel<(sizeof(PCM_Configuration_function)/8-1))
			 (PCM_Configuration_function[nSel].func)(ePort);
	}
}


//////////
// Function Name : PCM_DataInPolling
// Function Description : Test PCM RX Channel Only CPU Transfer
// Input : 	ePort - Controller Number
// Output :	None 
// Version : v0.2
static void PCM_DataInPolling(AUDIO_PORT ePort)
{
	PCM_Infor *pInfor = PCM_GetInfor(ePort);
	u16* uRecBuf = pInfor->m_pRecAddr;
	s32 uPcmDataSize = (s32) pInfor->m_uRecSize;
	u32 uFIFOTriggerLevel = 0x8;
	u32 uSclkDiv, uSyncDiv;
	UART_Printf("Supply Sound to PCM CODEC via Line In Connector.\n");
   	UART_Printf("Press any key to record.\n");
    	UART_Getc();	
	PCM_InitCodecDataIn(ePort, pInfor->m_uCodec, pInfor->m_eLine);
	PCM_GetClkValAndClkDir(ePort, &uSclkDiv, &uSyncDiv);
	PCMCLKCTL_SetDivideLogic(ePort, uSclkDiv, uSyncDiv);
	PCMCTL_EnableFIFO(ePort, PCM_RX, ENABLE);
	PCMCTL_EnablePCMIF(ePort, ENABLE);	
	UART_Printf("Now Recoding....\n");
	while( uPcmDataSize > 0 )
	{
		do 
		{			
		} while ( PCMFIFO_GetCnt(ePort, PCM_RX) < uFIFOTriggerLevel);	// Rx FIFO Level check
		while(1)
		{
			*uRecBuf++ = PCMFIFO_GetData(ePort, PCM_RX);
			uPcmDataSize -= 2;
			if (PCMFIFO_GetState(ePort, PCM_RX) & (PCM_FIFOEmpty) )
				break;
		}
	}
	PCMCTL_EnablePCMIF(ePort, DISABLE);
	PCMCTL_EnableFIFO(ePort, PCM_RX, DISABLE);
	UART_Printf("Rec Done!\n");
}


//////////
// Function Name : PCM_DataOutPolling
// Function Description : Test PCM TX Channel Only CPU Transfer
// Input : 	ePort - Controller Number
// Output :	None 
// Version : v0.2
static void PCM_DataOutPolling(AUDIO_PORT ePort)
{
	PCM_Infor *pInfor = PCM_GetInfor(ePort);
	u16* uRecBuf = pInfor->m_pPCMTxAddr;
	s32 uPcmDataSize = pInfor->m_uPlaySize;
	u32 uFIFOTriggerLevel = 0x8;
	u32 uSclkDiv, uSyncDiv;
	UART_Printf("\nListen to Sound via Speak Out Connector.\n");
	UART_Printf("Press any key to play.\n");
    	UART_Getc();	
	PCM_InitCodecDataOut(ePort, pInfor->m_uCodec, pInfor->m_eLine);
	PCM_GetClkValAndClkDir(ePort, &uSclkDiv, &uSyncDiv);
	PCMCLKCTL_SetDivideLogic(ePort, uSclkDiv, uSyncDiv);
	PCMCTL_EnableFIFO(ePort, PCM_TX, ENABLE);
	PCMCTL_EnablePCMIF(ePort, ENABLE);	
	UART_Printf("Now Playing....\n");
	while( uPcmDataSize > 0 )
	{
		while(1)
		{
			PCMFIFO_PutData(ePort, PCM_TX, *uRecBuf++);
			uPcmDataSize -= 2;
			if (PCMFIFO_GetState(ePort, PCM_TX) & (PCM_FIFOFull) )
				break;
		}		
		do 
		{			
		} while ( PCMFIFO_GetCnt(ePort, PCM_TX) > uFIFOTriggerLevel);	// Rx FIFO Level check
	}
	PCMCTL_EnablePCMIF(ePort, DISABLE);
	PCMCTL_EnableFIFO(ePort, PCM_TX, DISABLE);
	UART_Printf("Play Done!\n");
}

//////////
// Function Name : PCM_DataInDMA
// Function Description : Test PCM RX Channel with DMA Request
// Input : 	ePort - Controller Number
// Output :	None 
// Version : v0.2
static void PCM_DataInDMA(AUDIO_PORT ePort)
{
	PCM_Infor *pInfor = PCM_GetInfor(ePort);
	u32 uSclkDiv, uSyncDiv;
	UART_Printf("Supply Sound to PCM CODEC via Line In Connector.\n");
    	UART_Printf("Press any key to record.\n");    
    	UART_Getc();		
   	UART_Printf("Recording...\n");
	PCM_InitCodecDataIn(ePort, pInfor->m_uCodec, pInfor->m_eLine);
	PCM_InitDMA(ePort, PCM_RX);
	if ( ePort == AUDIO_PORT0)
		INTC_SetVectAddr(pInfor->m_uNumDma, Isr_PCMPORT0_PCMIn_DMADone);
	else if ( ePort == AUDIO_PORT1)
		INTC_SetVectAddr(pInfor->m_uNumDma, Isr_PCMPORT1_PCMIn_DMADone);	
	PCM_GetClkValAndClkDir(ePort, &uSclkDiv, &uSyncDiv);
	PCMCLKCTL_SetDivideLogic(ePort, uSclkDiv, uSyncDiv);
	PCMCTL_SetDipstick(ePort, PCM_RX, pInfor->m_uRXFIFODipstick);
	PCMCTL_EnableFIFO(ePort, PCM_RX, ENABLE);
	PCMCTL_EnableDMA(ePort, PCM_RX, ENABLE);
	PCMCTL_EnablePCMIF(ePort, ENABLE);	
	pInfor->m_usAC97PCMInDone = FALSE;
	while(pInfor->m_usAC97PCMInDone  == FALSE)
    	{
        	UART_Printf(".");
        	Delay(3000);
    	}
    	PCM_DMAStop(ePort, PCM_RX);
	PCMCTL_EnablePCMIF(ePort, DISABLE);	
	PCMCLKCTL_ActiveDivideLogic(ePort, DISABLE);		
	PCMCTL_EnableFIFO(ePort, PCM_RX, DISABLE);
	PCMCTL_EnableDMA(ePort, PCM_RX, DISABLE); 	
  	UART_Printf("\nEnd of Record!\n");
  	Delay(3000); 
}

//////////
// Function Name : PCM_DataOutDMA
// Function Description : Test PCM TX Channel with DMA Request
// Input : 	ePort - Controller Number
// Output :	None 
// Version : v0.2
static void PCM_DataOutDMA(AUDIO_PORT ePort)
{
	u8 uChar;
	PCM_Infor *pInfor = PCM_GetInfor(ePort);
	UART_Printf("\nListen to Sound via Speak Out Connector.\n");
	UART_Printf("Press any key to play.\n");
    	UART_Getc();  			
	PCM_InitCodecDataOut(ePort, pInfor->m_uCodec, pInfor->m_eLine);
	PCM_PCMOutDMAStart(ePort);
	UART_Printf("\nIf you want to exit, Press the 'x' key.\n");
	UART_Printf("DMA Disable : P		Enable : O\n");
	UART_Printf("FIFO Disable : L	Enable : K\n");
	UART_Printf("CLK Disable : I		Enable : U\n");
	while(1)
	{
		uChar = UART_Getc();
		if( (uChar == 'x') | (uChar == 'X')) 
			break;
		else if ( (uChar == 'o') | (uChar == 'O'))
			PCMCTL_EnableDMA(ePort, PCM_TX, true);
		else if ( (uChar == 'p') | (uChar == 'P'))
			PCMCTL_EnableDMA(ePort, PCM_TX, false);
		else if ( (uChar == 'l') | (uChar == 'L'))
			PCMCTL_EnableFIFO(ePort, PCM_TX, false);
		else if ( (uChar == 'k') | (uChar == 'K'))
			PCMCTL_EnableFIFO(ePort, PCM_TX, true);
		else if ( (uChar == 'i') | (uChar == 'I'))
			PCMCLKCTL_ActiveDivideLogic(ePort, false);
		else if ( (uChar == 'u') | (uChar == 'U'))
			PCMCLKCTL_ActiveDivideLogic(ePort, true);
	} 	
	PCM_PCMOutDMAStop(ePort);
	UART_Printf("\nEnd of Play!\n");	
	Delay(3000);
}

//////////
// Function Name : PCM_ByPassPolling
// Function Description : Test Full Duplex (PCM RX and PCM TX) CPU Transfer 
//
// 				RX FIFO ---- CPU Copys Data ----> TX FIFO
//
// Input : 	ePort - Controller Number
// Output :	None 
// Version : v0.2
static void PCM_ByPassPolling(AUDIO_PORT ePort)
{
	PCM_Infor *pInfor = PCM_GetInfor(ePort);
	u16* uRecBuf = pInfor->m_pRecAddr;
	s32 uPcmDataSize = (s32) pInfor->m_uRecSize;
	u32 uFIFOTriggerLevel = 0x8;
	u32 uSclkDiv, uSyncDiv;

}

static void PCM_BypassDMA(AUDIO_PORT ePort)
{
	u8 uChar;
	PCM_Infor *pInfor = PCM_GetInfor(ePort);
	u32 uSclkDiv, uSyncDiv;
	UART_Printf("Supply Sound to PCM CODEC via Line In Connector.\n");
	UART_Printf("\nListen to Sound via Speak Out Connector.\n");
    	UART_Printf("Press any key to record.\n");    
    	UART_Getc();
	if ( ePort == AUDIO_PORT0)
		INTC_SetVectAddr(pInfor->m_uNumDma, Isr_PCM0_Bypass);
	else if ( ePort == AUDIO_PORT1)
		INTC_SetVectAddr(pInfor->m_uNumDma, Isr_PCM1_Bypass);	
	PCM_InitCodecFullDuplex(ePort, pInfor->m_uCodec, pInfor->m_eLine);
	PCM_GetClkValAndClkDir(ePort, &uSclkDiv, &uSyncDiv);
	PCMCLKCTL_SetDivideLogic(ePort, uSclkDiv, uSyncDiv);	
	PCM_InitDMA(ePort, PCM_RX);
	PCMCTL_SetDipstick(ePort, PCM_RX, pInfor->m_uRXFIFODipstick);
	PCMCTL_EnableFIFO(ePort, PCM_RX, ENABLE);
	PCMCTL_EnableDMA(ePort, PCM_RX, ENABLE);	
	PCMCTL_EnablePCMIF(ePort, ENABLE);		
	Delay(1000);
	PCM_InitDMA(ePort, PCM_TX);	
	PCMCTL_SetDipstick(ePort, PCM_TX, pInfor->m_uTXFIFODipstick);	
	PCMCTL_EnableFIFO(ePort, PCM_TX, ENABLE);
	PCMCTL_EnableDMA(ePort, PCM_TX, ENABLE);	
	while(1)
	{
		UART_Printf("EXIT : X\n");
		uChar = UART_Getc();
		if( (uChar == 'x') | (uChar == 'X')) 
			break;
	} 		
	UART_Printf("\nEnd of Play!\n");
	PCM_DMAStop(ePort, PCM_TX);	
	PCM_DMAStop(ePort, PCM_RX);	
	PCMCTL_EnableDMA(ePort, PCM_TXRX, DISABLE);
	PCMCTL_EnableFIFO(ePort, PCM_TXRX, DISABLE);
	PCMCTL_EnablePCMIF(ePort, DISABLE);
	PCMCLKCTL_ActiveDivideLogic(ePort, DISABLE);		
	//PCM_CodecExitPCMOut();	
}

static void PCMInOutInt(AUDIO_PORT ePort)
{
	PCM_Infor *pInfor = PCM_GetInfor(ePort);
	UART_Printf("Supply Sound to PCM CODEC via Line In Connector.\n");
   	UART_Printf("Press any key to record.\n");
    	UART_Getc();
   	UART_Printf("Recording...\n");	
	PCM_InitCodecDataIn(ePort, pInfor->m_uCodec, pInfor->m_eLine);
	PCM_PCMInInt(ePort);
	//PCM_CodecExitPCMIn(ePort);
	UART_Printf("\nListen to Sound via Speak Out Connector.\n");
	UART_Printf("Press any key to play.\n");
    	UART_Getc();
	UART_Printf("Play...\n");
	PCM_InitCodecDataOut(ePort, pInfor->m_uCodec, pInfor->m_eLine);
	PCM_PCMOutInt(ePort);		
	//PCM_CodecExitPCMOut();	
}


static void PCM_DataIn2Port(AUDIO_PORT ePort)
{
	AUDIO_PORT ePortIndi;
	PCM_Infor*pInfor = PCM_GetInfor(ePort);
	u32 uSclkDiv, uSyncDiv;
	u32 uCnt;
	UART_Printf("Supply Sound to PCM CODEC via Line In Connector.\n");
    	UART_Printf("Press any key to record.\n");    
    	UART_Getc();		
   	UART_Printf("Recording...\n");

	for (uCnt = 0; uCnt < AUDIO_NUM; uCnt++)
	{
		ePortIndi = (AUDIO_PORT) uCnt;
		pInfor = PCM_GetInfor(ePortIndi);
		PCM_InitCodecDataIn(ePortIndi, pInfor->m_uCodec, pInfor->m_eLine);
		PCM_InitDMA(ePortIndi, PCM_RX);
		if ( ePortIndi == AUDIO_PORT0)
			INTC_SetVectAddr(pInfor->m_uNumDma, Isr_PCMPORT0_PCMIn_DMADone);
		else if ( ePortIndi == AUDIO_PORT1)
			INTC_SetVectAddr(pInfor->m_uNumDma, Isr_PCMPORT1_PCMIn_DMADone);	
		PCM_GetClkValAndClkDir(ePortIndi, &uSclkDiv, &uSyncDiv);
		PCMCLKCTL_SetDivideLogic(ePortIndi, uSclkDiv, uSyncDiv);
		PCMCTL_SetDipstick(ePortIndi, PCM_RX, pInfor->m_uRXFIFODipstick);
		PCMCTL_EnableFIFO(ePortIndi, PCM_RX, ENABLE);
		PCMCTL_EnableDMA(ePortIndi, PCM_RX, ENABLE);
		PCMCTL_EnablePCMIF(ePortIndi, ENABLE);	
		pInfor->m_usAC97PCMInDone = FALSE;
	}
	while((PCM_GetInfor(AUDIO_PORT0)->m_usAC97PCMInDone  == FALSE) && (PCM_GetInfor(AUDIO_PORT1)->m_usAC97PCMInDone  == FALSE))
    	{
        	UART_Printf(".");
        	Delay(3000);
    	}
	for (uCnt = 0; uCnt < AUDIO_NUM; uCnt++)
	{
		ePortIndi = (AUDIO_PORT) uCnt;
		pInfor = PCM_GetInfor(ePortIndi);
	    	PCM_DMAStop(ePortIndi, PCM_RX);
		PCMCTL_EnablePCMIF(ePortIndi, DISABLE);	
		PCMCLKCTL_ActiveDivideLogic(ePortIndi, DISABLE);		
		PCMCTL_EnableFIFO(ePortIndi, PCM_RX, DISABLE);
		PCMCTL_EnableDMA(ePortIndi, PCM_RX, DISABLE); 	
	}
  	UART_Printf("\nEnd of Record!\n");
  	Delay(3000); 
}

static void PCM_DataOut2Port(AUDIO_PORT ePort)
{
	AUDIO_PORT ePortIndi;
	PCM_Infor* pInfor = PCM_GetInfor(ePort);
	u32 uCnt;
	u8 uChar;
	for (uCnt = 0; uCnt < AUDIO_NUM; uCnt++)
	{
		ePortIndi = (AUDIO_PORT) uCnt;
		pInfor = PCM_GetInfor(ePortIndi);
		PCM_InitCodecDataOut(ePortIndi, pInfor->m_uCodec, pInfor->m_eLine);
		PCM_PCMOutDMAStart(ePortIndi);
		Delay(10);
	}
	while(1)
	{
		UART_Printf("EXIT : X\n");
		uChar = UART_Getc();
		if( (uChar == 'x') | (uChar == 'X')) 
			break;	
	} 
	for (uCnt = 0; uCnt < AUDIO_NUM; uCnt++)
	{
		ePortIndi = (AUDIO_PORT) uCnt;
		PCM_PCMOutDMAStop(ePortIndi);
	}
	UART_Printf("\nEnd of Play!\n");	
	Delay(3000);
}
void __irq ISR_PCM_INTCHECK(void)
{
	#if 0
	u32 uFIFOStat, uRXFIFOLev, uTXFIFOLev;
	
	PCM_ClearInt(AUDIO_PORT0);
	PCM_ClearInt(AUDIO_PORT1);
	INTC_ClearVectAddr();
	UART_Printf("\nInterrupt!!\n");
	Disp("Before Clearing\n");
	Disp("Port 0(Int)\n");
	UART_Printf("IRQCTL : 	0x%x\t",PCM_Inp32(AUDIO_PORT0, rPCMIRQCTL));
	UART_Printf("IRQSTAT : 	0x%x\t",PCM_Inp32(AUDIO_PORT0, rPCMIRQSTAT));
	uFIFOStat = PCM_Inp32(AUDIO_PORT0, rPCMFIFOSTAT);
	uRXFIFOLev = (uFIFOStat & 0x3f0) >> 4;
	uTXFIFOLev = (uFIFOStat & 0xfc000) >> 14;
	UART_Printf("FIFOSTAT :	0x%x\n",uFIFOStat);
	UART_Printf("RXFIFO Level :	0x%x\n", uRXFIFOLev);
	UART_Printf("TXFIFO Level :	0x%x\n", uTXFIFOLev);
	Disp("Port 1(Int)\n");
	UART_Printf("IRQCTL : 	0x%x\t",PCM_Inp32(AUDIO_PORT1, rPCMIRQCTL));
	UART_Printf("IRQSTAT : 	0x%x\t",PCM_Inp32(AUDIO_PORT1, rPCMIRQSTAT));
	uFIFOStat = PCM_Inp32(AUDIO_PORT1, rPCMFIFOSTAT);
	uRXFIFOLev = (uFIFOStat & 0x3f0) >> 4;
	uTXFIFOLev = (uFIFOStat & 0xfc000) >> 14;
	UART_Printf("FIFOSTAT :	0x%x\n",uFIFOStat);
	UART_Printf("RXFIFO Level :	0x%x\n", uRXFIFOLev);
	UART_Printf("TXFIFO Level :	0x%x\n", uTXFIFOLev);
	//service
	//PCM Clock Setting 
	//PCM_CLKOUT(AUDIO_PORT0);
	//PCM_GetClkValAndClkDir(AUDIO_PORT0, &uSclkDiv, &uSyncDiv);
	//PCMCLKCTL_SetDivideLogic(AUDIO_PORT0, uSclkDiv, uSyncDiv);
	
	INTC_Disable(g_oPCMInfor[AUDIO_PORT0].m_uNumInt);	
	PCMIRQCTL_EnableInt(AUDIO_PORT0, false);
	PCMIRQCTL_SetIRQMode(AUDIO_PORT0, PCMIRQALL, false);						// Disable another Interrupt Condition
	INTC_Disable(g_oPCMInfor[AUDIO_PORT1].m_uNumInt);
	PCMIRQCTL_EnableInt(AUDIO_PORT1, false);
	PCMIRQCTL_SetIRQMode(AUDIO_PORT1, PCMIRQALL, false);						// Disable another Interrupt Condition
	INTC_ClearVectAddr();
	g_isrTest = 1;

	PCMCLKCTL_ActiveDivideLogic(AUDIO_PORT0, DISABLE);	

	Disp("After Clearing\n");
	Disp("Port 0(Int)\n");
	UART_Printf("IRQCTL : 	0x%x\t",PCM_Inp32(AUDIO_PORT0, rPCMIRQCTL));
	UART_Printf("IRQSTAT : 	0x%x\t",PCM_Inp32(AUDIO_PORT0, rPCMIRQSTAT));
	UART_Printf("FIFOSTAT :	0x%x\n",PCM_Inp32(AUDIO_PORT0, rPCMFIFOSTAT));
	Disp("Port 1(Int)\n");
	UART_Printf("IRQCTL : 	0x%x\t",PCM_Inp32(AUDIO_PORT1, rPCMIRQCTL));
	UART_Printf("IRQSTAT : 	0x%x\t",PCM_Inp32(AUDIO_PORT1, rPCMIRQSTAT));
	UART_Printf("FIFOSTAT :	0x%x\n",PCM_Inp32(AUDIO_PORT1, rPCMFIFOSTAT));	
	#endif
}

static void PCM_InterruptTest(AUDIO_PORT ePort)
{
	#if 0 
	u32 uSclkDiv, uSyncDiv;
	u16* uRecBuf = pInfor->m_pRecAddr;
	s32 uPcmDataSize = pInfor->m_uPcmSize;
	u32 uCnt;
	u32 uFIFOStat, uRXFIFOLev, uTXFIFOLev;

	PCMCTL_EnablePCMIF(ePort, false);
	PCMCTL_EnableFIFO(ePort, PCM_TXRX, false);
	PCMIRQCTL_EnableInt(ePort, false);  
	PCMIRQCTL_SetIRQMode(ePort, PCMIRQALL, false);						// Disable another Interrupt Condition
	PCM_ClearInt(ePort);
	
	UART_Printf("\nPress any key to Start Test.\n");
	UART_Getc();
	
	
	INTC_ClearVectAddr();	
	INTC_SetVectAddr(pInfor->m_uNumInt, ISR_PCM_INTCHECK);
		
	//PCM Clock Setting 
	I2S_Init((AUDIO_PORT)(~ePort & 0x1));
	I2S_InitPort((AUDIO_PORT)((~ePort) & 0x1));
	I2S_SetCDCLKOut((AUDIO_PORT)((~ePort) & 0x1), pInfor->m_ePCMClkSrc);
	PCM_GetClkValAndClkDir(ePort, &uSclkDiv, &uSyncDiv);
	PCMCLKCTL_SetDivideLogic(ePort, uSclkDiv, uSyncDiv);
	PCMCLKCTL_ActiveDivideLogic(ePort, ENABLE);	
	PCMIRQCTL_SetIRQMode(ePort, RXFIFO_ALMOST_EMPTY, true);					// Set Irq condition when RX FIFO ALMOST Full	
	PCMCTL_EnableFIFO(ePort, PCM_RX, ENABLE);	
	PCMCTL_EnablePCMIF(ePort, ENABLE);	
	#if 0
	for (uCnt = 0;uCnt<15;uCnt++)
		PCM_Outp16(ePort, rPCMRXFIFO,(uCnt));	
	#elif 1
	Delay(2000);
	PCMCTL_EnablePCMIF(ePort, DISABLE);
	#endif
	Disp("Test Condition\n");
	Disp("Port 0\n");
	UART_Printf("IRQCTL : 	0x%x\t",PCM_Inp32(AUDIO_PORT0, rPCMIRQCTL));
	UART_Printf("IRQSTAT : 	0x%x\t",PCM_Inp32(AUDIO_PORT0, rPCMIRQSTAT));
	uFIFOStat = PCM_Inp32(AUDIO_PORT0, rPCMFIFOSTAT);
	uRXFIFOLev = (uFIFOStat & 0x3f0) >> 4;
	uTXFIFOLev = (uFIFOStat & 0xfc000) >> 14;
	UART_Printf("FIFOSTAT :	0x%x\n",uFIFOStat);
	UART_Printf("RXFIFO Level :	0x%x\n", uRXFIFOLev);
	UART_Printf("TXFIFO Level :	0x%x\n", uTXFIFOLev);
	Disp("Port 1\n");
	UART_Printf("IRQCTL : 	0x%x\t",PCM_Inp32(AUDIO_PORT1, rPCMIRQCTL));
	UART_Printf("IRQSTAT : 	0x%x\t",PCM_Inp32(AUDIO_PORT1, rPCMIRQSTAT));
	uFIFOStat = PCM_Inp32(AUDIO_PORT0, rPCMFIFOSTAT);
	uRXFIFOLev = (uFIFOStat & 0x3f0) >> 4;
	uTXFIFOLev = (uFIFOStat & 0xfc000) >> 14;
	UART_Printf("FIFOSTAT :	0x%x\n",uFIFOStat);
	UART_Printf("RXFIFO Level :	0x%x\n", uRXFIFOLev);
	UART_Printf("TXFIFO Level :	0x%x\n", uTXFIFOLev);
	
	g_isrTest = 0;
	PCMIRQCTL_EnableInt(ePort, ENABLE);
	INTC_Enable(pInfor->m_uNumInt);	
	while(!(g_isrTest))
	{
		#if 0
		*uRecBuf = PCM_Inp16(ePort, rPCMTXFIFO);	//Data Transfer
		#elif 0
		PCM_Outp16(ePort, rPCMTXFIFO,*uRecBuf);		
		#elif 1
		*uRecBuf++ = PCM_Inp16(ePort, rPCMRXFIFO);	//Data Transfer		
		#elif 0
		PCM_Outp16(ePort, rPCMRXFIFO,*uRecBuf);		
		#endif
		UART_Printf("RXFIFO Level :	0x%x\n", ((PCM_Inp32(ePort, rPCMFIFOSTAT) & 0x3f0) >> 4));
	}
	PCM_ClearInt(ePort);
	INTC_ClearVectAddr();
	PCMIRQCTL_EnableInt(ePort, false);  
	INTC_Disable(pInfor->m_uNumInt);	
	PCMCTL_EnablePCMIF(ePort, false);
	PCMCTL_EnableFIFO(ePort, PCM_TXRX, false);
	PCMIRQCTL_EnableInt(ePort, false);  
	PCMIRQCTL_SetIRQMode(ePort, PCMIRQALL, false);						// Disable another Interrupt Condition
	PCM_ClearInt(ePort);
	PCMCLKCTL_ActiveDivideLogic(ePort, FALSE);	
	UART_Printf("\nTest Done\n");
	#endif
}

static void PCMInAC97Out(AUDIO_PORT ePort)
{
	#if 0
	PCM_Infor *pInfor = PCM_GetInfor(ePort);
	UART_Printf("This Test is available when you use WM9713 Codec(AC97)\n");
	Delay(5000);
	
	#if (PCM_CODEC == WM9713)
	
		UART_Printf("PCM and AC97 operation are DMA mode\n");
		UART_Printf("Press any key to Continue.\n");
	    	UART_Getc();
		//Encoding by PCM ADC	
		//PCM_CodecInitPCMIn(pInfor->m_uSamplingRate, pInfor->m_eTXMSBPosition, pInfor->PCMSClk, pInfor->PCMClkSrc);			//set external codec
		PCM_PCMInDMA(ePort);					//set internal interface controller
		//PCM_CodecExitPCMIn(ePort);			//set DMA 
		//Decoding by AC97 DAC
		if(AC97_InitACLINK())
		{
			AC97_InitCodecPCMOut(pInfor->m_uSamplingRate);
			AC97_MICOutDMA();
		}
		
	#else
		UART_Printf("Present Codec is not WM9713(AC97) Codec!!\n");
	#endif
	#endif
}

static void AC97InPCMOut(AUDIO_PORT ePort)
{
	#if 0
	u8 uChar;
	PCM_Infor *pInfor = PCM_GetInfor(ePort);
	UART_Printf("This Test is available when you use WM9713 Codec(AC97)\n");
	Delay(5000);
	
	#if (PCM_CODEC == WM9713)
		UART_Printf("PCM and AC97 operation are DMA mode\n");
		UART_Printf("Press any key to Continue.\n");
	    	UART_Getc();
		
		if(AC97_InitACLINK())
		{	
			//Encoding by AC97 ADC
			AC97_InitCodecMICIn(pInfor->m_uSamplingRate);
			AC97_MICInDMA();
			//Decoding by PCM DAC
			//PCM_CodecInitPCMOut(pInfor->m_uSamplingRate, pInfor->m_eTXMSBPosition, pInfor->m_uPCMSClk, pInfor->PCMClkSrc);							 
			PCM_PCMOutDMAStart(pInfor->m_pRecAddr, pInfor->m_uPcmSize);
			#if (PCM_CODEC == WM9713)
			UART_Printf("Codec CMD : 's'	Exit : x\n");
			while(1)
			{
				UART_Printf("0x%x\n",AC97_CodecCmd(READ,0x36,0x0000));
				uChar = UART_Getc();

				if( (uChar == 'x') | (uChar == 'X')) 
					break;

				else if ( (uChar == 's' )| (uChar =='S') )
					AC97_CodecCmdManually();
			} 
			#else
			UART_Printf("\nIf you want to exit, Press the 'x' key.\n");
			UART_Printf("DMA Disable : P		Enable : O\n");
			UART_Printf("FIFO Disable : L	Enable : K\n");
			UART_Printf("CLK Disable : I		Enable : U\n");
			while(1)
			{
				uChar = UART_Getc();
				if( (uChar == 'x') | (uChar == 'X')) 
					break;
				else if ( (uChar == 'o') | (uChar == 'O'))
					PCMCTL_EnableDMA(ePort, PCM_TX, true);
				else if ( (uChar == 'p') | (uChar == 'P'))
					PCMCTL_EnableDMA(ePort, PCM_TX, false);
				else if ( (uChar == 'l') | (uChar == 'L'))
					PCMCTL_EnableFIFO(ePort, PCM_TX, false);
				else if ( (uChar == 'k') | (uChar == 'K'))
					PCMCTL_EnableFIFO(ePort, PCM_TX, true);
				else if ( (uChar == 'i') | (uChar == 'I'))
					PCMCLKCTL_ActiveDivideLogic(ePort, false);
				else if ( (uChar == 'u') | (uChar == 'U'))
					PCMCLKCTL_ActiveDivideLogic(ePort, true);
			} 
			#endif
		}	
	#else
	UART_Printf("Present Codec is not WM9713(AC97) Codec!!\n");
	#endif
	#endif
}

void PCMConf_SetPCMCLKSource(AUDIO_PORT ePort)
{
	PCM_Infor* pInfor = PCM_GetInfor(ePort);
	s32 uSelection;
	do
	{
		UART_Printf("Select PCM Source CLK\n");
		UART_Printf("0. EPLL		1. MPLL		2. System Clock(Fin of Syscon)\n");
		UART_Printf("3. External Codec CLK	4. PCLK\n");
		uSelection = UART_GetIntNum();
	}while(uSelection < 0 || uSelection > 4);	
	PCM_SelCLKAUDIO(ePort, (PCM_CLKSRC) uSelection);
	Delay(1000);	
}

void  PCMConf_SetPCMSCLK(AUDIO_PORT ePort)
{
	PCM_Infor* pInfor = PCM_GetInfor(ePort);
	u32 uSclk;
	do{
		UART_Printf("Enter the PCMSCLK Frequency\n");
		UART_Printf("!!Warning!!\n PCMSCLK must be greater than 16 times of PCMSYNC\n");
		uSclk = UART_GetIntNum();
	}while(!(uSclk >= (16 * pInfor->m_uSamplingRate)));
	pInfor->m_uPCMSClk = uSclk;
}

void PCMConf_SetPCMSync(AUDIO_PORT ePort)
{
	PCM_Infor* pInfor = PCM_GetInfor(ePort);
	u32 uSampleRate;
	do{
		UART_Printf("Enter the PCMSync Frequency(Sample Rate : 8000Hz ~ 19200Hz)\n");		
		uSampleRate = UART_GetIntNum();
	}while(!(uSampleRate >= 8000 && uSampleRate <= 192000));
	pInfor->m_uSamplingRate= uSampleRate;	
	if (pInfor->m_uPCMSClk < (16 * uSampleRate))
	{
		UART_Printf("Current PCMSCLK %3.1fKHz dose not support new PCM Sync!!\n",(double) (pInfor->m_uPCMSClk/1000));
		PCMConf_SetPCMSCLK(ePort);
	}	
}
	
void PCMConf_MSBPosition(AUDIO_PORT ePort)
{
	s8 selTemp;
	PCM_Infor* pInfor = PCM_GetInfor(ePort);
	do{
		UART_Printf("\nSelect PCM data MSB Postion\n");
		UART_Printf("0.TX DURING_PCMSYNC_HIGH(DSP Mode B)	1.TX AFTER_PCMSYNC_HIGH(DSP Mode A)[D]\n ");
		UART_Printf("2.TX DURING_PCMSYNC_HIGH(DSP Mode B)	3.TX AFTER_PCMSYNC_HIGH(DSP Mode A)[D]\n ");
		UART_Printf("4.ALL I/F DURING_PCMSYNC_HIGH(DSP Mode B)	5.ALL I/F AFTER_PCMSYNC_HIGH(DSP Mode A)[D]\n ");
		selTemp = UART_GetIntNum();
	}while(!(selTemp >= 0 && selTemp <= 5));
	if (selTemp == 0)			PCMCTL_SetMSBPosition(ePort, PCM_TX, DURING_PCMSYNC_HIGH);
	else if (selTemp == 1)	PCMCTL_SetMSBPosition(ePort, PCM_TX, AFTER_PCMSYNC_HIGH);
	else if (selTemp == 2)	PCMCTL_SetMSBPosition(ePort, PCM_RX, DURING_PCMSYNC_HIGH);
	else if (selTemp == 3)	PCMCTL_SetMSBPosition(ePort, PCM_RX, AFTER_PCMSYNC_HIGH);
	else if (selTemp == 4)	PCMCTL_SetMSBPosition(ePort, PCM_TXRX, DURING_PCMSYNC_HIGH);
	else 					PCMCTL_SetMSBPosition(ePort, PCM_TXRX, AFTER_PCMSYNC_HIGH);	
}
	
void PCMConf_Interrupt(AUDIO_PORT ePort)
{
	s8 ucSel;	
	s32 sLoopCnt = 13;
	s32 sCnt;
	u32 uIntCondition = (1 << sLoopCnt);
	PCM_Infor* pInfor = PCM_GetInfor(ePort);
	for ( sCnt = sLoopCnt; sCnt != 0;sCnt--)
	{
		Disp("Interrupt Condition");
		if (uIntCondition == TRANSFER_DONE)				Disp("Transfer Done");
		else if (uIntCondition == TXFIFO_EMPTY)			Disp("TX FIFO Empty");
		else if (uIntCondition == TXFIFO_ALMOST_EMPTY)	Disp("TX FIFO Almost Empty");
		else if (uIntCondition == TXFIFO_FULL)				Disp("TX FIFO Full");
		else if (uIntCondition == TXFIFO_ALMOST_FULL)		Disp("TX FIFO Almost Full");
		else if (uIntCondition == TXFIFO_ERROR_STARVE)		Disp("TX FIFO Starve Error");
		else if (uIntCondition == TXFIFO_ERROR_OVERFLOW)	Disp("TX FIFO Overflow Error");
		else if (uIntCondition == RXFIFO_EMPTY)			Disp("RX FIFO Empty");
		else if (uIntCondition == RXFIFO_ALMOST_EMPTY)	Disp("RX FIFO Almost Empty");
		else if (uIntCondition == RX_FIFO_FULL)				Disp("RX FIFO Full");
		else if (uIntCondition == RX_FIFO_ALMOST_FULL)		Disp("RX FIFO Alomst Full");
		else if (uIntCondition == RXFIFO_ERROR_STARVE)		Disp("RX FIFO Starve Error");
		else if (uIntCondition == RXFIFO_ERROR_OVERFLOW)	Disp("RX FIFO Overflow Error");
		else 											Disp("All of Interrupt Condition");	
		UART_Printf("\n0: Disable	1: Enable	2: Stop Condition Select\n");
		ucSel = UART_GetIntNum();
		if (ucSel == 2)
			break;
		else
		{
			if (uIntCondition == (1 << 13))
				PCMIRQCTL_SetIRQMode(ePort, PCMIRQALL, ucSel);
			else
				PCMIRQCTL_SetIRQMode(ePort, (PCM_INT) uIntCondition, ucSel);
		}
		uIntCondition = (1 << sCnt);
	}
}


//////////
// Function Name : PCMConf_DMAUnit
// Function Description : 
//   This function selects DMA Controller
// Input : 	ePort ->  I2S Controller
// Output : None
// Version : 0.0
// Example 
// I2SConf_SelDMAUnit(AUDIO_PORT1);
void PCMConf_DMAUnit(AUDIO_PORT ePort)
{	
	s32 uSelection;
	PCM_Infor *pInfor = PCM_GetInfor(ePort);
	do{
		UART_Printf("Select DMA\n");
		UART_Printf("0. Normal DMA		1. Secure DMA\n");
		uSelection = UART_GetIntNum();
	}while(!(uSelection >= 0 && uSelection <= 1));
	
	if ( uSelection == 0 )
		PCM_SetDMAUnit(ePort, (DMA_UNIT)((u32) DMA0 + (u32)ePort));
	
	else	
		PCM_SetDMAUnit(ePort, (DMA_UNIT)((u32) SDMA0 + (u32)ePort));
}

//////////
// Function Name : PCMConf_DMAUnitChanne
// Function Description : 
//   This function selects DMA Controller
// Input : 	ePort ->  I2S Controller
// Output : None
// Version : 0.0
// Example 
// I2SConf_SelDMAUnit(AUDIO_PORT1);
void PCMConf_DMAUnitChanne(AUDIO_PORT ePort)
{	
	s32 uSelection;
	s32 sChSel;
	PCM_Infor *pInfor = PCM_GetInfor(ePort);
	DMA_CH	uCh;
	do
	{
		do
		{
			UART_Printf("Select PCM Interface Channel\n");
			UART_Printf("0: TX	1: RX\n");
			sChSel = UART_GetIntNum();
		}while(!(uSelection >= 0 && uSelection <= 1));
		UART_Printf("\nSelect Channel : 0:CH A, 1:CH B, 2:CH C, 3:CH D, 4:CH E, 5:CH F, 6:CH G, 7:CH H	: ");
		uSelection=UART_GetIntNum();
		UART_Printf("\n");	
	}while(!(uSelection >= 0 && uSelection <= 7));
	switch(uSelection)
	{
		case 0: 	uCh = DMA_A;	break;             
		case 1: 	uCh = DMA_B;	break;
		case 2: 	uCh = DMA_C;	break;
		case 3: 	uCh = DMA_D;	break;	     	
		case 4: 	uCh = DMA_E;	break;
		case 5: 	uCh = DMA_F;	break;
		case 6: 	uCh = DMA_G;	break;
		case 7: 	uCh = DMA_H;	break;				
		default : Assert(0);
	}
	PCM_SetDMACh(ePort, (I2S_IFMode) sChSel, uCh );	
}


//////////
// Function Name : PCMConf_Addr
// Function Description : 
//   This function set PCM Data Address.
// Input : 	ePort ->  I2S Controller
// Output : None
// Version : 0.0
// Example 
// PCMConf_Addr(AUDIO_PORT1);
void PCMConf_Addr(AUDIO_PORT ePort)
{
	s32 uSelection;
	u32 uTempAddr;
	s32 uTempSize;
	PCM_Infor *pInfor = PCM_GetInfor(ePort);
	do
	{
		UART_Printf("Select PCM Interface Channel\n");
		UART_Printf("0: TX	1: RX	2: Tx and Rx\n");
		uSelection = UART_GetIntNum();
	}while(!(uSelection >= 0 && uSelection <= 2));	
	UART_Printf("Enter the new temporary address(0x...):");
	uTempAddr = (u32) UART_GetIntNum();
	if ( uTempAddr == 0xffffffff )
		uTempAddr = 0x5100002c;
	UART_Printf("Enter the new size that is multiple of 4(0x4 ~ 0xfffff):");
	uTempSize = (u32) UART_GetIntNum();
	if ( uTempSize < 0x4 ||  uTempSize > 0xfffff )
		uTempAddr = 0xfffff;	
	uTempSize = (uTempSize / 4) * 4;
	PCM_SetAddr(ePort, (PCM_IFMODE) uSelection, (u16 *) uTempAddr, uTempSize);
}

//////////
// Function Name : PCMConf_Codec
// Function Description : 
//   This function configurate SMDK.
// Input : 	ePort ->  I2S Controller
// Output : None
// Version : 0.0
// Example 
// PCMConf_Addr(AUDIO_PORT1);
void PCMConf_Codec(AUDIO_PORT ePort)
{
	s32 uSelection;
	do
	{
		UART_Printf("Select Audio Codec for PCM I/Fl\n");
		UART_Printf("0: AK2430	1: WM9713	2: WM8753	3: STAC9767	4: WM8580	5: WM8990\n");
		uSelection = UART_GetIntNum();
	}while(!(uSelection >= 0 && uSelection <= 5));	
	PCM_GetInfor(ePort)->m_uCodec = uSelection;
}

static void PCMCodecRegWR(AUDIO_PORT ePort)
{
	
/////////////////////////////////////////////////////////////////////
	#if (PCM_CODEC == AK2430)	
		u32 i;
		UART_Printf("\nIIC Test of AK2430 PCM Codec.\n");
		UART_Printf("\nReg. Addr.	Reg. Data\n");	

		//for(i=0x2; i<0x1e; i++)
		//	UART_Printf("%2x		%2x \n", i, PCM_CODEC_IICRead(0x9e, i));		

		for(i=0;i<32;i++)
		{
			//PCM_CODEC_IICWrite(0x9e, 0x15, i);
			//UART_Printf("MASTERVOL: %2x \n", PCM_CODEC_IICRead(0x9e, 0x15));		
		}
	
/////////////////////////////////////////////////////////////////////
	#elif (PCM_CODEC == WM9713)
		u32 uOutVol;
		u32 i;
		UART_Printf("\nRegister W/R Test of WM9713 PCM Codec.\n");
		if(AC97_InitACLINK())
		{	
			for(i=0; i<32; i++)
			{
				AC97_CodecCmd(WRITE,0x04,i);		// Set HPL/R Volume 
				uOutVol = AC97_CodecCmd(READ,0x04,0x00000);
				UART_Printf("HPL/R Volume: %2x \n", uOutVol);
			}
		}
	
/////////////////////////////////////////////////////////////////////
	#elif (PCM_CODEC == WM8753)
		u32 i;
		UART_Printf("\nIIC Test of WM8753 PCM Codec.\n");
		for(i=0; i<128; i++)
		{
			//PCM_CODEC_IICWrite(0x34, 0x58, i);
			UART_Printf(".");
			Delay(1000);
		} 
		UART_Printf("\n");
	#else
		Assert(0);
	#endif
	
}
