/********************************************************************************
* 
*	Project Name : S3C6400 Validation
*
*	Copyright 2006 by Samsung Electronics, Inc.
*	All rights reserved.
*
*	Project Description :
*		This software is only for verifying functions of the S3C6400.
*		Anybody can use this software without our permission.
*  
*--------------------------------------------------------------------------------
* 
*	File Name : pcm.h
*	File Description :
*
*	Author	: Sung-Hyun, Na
*	Dept. : AP Development Team
*
*	Version : 0.2
* 
*	History
*	- Version 0.1 (2007/03/16)
*	  -> Available with AK2440 PCM Codec.
*   - Version 0.2 (2007/04/19)
*     -> Also, working with WM8753 PCM Codec.
*
********************************************************************************/

#ifndef __PCM_H__
#define __PCM_H__
 
  
#ifdef __cplusplus
extern "C" {
#endif

#include "def.h"
#include "option.h"
#include "library.h"
#include "sfr6410.h"
#include "system.h"
#include "sysc.h"
#include "dma.h"
#include "i2s.h"
#include "ac97.h"
#include "audio.h"



#define PCM_CODEC			WM8990

// Codec Master CLK ON/OFF

#define PCMCTL_EN_TX_DMA						(1 << 6)
#define PCMCTL_EN_RX_DMA						(1 << 5)
#define PCMCTL_EN_TX_FIFO						(1 << 2)
#define PCMCTL_EN_RX_FIFO						(1 << 1)
#define PCMCTL_EN_PCMIF							(1 << 0)
#define PCMCTL_ST_RXFIFODIPSTICK(n)				(((n)&0x3f) <<7)
#define PCMCTL_ST_TXFIFODIPSTICK(n)				(((n)&0x3f) <<13)

#define PCMCLK_EN_DivideLogic						(1 << 19)
#define PCMCLK_SERCLKSEL						(1 << 18)

#define PCMIRQ_Enable_IRQ_TO_ARM				(1 << 14)
#define PCMIRQ_Enable_ALLPCMIRQ					(0x1fff)
#define PCMIRQ_Enable_TransferDone				(1 << 12)
#define PCMIRQ_Enable_TX_FIFO_EMPTY				(1 << 11)
#define PCMIRQ_Enable_TX_FIFO_ALMOST_EMPTY		(1 << 10)
#define PCMIRQ_Enable_TX_FIFO_FULL				(1 << 9)
#define PCMIRQ_Enable_TX_FIFO_ALMOST_FULL		(1 << 8)
#define PCMIRQ_Enable_TX_FIFO_STARVE_ERROR		(1 << 7)
#define PCMIRQ_Enable_TX_FIFO_OVERFLOW_ERROR	(1 << 6)
#define PCMIRQ_Enable_RX_FIFO_EMPTY				(1 << 5)
#define PCMIRQ_Enable_RX_FIFO_ALMOST_EMPTY		(1 << 4)
#define PCMIRQ_Enable_RX_FIFO_FULL				(1 << 3)
#define PCMIRQ_Enable_RX_FIFO_ALMOST_FULL		(1 << 2)
#define PCMIRQ_Enable_RX_FIFO_STARVE_ERROR		(1 << 1)
#define PCMIRQ_Enable_RX_FIFO_OVERFLOW_ERROR	(1 << 0)

#define PCMIRQ_Status_IRQ_PENDING				(1 << 13)
#define PCMIRQ_Status_TX_FIFO_EMPTY				(1 << 11)
#define PCMIRQ_Status_TX_FIFO_ALMOST_EMPTY		(1 << 10)
#define PCMIRQ_Status_TX_FIFO_FULL				(1 << 9)
#define PCMIRQ_Status_TX_FIFO_ALMOST_FULL		(1 << 8)
#define PCMIRQ_Status_TX_FIFO_STARVE_ERROR		(1 << 7)
#define PCMIRQ_Status_TX_FIFO_OVERFLOW_ERROR	(1 << 6)
#define PCMIRQ_Status_RX_FIFO_EMPTY				(1 << 5)
#define PCMIRQ_Status_RX_FIFO_ALMOST_EMPTY		(1 << 4)
#define PCMIRQ_Status_RX_FIFO_FULL				(1 << 3)
#define PCMIRQ_Status_RX_FIFO_ALMOST_FULL		(1 << 2)
#define PCMIRQ_Status_RX_FIFO_STARVE_ERROR		(1 << 1)
#define PCMIRQ_Status_RX_FIFO_OVERFLOW_ERROR	(1 << 0)

#define PCMFIFO_Status_TX_FIFO_Count				(0x3f << 14)
#define PCMFIFO_Status_TX_FIFO_EMPTY				(1 << 13)
#define PCMFIFO_Status_TX_FIFO_ALMOST_EMPTY		(1 << 12)
#define PCMFIFO_Status_TX_FIFO_FULL				(1 << 11)
#define PCMFIFO_Status_TX_FIFO_ALMOST_FULL		(1 << 10)
#define PCMFIFO_Status_RX_FIFO_Count				(0x3f << 4)
#define PCMFIFO_Status_RX_FIFO_EMPTY				(1 << 3)
#define PCMFIFO_Status_RX_FIFO_ALMOST_EMPTY		(1 << 2)
#define PCMFIFO_Status_RX_FIFO_FULL				(1 << 1)
#define PCMFIFO_Status_RX_FIFO_ALMOST_FULL		(1 << 0)

#define PCM_FIFOEmpty 							(1 << 3)
#define PCM_FIFOAlmostEmpty 						(1 << 2)
#define PCM_FIFOFull 								(1 << 1)
#define PCM_FIFOAlmostFull 						(1 << 0)

#define PCM_REC_BUF  				CODEC_MEM_ST	//0x51000000
#define PCM_REC_LEN 				0xffff

typedef enum 
{
	rPCMCTRL = 0x0,		
	rPCMCLKCTL = 0x4,		
	rPCMTXFIFO = 0x8,		
	rPCMRXFIFO = 0xc,   	
	rPCMIRQCTL = 0x10,		
	rPCMIRQSTAT= 0x14,		
	rPCMFIFOSTAT = 0x18,	
	rPCMCLRINT = 0x20		
}PCM_SFR;





#define PCM_RXFIFO_EN   			(1<<1)
#define PCM_TXFIFO_EN			(1<<2)
#define RX_MSB_POS0				(0<<3)
#define RX_MSB_POS1				(1<<3)
#define TX_MSB_POS0				(0<<4)
#define TX_MSB_POS1				(1<<4)
#define PCM_RX_DMA_EN			(1<<5)
#define PCM_TX_DMA_EN			(1<<6)
#define RXFIFO_DIPSTICK(n)		(((n)&0x3f) <<7)
#define TXFIFO_DIPSTICK(n)		(((n)&0x3f) <<13)

#if 0	//For PCM SFR W/R Test
REGINFO		sPCMRegInfo[] = 
{ 

	{"			", PCM0_BASE+0x00, 32, RW, DPDB, 0, 0},   
	{"			", PCM0_BASE+0x04, 32, RW, DPDB, 0, 0},
	{"			", PCM0_BASE+0x08, 32, RW, DPDB, 0, 0},
	{"			", PCM0_BASE+0x0C, 32, RW, DPDB, 0, 0},
	{"			", PCM0_BASE+0x10, 32, RW, DPDB, 0, 0},   
	{"			", PCM0_BASE+0x14, 32, RW, DPDB, 0, 0},
	{"			", PCM0_BASE+0x18, 32, RW, DPDB, 0, 0},
	{"			", PCM0_BASE+0x20, 32, RW, DPDB, 0, 0},   

	{"			", PCM1_BASE+0x00, 32, RW, DPDB, 0, 0},   
	{"			", PCM1_BASE+0x04, 32, RW, DPDB, 0, 0},
	{"			", PCM1_BASE+0x08, 32, RW, DPDB, 0, 0},
	{"			", PCM1_BASE+0x0C, 32, RW, DPDB, 0, 0},
	{"			", PCM1_BASE+0x10, 32, RW, DPDB, 0, 0},   
	{"			", PCM1_BASE+0x14, 32, RW, DPDB, 0, 0},
	{"			", PCM1_BASE+0x18, 32, RW, DPDB, 0, 0},
	{"			", PCM1_BASE+0x20, 32, RW, DPDB, 0, 0},   

};
#endif

///////////////////////////////////////////////////////////////////////////////////////

//Port Selction
typedef enum
{
	PCM_TX = 0,
	PCM_RX = 1,
	PCM_TXRX = 2
}PCM_IFMODE;
//Clock Source Selction 
typedef enum
{
	PCM_MOUT_EPLL = 0,
	PCM_DOUT_MPLL = 1,
	PCM_FIN_EPLL = 2,
	PCM_PCMCDCLK = 3,
	PCM_PCLK =4
}PCM_CLKSRC;

typedef enum 
{
	PCMIRQALL				= (0x1fff),
	PCMIRQPENDING			= (1 << 13),
	TRANSFER_DONE			= (1 << 12), 
	TXFIFO_EMPTY			= (1 << 11),
	TXFIFO_ALMOST_EMPTY	= (1 << 10),
	TXFIFO_FULL				= (1 << 9),
	TXFIFO_ALMOST_FULL		= (1 << 8),
	TXFIFO_ERROR_STARVE	= (1 << 7),
	TXFIFO_ERROR_OVERFLOW	= (1 << 6),
	RXFIFO_EMPTY			= (1 << 5),
	RXFIFO_ALMOST_EMPTY	= (1 << 4),
	RX_FIFO_FULL				= (1 << 3),
	RX_FIFO_ALMOST_FULL		= (1 << 2),
	RXFIFO_ERROR_STARVE	= (1 << 1),
	RXFIFO_ERROR_OVERFLOW	= (1 << 0)
}PCM_INT;
///////////////////////////////////////////////////////////////////////////////////////

typedef struct
{
	// Interrupt
	u32 						m_uNumInt;
	// DMA
	u32 						m_uNumDma;
	DMA_UNIT 				m_eDmaUnit;
	//Tx DMA Request Channel
	DMA_CH					m_eDmaTxCh;
	DMAC 					m_oPcmTxDma;
	//Rx DMA Request Channel
	DMA_CH					m_eDmaRxCh;
	DMAC 					m_oPcmRxDma;
	// Memory Address
	u16*					m_pPCMTxAddr;
	u16*					m_pRecAddr;
	s32						m_uPlaySize;
	s32						m_uRecSize;
	u16*					m_pMemI2STx;		
	u16*					m_pMemI2SRx;
	// Sample Rate
	u32						m_uSamplingRate;	
	u32						m_uPCMSClk;
	// IP Operation
	u16						m_uTXFIFODipstick;
	u16						m_uRXFIFODipstick;
	SerialDataFormat			m_eTXMSBPosition;	
	SerialDataFormat			m_eRXMSBPosition;	
	PCM_CLKSRC				m_ePCMClkSrc;
	u32						m_uIntAspects;
	// SMDK
	AudioCodec				m_uCodec;
	CodecPort				m_eLine;		
	u16 *					m_uRecBufferEndAddr;
	// 
	u8						m_usAC97PCMInDone;
	u8						m_usAC97PCMOutDone;
}PCM_Infor;

typedef struct PCMtestFuncMenu {
	void (*func)(AUDIO_PORT); 
	const char *desc;
} PCMtestFuncMenu;


///////////////////////////////////////////////////////////////////////////////////////
PCM_Infor* PCM_GetInfor(AUDIO_PORT);
void PCM_SetInfor(AUDIO_PORT ePort, PCM_Infor* peInfor);
u8 PCM_CpyInfor(AUDIO_PORT ePort, u32 *peTemp);
void PCM_SetAddr(AUDIO_PORT ePort, PCM_IFMODE  eCh, u16* pAddr, u32 uDataSize);
u16* PCM_PutDataMem(AUDIO_PORT, PCM_IFMODE , u32);
u16 PCM_PopDataMem(AUDIO_PORT, PCM_IFMODE);
u8 PCM_InitCodecDataIn(AUDIO_PORT ePort, u32 uCodecId, CodecPort eCodecPort);
u8 PCM_InitCodecDataOut(AUDIO_PORT ePort, u32 uCodecId, CodecPort eCodecPort);
u8 PCM_InitCodecFullDuplex(AUDIO_PORT ePort, u32 uCodecId, CodecPort eCodecPort);
void PCM_Init(AUDIO_PORT);



void PCM_InitPort(AUDIO_PORT ePort);
void PCM_ClosePort(AUDIO_PORT ePort);
//void PCM_CLKOUT(AUDIO_PORT ePort);
void PCM_PCMInDMA(AUDIO_PORT ePort);
void PCM_PCMInDMAStop(AUDIO_PORT ePort);
void PCM_PCMOutDMAStart(AUDIO_PORT ePort);
void PCM_PCMOutDMAStop(AUDIO_PORT ePort);
void PCM_PCMInInt(AUDIO_PORT ePort);
void PCM_PCMOutInt(AUDIO_PORT ePort);

void PCM_InitDMA(AUDIO_PORT, PCM_IFMODE);
void PCM_DMAStop(AUDIO_PORT, PCM_IFMODE);

void PCM_DMADone(AUDIO_PORT, PCM_IFMODE);
void PCM_DMARestart(AUDIO_PORT, PCM_IFMODE);
void PCM_IsrDataIn(AUDIO_PORT);
void PCM_IsrDataOut(AUDIO_PORT);

void __irq Isr_PCMPORT0_PCMIn_DMADone(void);
void __irq Isr_PCMPORT0_PCMIn_DMARestart(void);
void __irq Isr_PCMPORT0_PCMOut_DMADone(void);
void __irq Isr_PCMPORT1_PCMIn_DMADone(void);
void __irq Isr_PCMPORT1_PCMIn_DMARestart(void);
void __irq Isr_PCMPORT1_PCMOut_DMADone(void);

void __irq Isr_PCMPORT0_PCMIn(void);
void __irq Isr_PCMPORT0_PCMOut(void);
void __irq Isr_PCMPORT1_PCMIn(void);
void __irq Isr_PCMPORT1_PCMOut(void);

void __irq Isr_PCM0_Bypass(void);
void __irq Isr_PCM1_Bypass(void);




void PCMCTL_PutData(AUDIO_PORT ePort);
void PCMCTL_SetDipstick(AUDIO_PORT, PCM_IFMODE, u8);
void PCMCTL_SetMSBPosition(AUDIO_PORT, PCM_IFMODE , SerialDataFormat);
void PCMCTL_EnablePCMIF(AUDIO_PORT ePort,   u8 uActive);
void PCMCTL_EnableDMA(AUDIO_PORT ePort,  PCM_IFMODE rhs_eIFMode, u8 uActive);
void PCMCTL_EnableFIFO(AUDIO_PORT ePort, PCM_IFMODE rhs_eIFMode, u8 uActive);

void PCMCLKCTL_SetDivideLogic(AUDIO_PORT ePort, u32 uSclkDiv, u32  uSyncDiv);
void PCMCLKCTL_ActiveDivideLogic(AUDIO_PORT ePort, u8 uActive);
void PCMCLKCTL_SetSclkDivVal(AUDIO_PORT ePort, u32 uSclkDiv);
void PCMCLKCTL_SetSyncDivVal(AUDIO_PORT ePort, u32 uSyncDiv);

u8 PCMFIFO_GetValid(AUDIO_PORT, PCM_IFMODE);
u16 PCMFIFO_GetData(AUDIO_PORT, PCM_IFMODE);
void PCMFIFO_PutData(AUDIO_PORT, PCM_IFMODE, u16);

void PCMIRQCTL_EnableInt(AUDIO_PORT ePort, u8 rhs_uActive);
void PCMIRQCTL_SetIRQMode(AUDIO_PORT ePort, PCM_INT rhs_ePcmInt,  u8 rhs_uActive);
u32 PCMIRQCTL_GetIRQMode(AUDIO_PORT);
u32 PCMIRQSTAT_GetIRQState(AUDIO_PORT);
u8 PCMFIFO_GetCnt(AUDIO_PORT, PCM_IFMODE);
u8 PCMFIFO_GetState(AUDIO_PORT, PCM_IFMODE);

void PCM_ClearInt(AUDIO_PORT);

void PCM_SelCLKAUDIO(AUDIO_PORT ePort, PCM_CLKSRC eClkSrc);
void PCM_GetClkValAndClkDir(AUDIO_PORT ePort, u32* uSclkDiv, u32* uSyncDiv);
void PCM_SetDMAUnit(AUDIO_PORT, DMA_UNIT);
u8 PCM_SetDMACh(AUDIO_PORT, I2S_IFMode, DMA_CH);
#ifdef __cplusplus
}
#endif

#endif /*__PCM_H__*/

