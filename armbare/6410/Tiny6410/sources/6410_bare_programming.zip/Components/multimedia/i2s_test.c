/**************************************************************************************
* 
*	Project Name : S3C6400 Validation
*
*	Copyright 2006 by Samsung Electronics, Inc.
*	All rights reserved.
*
*	Project Description :
*		This software is only for validating functions of the S3C6400.
*		Anybody can use this software without our permission.
*  
*--------------------------------------------------------------------------------------
* 
*	File Name : i2s_test.c
*  
*	File Description : This file implements i2s test functions.
*
*	Author : Sunil,Roe
*	Dept. : AP Development Team
*	Created Date : 2006/12/26
*	Version : 0.2 
* 
*	History
*	- 0. Created(Sunil,Roe 2006/12/26)
*	- 1. Revision for S3C6410 (Sung-Hyun, Na 2008/02/15)
*   
**************************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

#include "def.h"
#include "option.h"
#include "library.h"
#include "sfr6410.h"
#include "system.h"
#include "sysc.h"
#include "gpio.h"
#include "dma.h"
#include "intc.h"
#include "iic.h"
#include "i2s.h"
#include "audio.h"

#include "nand.h"

void I2S_InitCodecDataIn(AUDIO_PORT ePort, u32 uCodecId, CodecPort eCodecPort);
void I2S_InitCodecDataOut(AUDIO_PORT ePort, u32 uCodecId, CodecPort eCodecPort);
void I2S_InitCodecFullDuplex(AUDIO_PORT ePort, u32 uCodecId, CodecPort eCodecPort);

void I2S_DispTestInfor(void);
AUDIO_PORT I2S_ChangePort(void);
void I2SConf_Addr(AUDIO_PORT ePort);
void I2SConf_WordLength(AUDIO_PORT);
void I2SConf_CLKSource(AUDIO_PORT);
void I2SConf_Interface(AUDIO_PORT);
void I2SConf_OPMode(AUDIO_PORT);
void I2SConf_LRPolarity(AUDIO_PORT);
void I2SConf_IFFormat(AUDIO_PORT);
void I2SConf_RFS(AUDIO_PORT);
void I2SConf_BFS(AUDIO_PORT);
void I2SConf_DCE(AUDIO_PORT ePort);
void I2SConf_CDD(AUDIO_PORT ePort);
void I2SConf_SampleRate(AUDIO_PORT);
void I2SConf_SelDMAUnit(AUDIO_PORT);
void I2SConf_Codec(AUDIO_PORT ePort);
/*-----------------------------------Test Functions ------------------------------------*/
void I2S_Configuration(AUDIO_PORT ePort);

void I2S_PollingRx(AUDIO_PORT ePort);
void I2S_PollingTx(AUDIO_PORT ePort);
void I2S_PollingFullDuplex(AUDIO_PORT ePort);

void I2S_DMARx(AUDIO_PORT);
void I2S_DMATx(AUDIO_PORT);
void I2S_DMAFullDuplex(AUDIO_PORT ePort);

void I2S_IntrRx(AUDIO_PORT ePort);
void I2S_IntrTx(AUDIO_PORT ePort);

//void I2S_LoopBackTest(AUDIO_PORT ePort);

void I2S_CodecRead(AUDIO_PORT ePort);
// global variables
extern NAND_oInform NAND_Inform[NAND_CONNUM];
/*---------------------------------- Test Functions -------------------------------*/
//////////
// Function Name : I2S_Test
// Function Description : 
//   This function implements I2S Test function.
// Input : NONE
// Output : NONE
// Version : 
void I2S_Test(void)
{
	u32 uCountFunc=0;
	s32 iSel=0;
	AUDIO_PORT eSelPort;	
	const I2StestFuncMenu aI2STestFunc[] =
	{
		//I2S Function Test Item
		0,							"Exit\n",
		I2S_Configuration,			"I2S Configuration\n",	
		
		I2S_PollingRx,				"Polling Mode Data In . ",
		I2S_PollingTx,				"Polling Mode Data Out.",
		I2S_PollingFullDuplex,		"Polling Mode Bypass\n",	
		
		I2S_DMARx,				"DMA Mode Data In.",	
		I2S_DMATx,				"DMA Mode Data Out.",
		I2S_DMAFullDuplex,		"DMA Mode Bypass\n",	

		I2S_IntrRx,					"Interrupt Mode(RX Over Run) Data In.",	
		I2S_IntrTx,					"Interrupt Mode(TX Under Run) Data Out.\n",
		
		//I2S_LoopBackTest,			"LoopBack Test ",		
		//I2S_CodecRead,			"WM8990 Register Read Test\n",		
	    	0,0
	};
	//TestSFR();
	I2S_Init(AUDIO_PORT0);
	I2S_SetDMAUnit(AUDIO_PORT0, DMA0);
	
	I2S_Init(AUDIO_PORT1);
	I2S_SetDMAUnit(AUDIO_PORT1, DMA1);
	
	I2S_Init(AUDIO_PORT2);
	I2S_SetDMAUnit(AUDIO_PORT2, DMA0);
	while(1)
	{	
		I2S_DispTestInfor();
		UART_Printf("====================== I2S Function Test =======================================\n\n");
		UART_Printf("Current Control Port : Port %d\n",eSelPort);
		for (uCountFunc=0; (u32)(aI2STestFunc[uCountFunc].desc)!=0; uCountFunc++)
			UART_Printf("%2d: %s\n", uCountFunc, aI2STestFunc[uCountFunc].desc);	
		UART_Printf("\n%2d: Change Port\n",uCountFunc++);		
		UART_Printf("================================================================================\n");			
		UART_Printf("\nSelect the function to test : ");
		
		iSel =UART_GetIntNum();		
		UART_Printf("\n");
		
		if(iSel == 0) 
			break;
		if (iSel>0 && iSel<(sizeof(aI2STestFunc)/8-1))
			(aI2STestFunc[iSel].func) (eSelPort);
		else if ( iSel == (sizeof(aI2STestFunc)/8-1))			
			eSelPort = I2S_ChangePort();	
	}	
	I2S_ClosePort(AUDIO_PORT0);
	I2S_ClosePort(AUDIO_PORT1);	
}

//////////
// Function Name : I2S_PollingRx
// Function Description : 
//   This function test I2S RX Interface using ARM Transfer.
// Input : ePort - Audio Controller Number
// Output : NONE
// Version : 
void I2S_PollingRx(AUDIO_PORT ePort)
{
	I2S_Infor *pInfor = I2S_GetInfor(ePort);	
	u32 uFIFOTriggerLevel = 0x8;	//for Debug	
	s32 uBufferCnt;
	u32 uData;
	
	I2S_InitPort(ePort);
	I2SMOD_SetMode(ePort, pInfor->m_eWordLength, pInfor->m_eCLKSRC, pInfor->m_eIFMode, pInfor->m_eOpMode, pInfor->m_eLRCLKPolarity, pInfor->m_eDataFormat, pInfor->m_eRFS, pInfor->m_eBFS);
	I2S_SetCDCLKOut(ePort, pInfor->m_eCLKSRC, pInfor->m_uSamplingRate, pInfor->m_eRFS);						//Acrivate I2S Interface to clock out I2SCDCLK
	I2S_InitBuffer(ePort, RXOnly, pInfor->m_pI2SRxAddr, pInfor->m_sI2SRxSize);
	I2S_InitCodecDataIn(ePort, pInfor->m_uCodec, pInfor->m_eLine);
	UART_Printf("Now Record...\n");	
	I2SFIC_AutoFlush(ePort, RXOnly);			//FIFO Flush
	I2SMOD_SetInterface(ePort, RXOnly);
	I2SCON_ActiveIF(ePort, ACTIVE);			//IIS IF ACTIVE
	I2SCON_PauseIF(ePort, RXOnly,  PLAY);	//I2S RX IF no Pause
	do
	{
		do 
		{			
		} while (I2SFIC_GetFIFOLevel(ePort, RXOnly) < uFIFOTriggerLevel);		// Rx FIFO Level check
		while(1)
		{
			uData = I2SRXD_GetData(ePort);									//Data Transfer	
			uBufferCnt = I2S_PutDataMem(ePort, RXOnly, &uData);
			if (I2SCON_ChkFIFOEmpty(ePort, RXOnly))
				break;
		}
	}while( uBufferCnt > 0 );	
	UART_Printf("Data Receive Done\n");	
	I2SCON_PauseIF(ePort, RXOnly, PAUSE);				//RX IF Pause
	I2SCON_ActiveIF(ePort, INACTIVE);					//IF Inactive	
	I2SFIC_AutoFlush(ePort, RXOnly);						//FIFO FLUSH
	I2S_ClosePort(ePort);
	#if 0
	Parser_32to24(pInfor->m_pI2SRxAddr, pInfor->m_sI2STxSize, (u32 *)0x53400000);
	#endif
	
}

//////////
// Function Name : I2S_PollingTx
// Function Description : 
//   This function test I2S TX Interface using ARM Transfer.
// Input : ePort - Audio Controller Number
// Output : NONE
// Version : 
void I2S_PollingTx(AUDIO_PORT ePort)
{
	I2S_Infor *pInfor = I2S_GetInfor(ePort);		
	u32 uData;
	u32 uFIFOTriggerLevel = 0x8;		
	s32 uBufferCnt;

	I2S_InitPort(ePort);
	I2SMOD_SetMode(ePort, pInfor->m_eWordLength, pInfor->m_eCLKSRC, pInfor->m_eIFMode, pInfor->m_eOpMode, pInfor->m_eLRCLKPolarity, pInfor->m_eDataFormat, pInfor->m_eRFS, pInfor->m_eBFS);
	I2S_SetCDCLKOut(ePort, pInfor->m_eCLKSRC, pInfor->m_uSamplingRate, pInfor->m_eRFS);						//Acrivate I2S Interface to clock out I2SCDCLK
	I2S_InitCodecDataOut(ePort, pInfor->m_uCodec, pInfor->m_eLine);
	UART_Printf("Now Play...\n");	
	I2S_InitBuffer(ePort, TXOnly, pInfor->m_pI2STxAddr, pInfor->m_sI2STxSize);
	I2SFIC_AutoFlush(ePort, TXOnly);			//FIFO Flush	
	I2SMOD_SetInterface(ePort, TXOnly);	//Set interface mode of I2SMOD 
	I2SCON_ActiveIF(ePort, ACTIVE);			//
	I2SCON_PauseIF(ePort, TXOnly,  PLAY);	//I2S RX IF no Pause
	do
	{
		while(1)
		{
			uBufferCnt = I2S_PopDataMem(ePort, TXOnly, &uData);
			I2STXD_PutData(ePort, uData);
			if (I2SCON_ChkFIFOFull(ePort, TXOnly))
				break;
		}		
		do 
		{			
		} while (I2SFIC_GetFIFOLevel(ePort, TXOnly) > uFIFOTriggerLevel);		// TX FIFO Level check
	}while(uBufferCnt > 0);	
	UART_Printf("Play Done~\n");	
	I2SCON_PauseIF(ePort, TXOnly, PAUSE);				//RX IF Pause
	I2SCON_ActiveIF(ePort, INACTIVE);					//IF Inactive		
	I2S_ClosePort(ePort);
}


//////////
// Function Name : I2S_PollingFullDuplex
// Function Description : 
//   This function test I2S RX and TX Interface using ARM Transfer at same time
// Input : ePort - Audio Controller Number
// Output : NONE
// Version : 
void I2S_PollingFullDuplex(AUDIO_PORT ePort)
{
	I2S_Infor *pInfor = I2S_GetInfor(ePort);	
	u32 uRxFifoTriggerLevel = 0xf;
	u32 uTxFifoTriggerLevel = 0x1;
	u32 uPollingDelay = 0x10000 * 4;
	I2S_InitPort(ePort);
	I2SMOD_SetMode(ePort, pInfor->m_eWordLength, pInfor->m_eCLKSRC, pInfor->m_eIFMode, pInfor->m_eOpMode, pInfor->m_eLRCLKPolarity, pInfor->m_eDataFormat, pInfor->m_eRFS, pInfor->m_eBFS);
	I2S_InitCodecFullDuplex(ePort, pInfor->m_uCodec, pInfor->m_eLine);	
	UART_Printf("By Pass Start...\n");	
	I2SFIC_AutoFlush(ePort, TXRXBoth);		//FIFO Flush	
	I2SMOD_SetInterface(ePort, TXRXBoth);	//Set interface mode of I2SMOD 
	I2SCON_ActiveIF(ePort, ACTIVE);			//IIS IF ACTIVE
	I2SCON_PauseIF(ePort, TXRXBoth, PLAY);	//I2S RX IF no Pause
	do
	{
		do 
		{			
		} while ((I2SFIC_GetFIFOLevel(ePort, RXOnly) < uRxFifoTriggerLevel) || (I2SFIC_GetFIFOLevel(ePort, TXOnly) > uTxFifoTriggerLevel));		// Rx FIFO Level check
		do
		{
			I2STXD_PutData(ePort, I2SRXD_GetData(ePort));			
		}while ((I2SCON_ChkFIFOEmpty(ePort, RXOnly)) || I2SCON_ChkFIFOFull(ePort, TXOnly));		// Tx FIFO Level check
		uPollingDelay--;
	}while( uPollingDelay != 0 );
	UART_Printf("By Pass End.\n");	
	I2SCON_PauseIF(ePort, TXRXBoth, PAUSE);			//TX, RX IF Pause
	I2SCON_ActiveIF(ePort, INACTIVE);					//IF Inactive	
	I2S_ClosePort(ePort);
}


//////////
// Function Name : I2S_DMARx
// Function Description : 
//   This function test I2S RX Interface using DMA Transfer.
// Input : ePort - Audio Controller Number
// Output : NONE
// Version : 
void I2S_DMARx(AUDIO_PORT ePort)
{
	u8 ucChar=0;
	I2S_Infor *pInfor = I2S_GetInfor(ePort);	
	UART_Printf("Supply Sound to I2S CODEC via Line In Connector.\n");
	UART_Printf("Press any key to record.\n");
	UART_Getc();
	UART_Printf("Recording...\n");
	I2S_InitPort(ePort);
	I2SMOD_SetMode(ePort, pInfor->m_eWordLength, pInfor->m_eCLKSRC, pInfor->m_eIFMode, pInfor->m_eOpMode, pInfor->m_eLRCLKPolarity, pInfor->m_eDataFormat, pInfor->m_eRFS, pInfor->m_eBFS);
	I2S_SetCDCLKOut(ePort, pInfor->m_eCLKSRC, pInfor->m_uSamplingRate, pInfor->m_eRFS);		// I2SCDCLK Out	
	I2S_InitCodecDataIn(ePort, pInfor->m_uCodec, pInfor->m_eLine);
	I2S_InitBuffer(ePort, RXOnly, pInfor->m_pI2SRxAddr, pInfor->m_sI2SRxSize);
	I2S_InitDMA(ePort, RXOnly);		
	INTC_SetVectAddr(pInfor->m_uNumDma ,Isr_I2SDmaDone);			// Stop DMA Controller	
	I2SMOD_SetInterface(ePort, RXOnly);	
	I2SFIC_AutoFlush(ePort, RXOnly);					//RX FIFO Flush	
	I2SMOD_SetInterface(ePort, RXOnly);			//Set interface mode of I2SMOD 
	I2SCON_ActiveIF(ePort, ACTIVE);					//IIS IF ACTIVE
	I2SCON_EnableIntr(ePort, I2S_RX, DISABLE);		//Disable RX Overrun Interrupt 
	I2SCON_PauseIF(ePort, RXOnly, PLAY);			//DMA Request Play	
	do 
	{			
	} while (I2SCON_ChkFIFOEmpty(ePort, RXOnly));	//Rx FIFO Empty check
	I2SCON_ActiveDMA(ePort, RXOnly, ACTIVE);		//Enable RX DMA
	I2SCON_PauseDMA(ePort, RXOnly, PLAY);			//Play DMA Request
	UART_Printf("DMA Pause : P, DMA Play O\n");
	UART_Printf("TX Interface Pause : L, Interface Play : K\n");
	UART_Printf("I2S Interface Pause : I, Play : U\n");		
	I2S_SetIntrDone(ePort, RXOnly, FALSE);
	while(I2S_GetIntrDone(ePort,  RXOnly) == FALSE)    	
	{
        	ucChar = UART_Getc();
		if ((ucChar == 'p') | (ucChar == 'P'))
		{
			I2SCON_PauseDMA(ePort, RXOnly, PAUSE);
			UART_Printf("DMA PAUSE!!\n");				
		}
		else if ((ucChar == 'o') | (ucChar == 'O'))
		{
			I2SCON_PauseDMA(ePort, RXOnly, PLAY);
			UART_Printf("DMA PLAY!!\n");
		}
		else if ((ucChar == 'l') | (ucChar == 'L'))
		{
			I2SCON_PauseIF(ePort, RXOnly, PAUSE);
			UART_Printf("TX Interface PAUSE!!\n");
		}
		else if ((ucChar == 'k') | (ucChar == 'K'))
		{
			I2SCON_PauseIF(ePort, RXOnly, PLAY);
			UART_Printf("TX Interface PLAY!!\n");
		}
		else if ((ucChar == 'i') | (ucChar == 'I'))
		{
			I2SCON_ActiveIF(ePort,  false);
			UART_Printf("Interface Off\n");
		}
		else if ((ucChar == 'u') | (ucChar == 'U'))
		{
			I2SCON_ActiveIF(ePort,  true);
			UART_Printf("Interface On\n");
		}		
		if ( I2SCON_ChkFIFOFull(ePort, TXOnly) )
			Disp("TX Fifo Full!!\n");
		if ( I2SCON_ChkFIFOEmpty(ePort, TXOnly) )
			Disp("TX Fifo Empty!!\n");
		if ( I2SCON_ChkFIFOFull(ePort, RXOnly) )
			Disp("RX Fifo Full!!\n");
		if ( I2SCON_ChkFIFOEmpty(ePort, RXOnly) )
			Disp("RX Fifo Empty!!\n");
	}	
	I2S_DMAStop(ePort, RXOnly);
	INTC_Disable(pInfor->m_uNumDma);				//Disble Interrupt 
	I2SCON_ActiveDMA(ePort, RXOnly, INACTIVE);		//Disble RX DMA
	I2SCON_PauseIF(ePort, RXOnly, INACTIVE);		//DMA Request Pause		
	I2SCON_ActiveIF(ePort, INACTIVE);				//Inactivate I2S I/F
	I2SFIC_AutoFlush(ePort, RXOnly);					//FIFO FLUSH	
	I2S_ClosePort(ePort);
}

//////////
// Function Name : I2S_DMATx
// Function Description : 
//   This function test I2S TX Interface using DMA Transfer.
// Input : ePort - Audio Controller Number
// Output : NONE
// Version : 
void I2S_DMATx(AUDIO_PORT ePort)
{
	I2S_Infor *pInfor = I2S_GetInfor(ePort);	
	u8 ucChar;
	UART_Printf("\nPlay Wave File.\n");	
	I2S_InitPort(ePort);
	I2SMOD_SetMode(ePort, pInfor->m_eWordLength, pInfor->m_eCLKSRC, pInfor->m_eIFMode, pInfor->m_eOpMode, pInfor->m_eLRCLKPolarity, pInfor->m_eDataFormat, pInfor->m_eRFS, pInfor->m_eBFS);
	I2S_SetCDCLKOut(ePort, pInfor->m_eCLKSRC, pInfor->m_uSamplingRate, pInfor->m_eRFS);		// I2SCDCLK Out		
	I2S_InitCodecDataOut(ePort, pInfor->m_uCodec, pInfor->m_eLine);
	I2S_InitBuffer(ePort, TXOnly, pInfor->m_pI2STxAddr, pInfor->m_sI2STxSize);	
	I2S_InitDMA(ePort, TXOnly);
	INTC_SetVectAddr(pInfor->m_uNumDma ,Isr_I2SDmaRestart);	
	I2SFIC_AutoFlush(ePort, TXOnly);					//FIFO Flush	
	I2SMOD_SetInterface(ePort, TXOnly);			//TX Interface Mode	
	I2SCON_EnableIntr(ePort, I2S_TX, DISABLE);		//Disable I2S TXFIFO Underrun Interrupt
	
	I2SCON_ActiveDMA(ePort, TXOnly, ACTIVE);		//Active DMA request
	I2SCON_PauseDMA(ePort, TXOnly, PLAY);			//No Pause DMA Request	
	do
	{
	}while(I2SCON_ChkFIFOFull(ePort, TXOnly));		

	I2SCON_ActiveIF(ePort, ACTIVE);					//IIS IF ACTIVE	
	I2SCON_PauseIF(ePort, TXOnly, PLAY);			//Enable TX Interface	
	UART_Printf("\nIf you want to exit, Press the 'x' key.\n");
	UART_Printf("TX DMA Pause : P, TX DMA Play O\n");
	UART_Printf("TX Interface Pause : L, TX Interface Play : K\n");
	UART_Printf("I2S Port Interface Pause : I, I2S Port Interface Pause : U\n");
	while(1)
	{		
		ucChar = UART_Getc();
		if((ucChar == 'x') | (ucChar == 'X')) 
			break;
		else if ((ucChar == 'p') | (ucChar == 'P'))
		{
			I2SCON_PauseDMA(ePort, TXOnly, PAUSE);
			UART_Printf("TX DMA PAUSE!!\n");				
		}
		else if ((ucChar == 'o') | (ucChar == 'O'))
		{
			I2SCON_PauseDMA(ePort, TXOnly, PLAY);
			UART_Printf("TX DMA PLAY!!\n");
		}
		else if ((ucChar == 'l') | (ucChar == 'L'))
		{
			I2SCON_PauseIF(ePort, TXOnly, PAUSE);
			UART_Printf("TX Interface PAUSE!!\n");
		}
		else if ((ucChar == 'k') | (ucChar == 'K'))
		{
			I2SCON_PauseIF(ePort, TXOnly, PLAY);
			UART_Printf("TX Interface PLAY!!\n");
		}
		else if ((ucChar == 'i') | (ucChar == 'I'))
		{
			I2SCON_ActiveIF(ePort,  false);
			UART_Printf("Interface Off\n");
		}
		else if ((ucChar == 'u') | (ucChar == 'U'))
		{
			I2SCON_ActiveIF(ePort,  true);
			UART_Printf("Interface On\n");
		}
		if ( I2SCON_ChkFIFOFull(ePort, TXOnly) )
			Disp("TX Fifo Full!!\n");
		if ( I2SCON_ChkFIFOEmpty(ePort, TXOnly) )
			Disp("TX Fifo Empty!!\n");
		if ( I2SCON_ChkFIFOFull(ePort, RXOnly) )
			Disp("RX Fifo Full!!\n");
		if ( I2SCON_ChkFIFOEmpty(ePort, RXOnly) )
			Disp("RX Fifo Empty!!\n");
	}		 
	I2S_DMAStop(ePort, TXOnly);
    	INTC_Disable(pInfor->m_uNumDma);				//Disble Interrupt 
	I2SCON_ActiveDMA(ePort, TXOnly, INACTIVE);		//Disble RX DMA
	I2SCON_PauseIF(ePort, TXOnly, INACTIVE);		//DMA Request Pause	
	I2SFIC_AutoFlush(ePort, TXOnly);					//FIFO FLUSH	
	I2S_ClosePort(ePort);
}


//////////
// Function Name : I2S_DMAFullDuplex
// Function Description : 
//   This function test I2S RX and TX Interface using DMA Transfe at same time..
// Input : ePort - Audio Controller Number
// Output : NONE
// Version : 
void I2S_DMAFullDuplex(AUDIO_PORT ePort)
{
	I2S_Infor *pInfor = I2S_GetInfor(ePort);	
	u8 ucChar;
	I2S_InitPort(ePort);
	I2SMOD_SetMode(ePort, pInfor->m_eWordLength, pInfor->m_eCLKSRC, pInfor->m_eIFMode, pInfor->m_eOpMode, pInfor->m_eLRCLKPolarity, pInfor->m_eDataFormat, pInfor->m_eRFS, pInfor->m_eBFS);
	I2S_SetCDCLKOut(ePort, pInfor->m_eCLKSRC, pInfor->m_uSamplingRate, pInfor->m_eRFS);		// I2SCDCLK Out	
	I2S_InitCodecFullDuplex(ePort, pInfor->m_uCodec, pInfor->m_eLine);
	
	I2S_InitBuffer(ePort, RXOnly, pInfor->m_pI2SRxAddr, pInfor->m_sI2SRxSize);
	I2S_InitDMA(ePort, RXOnly);
	INTC_SetVectAddr(pInfor->m_uNumDma ,Isr_I2SDmaRestart);	
	UART_Printf("Bypass Start\n");
	I2SMOD_SetInterface(ePort, TXRXBoth);
	I2SCON_ActiveIF(ePort, ACTIVE);					//IIS IF ACTIVE
	I2SFIC_AutoFlush(ePort, RXOnly);					//FIFO Flush		
	I2SCON_EnableIntr(ePort, I2S_RX, ENABLE);		//Disable I2S RXFIFO Overrun Interrupt
	I2SCON_PauseIF(ePort, TXRXBoth, PLAY);			//Enable TX Interface	
	do 
	{			
	} while (I2SCON_ChkFIFOEmpty(ePort, RXOnly));	//Rx FIFO Empty check
	I2SCON_ActiveDMA(ePort, RXOnly, ACTIVE);		//Enable RX DMA
	I2SCON_PauseDMA(ePort, RXOnly, PLAY);			//Play DMA Request
	
	Delay(3000);
	
	I2S_InitBuffer(ePort, TXOnly, pInfor->m_pI2SRxAddr, pInfor->m_sI2SRxSize);				//Same memory buffer with Rx
	I2S_InitDMA(ePort, TXOnly);
	I2SFIC_AutoFlush(ePort, TXOnly);					//FIFO Flush	
	I2SCON_EnableIntr(ePort, I2S_TX, ENABLE);		//Disable I2S TXFIFO Underrun Interrupt
	I2SCON_ActiveDMA(ePort, TXOnly, ACTIVE);		//Enable TX DMA
	I2SCON_PauseDMA(ePort, TXOnly, PLAY);			//Play DMA Request
	UART_Printf("\nIf you want to exit, Press the 'x' key.\n");
	UART_Printf("TX DMA Pause : P, TX DMA Play O\n");
	UART_Printf("TX Interface Pause : L, TX Interface Play : K\n");
	UART_Printf("I2S Port Interface Pause : I, I2S Port Interface Pause : U\n");
	while(1)
	{		
		ucChar = UART_Getc();
		if((ucChar == 'x') | (ucChar == 'X')) 
			break;
		else if ((ucChar == 'p') | (ucChar == 'P'))
		{
			I2SCON_PauseDMA(ePort, TXOnly, PAUSE);
			UART_Printf("TX DMA PAUSE!!\n");				
		}
		else if ((ucChar == 'o') | (ucChar == 'O'))
		{
			I2SCON_PauseDMA(ePort, TXOnly, PLAY);
			UART_Printf("TX DMA PLAY!!\n");
		}
		else if ((ucChar == 'l') | (ucChar == 'L'))
		{
			I2SCON_PauseIF(ePort, TXOnly, PAUSE);
			UART_Printf("TX Interface PAUSE!!\n");
		}
		else if ((ucChar == 'k') | (ucChar == 'K'))
		{
			I2SCON_PauseIF(ePort, TXOnly, PLAY);
			UART_Printf("TX Interface PLAY!!\n");
		}
		else if ((ucChar == 'i') | (ucChar == 'I'))
		{
			I2SCON_ActiveIF(ePort,  false);
			UART_Printf("Interface Off\n");
		}
		else if ((ucChar == 'u') | (ucChar == 'U'))
		{
			I2SCON_ActiveIF(ePort,  true);
			UART_Printf("Interface On\n");
		}
		if ( I2SCON_ChkFIFOFull(ePort, TXOnly) )
			Disp("TX Fifo Full!!\n");
		if ( I2SCON_ChkFIFOEmpty(ePort, TXOnly) )
			Disp("TX Fifo Empty!!\n");
		if ( I2SCON_ChkFIFOFull(ePort, RXOnly) )
			Disp("RX Fifo Full!!\n");
		if ( I2SCON_ChkFIFOEmpty(ePort, RXOnly) )
			Disp("RX Fifo Empty!!\n");
	}
	UART_Printf("Bypass Stop\n");
	I2S_DMAStop(ePort, RXOnly);
	I2S_DMAStop(ePort, TXOnly);
    	INTC_Disable(pInfor->m_uNumDma);				//Disble DMA Interrupt 
	I2SCON_ActiveDMA(ePort, TXRXBoth, INACTIVE);	//Disble RX DMA
	I2SCON_PauseIF(ePort, TXRXBoth, INACTIVE);		//DMA Request Pause	
	I2SFIC_AutoFlush(ePort, TXRXBoth);				//FIFO FLUSH		
	I2S_ClosePort(ePort);
}

//////////
// Function Name : I2S_IntrRx
// Function Description : 
//   This function test I2S RX Interface using ARM Transfer by I2S RX Overrun interrupt
// Input : ePort - Audio Controller Number
// Output : NONE
// Version : 
void I2S_IntrRx(AUDIO_PORT ePort)
{
	if ( ePort != AUDIO_PORT2)
	{
		I2S_Infor *pInfor = I2S_GetInfor(ePort);	
		u32 uData;
		
		UART_Printf("Supply Sound to I2S CODEC via Line In Connector.\n");
		UART_Printf("Press any key to record.\n");
		UART_Getc();	
		
		I2S_InitPort(ePort);
		I2SMOD_SetMode(ePort, pInfor->m_eWordLength, pInfor->m_eCLKSRC, pInfor->m_eIFMode, pInfor->m_eOpMode, pInfor->m_eLRCLKPolarity, pInfor->m_eDataFormat, pInfor->m_eRFS, pInfor->m_eBFS);
		I2S_SetCDCLKOut(ePort, pInfor->m_eCLKSRC, pInfor->m_uSamplingRate, pInfor->m_eRFS);						//Acrivate I2S Interface to clock out I2SCDCLK
		I2S_InitCodecDataIn(ePort, pInfor->m_uCodec, pInfor->m_eLine);

		I2SFIC_AutoFlush(ePort, RXOnly);			//FIFO Flush	
		I2SCON_ActiveIF(ePort, ACTIVE);			//IIS IF ACTIVE
		I2SCON_PauseIF(ePort, RXOnly,  PLAY);	//I2S RX IF no Pause
		I2SMOD_SetInterface(ePort, RXOnly);
		
		I2S_InitBuffer(ePort, RXOnly, pInfor->m_pI2SRxAddr, pInfor->m_sI2SRxSize);	
		while(1)
		{
			uData = I2SRXD_GetData(ePort);									//Data Transfer	
			I2S_PutDataMem(ePort, RXOnly, &uData);
			if (I2SCON_ChkFIFOEmpty(ePort, RXOnly))
				break;
		}
		Disp("Recording.......\n");
		I2SCON_ClrOverIntr(ePort);	
		INTC_ClearVectAddr();		
		INTC_SetVectAddr(NUM_I2S ,ISR_I2SOverrunTransfer);			
		INTC_Enable(NUM_I2S);	
		I2SCON_EnableIntr(ePort, I2S_RX, ENABLE);	
		I2S_SetIntrDone(ePort, RXOnly, FALSE);
		while(1)
		{
			if ( I2S_GetIntrDone(ePort, RXOnly) == TRUE)
				break;
		}
		Disp("Recording Done\n");
		INTC_Disable(NUM_I2S);	
		I2SCON_EnableIntr(ePort, I2S_RX, DISABLE);	
		I2SCON_PauseIF(ePort, RXOnly,  PAUSE);		//I2S RX IF Pause
		I2SCON_ActiveIF(ePort, INACTIVE);			//IIS IF ACTIVE		
		
		I2S_ClosePort(ePort);
	}
	else 
	{
		Disp("I2S Controller 2 is not suppoerted RX overrun Interrupt\n");
	}
}

//////////
// Function Name : I2S_IntrTx
// Function Description : 
//   This function test I2S TX Interface using ARM Transfer by I2S TX Underrun interrupt
// Input : ePort - Audio Controller Number
// Output : NONE
// Version : 
void I2S_IntrTx(AUDIO_PORT ePort)
{
	I2S_Infor *pInfor = I2S_GetInfor(ePort);	
	u32 uData;
	UART_Printf("\nListen to Sound via Speak Out Connector.\n");
	UART_Printf("Press any key to play.\n");
	UART_Getc();	

	I2S_InitPort(ePort);
	I2SMOD_SetMode(ePort, pInfor->m_eWordLength, pInfor->m_eCLKSRC, pInfor->m_eIFMode, pInfor->m_eOpMode, pInfor->m_eLRCLKPolarity, pInfor->m_eDataFormat, pInfor->m_eRFS, pInfor->m_eBFS);
	I2S_SetCDCLKOut(ePort, pInfor->m_eCLKSRC, pInfor->m_uSamplingRate, pInfor->m_eRFS);						//Acrivate I2S Interface to clock out I2SCDCLK
	I2S_InitCodecDataOut(ePort, pInfor->m_uCodec, pInfor->m_eLine);

	I2SFIC_AutoFlush(ePort, TXOnly);			//FIFO Flush	
	I2SCON_ActiveIF(ePort, ACTIVE);			//IIS IF ACTIVE
	I2SCON_PauseIF(ePort, TXOnly,  PLAY);	//I2S RX IF no Pause
	I2SMOD_SetInterface(ePort, TXOnly);

	I2S_InitBuffer(ePort, RXOnly, pInfor->m_pI2STxAddr, pInfor->m_sI2STxSize);	
	while(1)
	{
		I2S_PopDataMem(ePort, TXOnly, &uData);
		I2STXD_PutData(ePort, uData);									//Data Transfer			
		if (I2SCON_ChkFIFOFull(ePort, TXOnly))
			break;
	}
	Disp("Play.......\n");
	I2SCON_ClrUnderIntr(ePort);	
	INTC_ClearVectAddr();		
	INTC_SetVectAddr(NUM_I2S ,ISR_I2SUnderrunTransfer);			
	INTC_Enable(NUM_I2S);	
	I2SCON_EnableIntr(ePort, I2S_TX, ENABLE);	
	I2S_SetIntrDone(ePort, TXOnly, FALSE);

	while(1)
	{
		if ( I2S_GetIntrDone(ePort, TXOnly) == TRUE)
			break;
	}
	Disp("Recording Done\n");
	INTC_Disable(NUM_I2S);	
	I2SCON_EnableIntr(ePort, I2S_TX, DISABLE);	
	I2SCON_PauseIF(ePort, TXOnly,  PAUSE);		//I2S RX IF Pause
	I2SCON_ActiveIF(ePort, INACTIVE);			//IIS IF ACTIVE		
	
	I2S_ClosePort(ePort);
}
/*---------------------------------- Test Functions -------------------------------*/
//////////
// Function Name : I2S_LoopBackTest
// Function Description : 
//   This function implements I2S Loopback Test function.

//	To execute this test, SMDK6410 must be modified.
//	
//			J13						J13
//		pin3  (BCLK)			pin3  (BCLK)
//		pin7  (CDCLK)			pin7  (CDCLK)  --> These signal should be connected to R249.(Ext.Clock)
//		pin11(LRCK)				pin11(LRCK)
//		pin17(DI)				pin21(DO)
//		pin21(DO)				pin17(DI)
//		
//		Master - AUDIO_PORT0 (Master sends LRCK and BCLK to Slave port.)
//		Slave  - AUDIO_PORT1
//		CDCLK - External Clock
// Input : AUDIO_PORT : DO NOT USE
// Output : NONE
// Version : 
void I2S_LoopBackTest1(AUDIO_PORT ePort)
{
	#if 1
	AUDIO_PORT MasterPort, SlavePort;
	I2S_Infor *MasterInfor, *SlaveInfor;
	MasterPort = AUDIO_PORT0;
	SlavePort = AUDIO_PORT1;
	
	MasterInfor = I2S_GetInfor(MasterPort);
	SlaveInfor = I2S_GetInfor(SlavePort);

	I2S_InitPort(MasterPort);
	I2SMOD_SetMode(MasterPort, MasterInfor->m_eWordLength, MasterInfor->m_eCLKSRC, TXOnly, Master, MasterInfor->m_eLRCLKPolarity, MasterInfor->m_eDataFormat, MasterInfor->m_eRFS, MasterInfor->m_eBFS);
	I2S_SetCDCLKOut(MasterPort, MasterInfor->m_eCLKSRC, MasterInfor->m_uSamplingRate, MasterInfor->m_eRFS);						//Acrivate I2S Interface to clock out I2SCDCLK

	I2S_InitPort(SlavePort);
	I2SMOD_SetMode(SlavePort, SlaveInfor->m_eWordLength, I2S_EXTERNALCDCLK, RXOnly, Slave, SlaveInfor->m_eLRCLKPolarity, SlaveInfor->m_eDataFormat, SlaveInfor->m_eRFS, SlaveInfor->m_eBFS);
	I2S_SetCDCLKOut(SlavePort, SlaveInfor->m_eCLKSRC, MasterInfor->m_uSamplingRate, MasterInfor->m_eRFS);		

	I2S_InitBuffer(MasterPort, TXOnly, MasterInfor->m_pI2STxAddr, MasterInfor->m_sI2STxSize);	
	I2S_InitBuffer(SlavePort, RXOnly, SlaveInfor->m_pI2SRxAddr, SlaveInfor->m_sI2SRxSize);	

	I2S_SetIntrDone(SlavePort, RXOnly, FALSE) ;
	I2S_DmaStart(SlavePort, RXOnly, FALSE);
	I2S_DmaStart(MasterPort, TXOnly, FALSE);
	Disp("Master TX -> Slave RX\n");
	do
	{
		Disp(".");
		Delay(1000);
	}while(I2S_GetIntrDone(SlavePort, RXOnly) == FALSE);	
	
	
	#endif
}


void I2S_CodecRead(AUDIO_PORT ePort)
{
	u32 udata = WM8990_IICRead(0x00);
	Disp("%d\n",udata);
	Disp("%x\n",udata);
}

//--------------Test Configuration -----------------------//
//////////
// Function Name : I2S_DispTestInfor
// Function Description : 
//   This function diplay Test Information of I2S Controller
// Input : 	ePort ->  I2S Controller
// Output : None
// Version : 0.0
// Example 
void I2S_DispTestInfor(void)
{
	u32 uCountFunc;
	I2S_Infor* pInfor;	
	UART_Printf("========================I2S Controller Information================================\n");
	for (uCountFunc = 0; uCountFunc < I2S_CONNUM; uCountFunc++)
	{
		pInfor = I2S_GetInfor((AUDIO_PORT) uCountFunc);
		UART_Printf("Port : %d\t",uCountFunc);	

		UART_Printf("Audio Codec : ");
		if (pInfor->m_uCodec == AK2430 )			UART_Printf("AK2430");
		else if (pInfor->m_uCodec == WM9713 )	UART_Printf("WM9713");
		else if (pInfor->m_uCodec == WM8753 )	UART_Printf("WM8753");
		else if (pInfor->m_uCodec == STAC9767 )	UART_Printf("STAC9767");
		else if (pInfor->m_uCodec == WM8580 )	UART_Printf("WM8580");
		else if (pInfor->m_uCodec == WM8990 )	UART_Printf("WM8990");	
		Disp("\t");
		
		UART_Printf("Codec Port: ");
		if (pInfor->m_eLine == CodecPort_1st)		UART_Printf("Primary\n");
		else if (pInfor->m_eLine == CodecPort_2nd)	UART_Printf("Secondry\n");
		
		UART_Printf("Operation Mode : ");
		if (pInfor->m_eOpMode ==  Master)	UART_Printf("Master\t");
		else if (pInfor->m_eOpMode == Slave)	UART_Printf("Slave\t");		
		
		UART_Printf("PCM Word Length : ");
		if (pInfor->m_eWordLength ==  Word8)			UART_Printf("8bit\n");
		else if (pInfor->m_eWordLength ==  Word16)	UART_Printf("16bit\n");
		else if (pInfor->m_eWordLength ==  Word24)	UART_Printf("24bit\n");

		UART_Printf("Interface Data Format : ");
		if ( pInfor->m_eDataFormat ==  I2SFormat)			UART_Printf("I2S Format\t");
		else if ( pInfor->m_eDataFormat ==  MSBJustified)	UART_Printf("MSBJustified(Left)\t");
		else if ( pInfor->m_eDataFormat ==  LSBJustified)	UART_Printf("LSBJustified(Right)\t");
		
		UART_Printf("LRCLK Polarity : ");
		if ( pInfor->m_eLRCLKPolarity ==  LeftHigh)			UART_Printf("Left High\n");
		else if ( pInfor->m_eLRCLKPolarity ==  RightHigh)	UART_Printf("Right High\n");	

		UART_Printf("I2S Clock Source : ");
		if ( pInfor->m_eCLKSRC ==  I2S_MOUT_EPLL)			UART_Printf("EPLL Out\t");
		else if ( pInfor->m_eCLKSRC ==  I2S_PCLK)			UART_Printf("PCLK\t");
		else if ( pInfor->m_eCLKSRC ==  I2S_DOUT_MPLL)	UART_Printf("MPLL Out\t");
		else if ( pInfor->m_eCLKSRC ==  I2S_FIN)			UART_Printf("System External CLK\t");
		else if (pInfor->m_eCLKSRC ==  I2S_EXTERNALCDCLK)UART_Printf("I2S External CLK\t");
		
		UART_Printf("Sampling Frequency : %3.1fKHz\n",((double)(pInfor->m_uSamplingRate)/1000));
		
		UART_Printf("RFS : ");
		if ( I2SMOD_GetRFS((AUDIO_PORT) uCountFunc) ==  RFS_256fs)		UART_Printf("256fs\t");
		else if ( I2SMOD_GetRFS((AUDIO_PORT) uCountFunc) ==  RFS_512fs)	UART_Printf("512fs\t");
		else if ( I2SMOD_GetRFS((AUDIO_PORT) uCountFunc) ==  RFS_384fs)	UART_Printf("384fs\t");
		else if ( I2SMOD_GetRFS((AUDIO_PORT) uCountFunc) ==  RFS_768fs)	UART_Printf("768fs\t");	

		UART_Printf("BFS : ");
		if ( pInfor->m_eBFS ==  BFS_32fs)			UART_Printf("32fs\t");
		else if ( pInfor->m_eBFS ==  BFS_48fs)		UART_Printf("48fs\t");
		else if ( pInfor->m_eBFS ==  BFS_16fs)		UART_Printf("16fs\t");
		else if ( pInfor->m_eBFS ==  BFS_24fs)		UART_Printf("24fs\t");
		
		if ( uCountFunc == AUDIO_PORT2)
		{
			UART_Printf("DCE : ");
			if (pInfor->m_eDCE == I2S_Tx0)		Disp("TX 0");
			else if (pInfor->m_eDCE == I2S_Tx1)	Disp("TX 0, Tx1");
			else if (pInfor->m_eDCE == I2S_Tx2)	Disp("TX 0, Tx2");
			else if (pInfor->m_eDCE == I2S_AllTx)	Disp("TX 0, Tx1, Tx2");
			Disp("\n");
			Disp("Tx1 Fifo CDD : ");
			if (pInfor->m_eFifo1CDD == NoDiscard ) 		Disp("No discard");
			else if (pInfor->m_eFifo1CDD == Discard15to0) 	Disp("15 to 0");
			else if (pInfor->m_eFifo1CDD == Discard31to16) 	Disp("31 to 16");
			Disp("\t");
			Disp("Tx1 Fifo CDD : ");
			if (pInfor->m_eFifo2CDD == NoDiscard ) 		Disp("No discard");
			else if (pInfor->m_eFifo2CDD == Discard15to0) 	Disp("15 to 0");
			else if (pInfor->m_eFifo2CDD == Discard31to16) 	Disp("31 to 16");
		}
		UART_Printf("\n\n");			
	}

}

//////////
// Function Name : I2S_Configuration
// Function Description : 
//   This function Configurte Test condition of I2S Controller
// Input : 	ePort ->  I2S Controller
// Output : None
// Version : 0.0
// Example 
void I2S_Configuration(AUDIO_PORT ePort)
{
	u32 uCountFunc=0;
	s32 iSel=0;	
	const I2StestFuncMenu aI2SConfigFunc[] =
	{
		//SMDK Configuration
		I2SConf_Codec,		"Audio Codec\n",
		//BUFFER
		I2SConf_Addr,			"Buffer Address and Size\n",
		//DMA Controller for I2S
		I2SConf_SelDMAUnit,	"DMA Controller\n",		
		//Sample Frequency
		I2SConf_SampleRate,	"Sampling Frequency(LRCLK Freq)\n",		
		//I2S Function Test Item
		I2SConf_OPMode,		"Operation Mode ",	
		I2SConf_WordLength,	"PCM Word Length(BLC) ",	
		I2SConf_Interface,		"Open/Close Interface ",	
		I2SConf_LRPolarity,		"LRCLK Polarity.",	
		I2SConf_IFFormat,		"Interface Data Format",
		I2SConf_CLKSource,	"I2S CLK Source",		
		I2SConf_RFS,			"LRCLK Length(RFS)",
		I2SConf_BFS,			"Effective Data Length(BFS)\n",	
		I2SConf_DCE,			"Extension Tx Fifo Enable(Only I2S Controller2)",
		I2SConf_CDD,			"Extension Tx Fifo Channel Discard(Only I2S Controller2)",
		
	    	0,0
	};
	UART_Printf("\n\n================== I2S Configuration =====================\n\n");
	while(1)
	{
		for (uCountFunc=0; (u32)(aI2SConfigFunc[uCountFunc].desc)!=0; uCountFunc++)
			UART_Printf("%2d: %s\n", uCountFunc, aI2SConfigFunc[uCountFunc].desc);

		UART_Printf("\nSelect the function to test : ");
		iSel =UART_GetIntNum();
		UART_Printf("\n");
		if(iSel == -1)
		{
			break;
		}
		(aI2SConfigFunc[iSel].func) (ePort);
		
	}
}

//////////
// Function Name : I2SConf_WordLength
// Function Description : 
//   This function selects PCM Word Length
// Input : 	ePort ->  I2S Controller
// Output : None
// Version : 0.0
// Example 
AUDIO_PORT I2S_ChangePort(void)
{	
	AUDIO_PORT eSelPort;
	
	UART_Printf("Which Port do you controll?\n");
	UART_Printf("0. Port 0	1. Port 1 	2. Port 2\n");
	eSelPort = (AUDIO_PORT)UART_GetIntNum();
	if (eSelPort == 1)			return AUDIO_PORT1;
	else if (eSelPort == 0)		return AUDIO_PORT0;	
	else if (eSelPort == 2)		return AUDIO_PORT2;	
	else Assert('0');
}

//////////
// Function Name : I2SConf_Codec
// Function Description : 
//   This function configurate SMDK.
// Input : 	ePort ->  I2S Controller
// Output : None
// Version : 0.0
// Example 
// PCMConf_Addr(AUDIO_PORT1);
void I2SConf_Codec(AUDIO_PORT ePort)
{
	s32 uSelection;
	do
	{
		UART_Printf("Select Audio Codec for I2S I/F\n");
		UART_Printf("0: AK2430	1: WM9713	2: WM8753	3: STAC9767	4: WM8580	5: WM8990\n");
		uSelection = UART_GetIntNum();
	}while(!(uSelection >= 0 && uSelection <= 5));	
	I2S_GetInfor(ePort)->m_uCodec = (AudioCodec) uSelection;
	if (uSelection == AK2430  || uSelection == STAC9767)		I2S_GetInfor(ePort)->m_eLine = CodecPort_1st;
	else if (uSelection == WM9713)						I2S_GetInfor(ePort)->m_eLine = CodecPort_2nd;
	else if ( uSelection == WM8753  || uSelection == WM8990 || uSelection == WM8580)
	{
		do
		{
			UART_Printf("Select Audio Codec for I2S I/F\n");
			UART_Printf("0: PAIF		1: SAIF\n");
			uSelection = UART_GetIntNum();
		}while(!(uSelection >= 0 && uSelection <= 1));	
		I2S_GetInfor(ePort)->m_eLine = (CodecPort) uSelection;
	}
}

//////////
// Function Name : I2SConf_Addr
// Function Description : 
//   This function set Buffer Address.
// Input : 	None
// Output : None
// Version : 0.0
// Example 
// PCMConf_Addr(AUDIO_PORT1);
void I2SConf_Addr(AUDIO_PORT ePort)
{
	s32 sChSel;
	u32 uTempAddr;
	s32 uTempSize;
	I2S_Infor *pInfor = I2S_GetInfor(ePort);
	do
	{
		UART_Printf("Select Interface Channel\n");
		UART_Printf("0: RX	1: TX \n");
		sChSel = UART_GetIntNum();
	}while(!(sChSel >= 0 && sChSel <= 1));	
	UART_Printf("Enter the new temporary address(0x...):");
	uTempAddr = (u32) UART_GetIntNum();
	if ( uTempAddr == 0xffffffff )
		uTempAddr = 0x5100002c;
	UART_Printf("Enter the new size that is multiple of 4(0x4 ~ 0xfffff):");
	uTempSize = (u32) UART_GetIntNum();
	if ( uTempSize < 0x4 ||  uTempSize > 0xfffff )
		uTempSize = 0xfffff;	
	uTempSize = (uTempSize / 4) * 4;
	if ( sChSel == 0 )		 	// MIC-In
	{
		pInfor->m_pI2SRxAddr= (u32 *)uTempAddr;
		pInfor->m_sI2SRxSize= (s32) uTempSize;
	}
	else if ( sChSel == 1 )	 // PCM-In
	{
		pInfor->m_pI2STxAddr = (u32 *)uTempAddr;
		pInfor->m_sI2STxSize = (s32) uTempSize;
	}
	else 
		Assert(0);
		
}


//////////
// Function Name : I2SConf_WordLength
// Function Description : 
//   This function selects PCM Word Length
// Input : 	ePort ->  I2S Controller
// Output : None
// Version : 0.0
// Example 
void I2SConf_WordLength(AUDIO_PORT ePort)
{
	s8 usSelection;
	UART_Printf("Select Word Length\n");
	do{
		
		UART_Printf("0. 16bit		1. 8bit		2. 24bit\n");
		usSelection = UART_GetIntNum();
	}while(!(usSelection >= 0 && usSelection <=2));	
	I2S_GetInfor(ePort)->m_eWordLength = (PCMWordLength) usSelection;
}


//////////
// Function Name : I2SConf_CLKSource
// Function Description : 
//   This function selects clock source(RCLK)
// Input : 	ePort ->  I2S Controller
// Output : None
// Version : 0.0
// Example 
// Example 
// I2SConf_CLKSource(AUDIO_PORT1);
void I2SConf_CLKSource(AUDIO_PORT ePort)
{
	s32 uSelection;
	do
	{
		UART_Printf("Select Serial Data Format\n");
		UART_Printf("0. EPLL		1. MPLL		2. System Clock(Fin of Syscon)\n");
		UART_Printf("3. External Codec CLK	4. PCLK\n");
		uSelection = UART_GetIntNum();
	}while(uSelection < 0 || uSelection > 4);	
	I2S_GetInfor(ePort)->m_eCLKSRC= (I2S_CLKSRC) uSelection;
}


//////////
// Function Name : I2SConf_Interface
// Function Description : 
//   This function selects channel
// Input : 	ePort ->  I2S Controller
// Output : None
// Version : 0.0
// Example 
// Example 
// I2SConf_Interface(AUDIO_PORT1);
void I2SConf_Interface(AUDIO_PORT ePort)
{
	s32 uSelection;
	do{
		UART_Printf("Select Interface\n");
		UART_Printf("0. TX Only		1. RX Only	2. TX_RX Simultaneously\n");
		uSelection = UART_GetIntNum();
	}while(uSelection < 0 || uSelection > 2);
	I2S_GetInfor(ePort)->m_eIFMode = (I2S_IFMode) uSelection;
}

//////////
// Function Name : I2SConf_OPMode
// Function Description : 
//   This function selects operation Mode of I2S Controller
// Input : 	ePort ->  I2S Controller
// Output : None
// Version : 0.0
// Example 
// I2SConf_OPMode(AUDIO_PORT1);
void I2SConf_OPMode(AUDIO_PORT ePort)
{
	s32 uSelection;
	do{
		UART_Printf("Select Opeation Mode\n");
		UART_Printf("0. Maseter		1. Slave\n");
		uSelection = UART_GetIntNum();
	}while(!(uSelection >= 0 && uSelection <= 1));
	I2S_GetInfor(ePort)->m_eOpMode = (OPMode) uSelection;
}

//////////
// Function Name : I2SConf_LRPolarity
// Function Description : 
//   This function selects LRCLK Porality
// Input : 	ePort ->  I2S Controller
// Output : None
// Version : 0.0
// Example 
// I2SConf_LRPolarity(AUDIO_PORT1);
void I2SConf_LRPolarity(AUDIO_PORT ePort)
{
	s32 uSelection;
	do
	{
		UART_Printf("Select LRCLK Polarity\n");
		UART_Printf("1. Right High		2. Left High\n");
		uSelection = UART_GetIntNum();
	}while(!(uSelection >= 0 && uSelection <= 1));
	I2SMOD_SetLRPolarity(ePort, (I2S_LRCLKPolarity)uSelection);
	I2S_GetInfor(ePort)->m_eDataFormat= (SerialDataFormat) uSelection;
}

//////////
// Function Name : I2SConf_IFFormat
// Function Description : 
//   This function selects Interface Format
// Input : 	ePort ->  I2S Controller
// Output : None
// Version : 0.0
// Example 
// I2SConf_IFFormat(AUDIO_PORT1);
void I2SConf_IFFormat(AUDIO_PORT ePort)
{
	s32 uSelection;
	do{
		UART_Printf("Select Serial Data Format\n");
		UART_Printf("0. IIS Format		1. MSB Justified	2. LSB Justified\n");
		uSelection = UART_GetIntNum();
	}while(!(uSelection >= 0 && uSelection <= 2));	
	I2S_GetInfor(ePort)->m_eDataFormat= (SerialDataFormat) uSelection;
}


//////////
// Function Name : I2SConf_RFS
// Function Description : 
//   This function selects RFS
// Input : 	ePort ->  I2S Controller
// Output : None
// Version : 0.0
// Example 
// I2SConf_RFS(AUDIO_PORT1);
void I2SConf_RFS(AUDIO_PORT ePort)
{
	s32 uSelection;
	do{
		UART_Printf("Select LRCLK Length(RFS)\n");
		UART_Printf("0. 16bit(256fs)		1. 32bit(512fs)		2. 12bit(384fs)		3. 24bit(768fs)\n");
		uSelection = UART_GetIntNum();
	}while(!(uSelection >= 0 && uSelection <= 3));
	I2S_GetInfor(ePort)->m_eRFS = (I2S_RFS) uSelection;
}
//////////
// Function Name : I2SConf_BFS
// Function Description : 
//   This function selects BFS
// Input : 	ePort ->  I2S Controller
// Output : None
// Version : 0.0
// Example 
// I2SConf_BFS(AUDIO_PORT1);
void I2SConf_BFS(AUDIO_PORT ePort)
{
	s32 uSelection;
	do{
		UART_Printf("Select LRCLK Length(RFS)\n");
		UART_Printf("0. 16bit(32fs)		1. 24bit(48fs)		2. 8bit(16fs)		3. 12bit(24fs)\n");
		uSelection = UART_GetIntNum();
	}while(!(uSelection >= 0 && uSelection <= 3));
	I2S_GetInfor(ePort)->m_eBFS = (I2S_BFS) uSelection;
	
}

//////////
// Function Name : I2SConf_DCE
// Function Description : 
//   This function selects BFS
// Input : 	ePort ->  I2S Controller
// Output : None
// Version : 0.0
// Example 
// I2SConf_BFS(AUDIO_PORT1);
void I2SConf_DCE(AUDIO_PORT ePort)
{
	if ( ePort == AUDIO_PORT2 )
	{
		s32 uSelection;
		do{
			UART_Printf("Select DCE (Extention TX FIFO Enable)\n");
			UART_Printf("0. Diable 	1. Fifo1		2. Fifo2		3. Fifo1 & 2\n");
			uSelection = UART_GetIntNum();
		}while(!(uSelection >= 0 && uSelection <= 3));
		I2S_GetInfor(ePort)->m_eDCE = (I2S_DCE) uSelection;
	}
	else 
	{
		Disp("I2S 2 (Multichannel Only Support!!\n");
	}
	
}

//////////
// Function Name : I2SConf_DCE
// Function Description : 
//   This function selects BFS
// Input : 	ePort ->  I2S Controller
// Output : None
// Version : 0.0
// Example 
// I2SConf_BFS(AUDIO_PORT1);
void I2SConf_CDD(AUDIO_PORT ePort)
{
	if ( ePort == AUDIO_PORT2 )
	{
		s32 uSelection;
		do{
			UART_Printf("Select CDD (Extention TX FIFO Enable)\n");
			UART_Printf("0. Diable 	1. Fifo1		2. Fifo2		3. Fifo1 & 2\n");
			uSelection = UART_GetIntNum();
		}while(!(uSelection >= 0 && uSelection <= 3));
		I2S_GetInfor(ePort)->m_eDCE = (I2S_DCE) uSelection;
	}
	else 
	{
		Disp("I2S 2 (Multichannel Only Support!!\n");
	}
	
}

//////////
// Function Name : I2SConf_SampleRate
// Function Description : 
//   This function selects SampleRate
// Input : 	ePort ->  I2S Controller
// Output : None
// Version : 0.0
// Example 
// I2SConf_SampleRate(AUDIO_PORT1);
void I2SConf_SampleRate(AUDIO_PORT ePort)
{
	I2S_Infor* pInfor = I2S_GetInfor(ePort);
	u32 uSampleRate = 48000;
	do{
		Disp("Enter Sample Rate : ");
		uSampleRate = UART_GetIntNum();
	}while(!(uSampleRate >= 8000 && uSampleRate <= 192000));
	pInfor->m_uSamplingRate = uSampleRate;
}

//////////
// Function Name : I2SConf_SelDMAUnit
// Function Description : 
//   This function selects DMA Controller
// Input : 	ePort ->  I2S Controller
// Output : None
// Version : 0.0
// Example 
// I2SConf_SelDMAUnit(AUDIO_PORT1);
void I2SConf_SelDMAUnit(AUDIO_PORT ePort)
{	
	s32 uSelection;
	I2S_Infor *pInfor = I2S_GetInfor(ePort);
	do{
		UART_Printf("Select DMA\n");
		UART_Printf("0. Normal DMA		1. Secure DMA\n");
		uSelection = UART_GetIntNum();
	}while(!(uSelection >= 0 && uSelection <= 1));
	
	if ( uSelection == 0 )
		I2S_SetDMAUnit(ePort, (DMA_UNIT)((u32) DMA0 + (u32)ePort));	
	else	
		I2S_SetDMAUnit(ePort, (DMA_UNIT)((u32) SDMA0 + (u32)ePort));	
}

//---------------------------------------------Audio Codec API--------------------------//
//////////
// Function Name : I2S_InitCodecDataIn
// Function Description : This function initialieze Audio Codec(ADC) to give Data to I2S I/F.
// Input : 	ePort - I2S Port Number 
// 			uCodecId - Codec ID
// 			eCodecPort - Codec I/F Port
// Output :	None
// Version : v0.0
void I2S_InitCodecDataIn(AUDIO_PORT ePort, u32 uCodecId, CodecPort eCodecPort)
{
	I2S_Infor* pInfor = I2S_GetInfor(ePort);
	if (uCodecId == WM8753)
		WM8753_CodecInitPCMIn(pInfor->m_eDataFormat, pInfor->m_uSamplingRate, pInfor->m_eOpMode,  pInfor->m_eWordLength, LINEIN, eCodecPort);
	else if (uCodecId == WM8990)
		WM8990_CodecInitPCMIn(pInfor->m_eDataFormat, pInfor->m_uSamplingRate, pInfor->m_eOpMode,  pInfor->m_eWordLength, LINEIN, eCodecPort);
	else if (uCodecId == WM8580)
		WM8580_CodecInitPCMIn(pInfor->m_eDataFormat, pInfor->m_uSamplingRate, pInfor->m_eOpMode,  pInfor->m_eWordLength, LINEIN, eCodecPort);
	else
	{
		Disp("This test code does not support this code\n");
		Assert(0);
	}
}

//////////
// Function Name : I2S_InitCodecDataOut
// Function Description : This function initialieze Audio Codec(DAC) to take Data to I2S I/F.
// Input : 	ePort - I2S Port Number 
// 			uCodecId - Codec ID
// 			eCodecPort - Codec I/F Port
// Output :	None
// Version : v0.0
void I2S_InitCodecDataOut(AUDIO_PORT ePort, u32 uCodecId, CodecPort eCodecPort)
{
	I2S_Infor* pInfor = I2S_GetInfor(ePort);
	if (uCodecId == WM8753)
		WM8753_CodecInitPCMOut(pInfor->m_eDataFormat, (u32) pInfor->m_uSamplingRate, pInfor->m_eOpMode,  pInfor->m_eWordLength, eCodecPort);
	else if (uCodecId == WM8990)
		WM8990_CodecInitPCMOut(pInfor->m_eDataFormat, (u32) pInfor->m_uSamplingRate, pInfor->m_eOpMode,  pInfor->m_eWordLength, eCodecPort);
	else if (uCodecId == WM8580)
		WM8580_CodecInitPCMOut(pInfor->m_eDataFormat, (u32) pInfor->m_uSamplingRate, pInfor->m_eOpMode,  pInfor->m_eWordLength, eCodecPort);
	else
	{
		Disp("This test code does not support this code\n");
		Assert(0);
	}
}

//////////
// Function Name : I2S_InitCodecFullDuplex
// Function Description : This function initialieze Audio Codec(DAC) to take Data to I2S I/F.
// Input : 	ePort - I2S Port Number 
// 			uCodecId - Codec ID
// 			eCodecPort - Codec I/F Port
// Output :	None
// Version : v0.0
void I2S_InitCodecFullDuplex(AUDIO_PORT ePort, u32 uCodecId, CodecPort eCodecPort)
{
	I2S_Infor* pInfor = I2S_GetInfor(ePort);
	if (uCodecId == WM8753)
		WM8753_CodecInitPCMIn(pInfor->m_eDataFormat, pInfor->m_uSamplingRate, pInfor->m_eOpMode,  pInfor->m_eWordLength, LINEIN, eCodecPort);
	else if (uCodecId == WM8990)
		WM8990_CodecInitFullDuplex(pInfor->m_eDataFormat, pInfor->m_uSamplingRate, pInfor->m_eOpMode,  pInfor->m_eWordLength, LINEIN, eCodecPort);
	else if (uCodecId == WM8580)
		WM8580_CodecInitPCMIn(pInfor->m_eDataFormat, pInfor->m_uSamplingRate, pInfor->m_eOpMode,  pInfor->m_eWordLength, LINEIN, eCodecPort);
	else
	{
		Disp("This test code does not support this code\n");
		Assert(0);
	}
}


