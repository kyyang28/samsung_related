/**************************************************************************************
* 
*	Project Name : S3C6410 Validation
*
*	Copyright 2008 by Samsung Electronics, Inc.
*	All rights reserved.
*
*	Project Description :
*		This software is only for validating functions of the S3C6410.
*		Anybody can use this software without our permission.
*  
*--------------------------------------------------------------------------------------
* 
*	File Name : audio.c
*  
*	File Description : This file implements various audio codec Initailization.
*
*	Author : Sunghyun,Na
*	Dept. : AP Development Team
*	Created Date : 2008/03/03
*	Version : 0.2 
* 
*	History
*	- 0. Created(Sunghyun,Na 2008/03/03)		
*   
**************************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "audio.h"
#include "def.h"
#include "option.h"
#include "library.h"
#include "sfr6410.h"
#include "system.h"
#include "intc.h"
#include "gpio.h"

#include "iic.h"
#include "ac97.h"


//////////
// Function Name : Audio_InitIICPort
// Function Desctiption : This function set GPIO port B to IIC.
// Input : None
// Output : None
// Version : 0.0
// Author : Sung-Hyun, Na
void Audio_InitIICPort(void)
{
	// Set I2C Port
	GPIO_SetPullUpDownEach(eGPIO_B, eGPIO_5, 0);	// Set GPIO PortB pull-up/down disable
	GPIO_SetPullUpDownEach(eGPIO_B, eGPIO_6, 0);	// Set GPIO PortB pull-up/down disable
	GPIO_SetFunctionEach(eGPIO_B, eGPIO_5, 2);		// Set GPIO PortB as I2C SCL
	GPIO_SetFunctionEach(eGPIO_B, eGPIO_6, 2);		// Set GPIO PortB as I2C SDA
}

//////////
// Function Name : Audio_InitIIC
// Function Desctiption : This function initialize IIC Interface.
// Input : None
// Output : None
// Version : 0.0
// Author : Sung-Hyun, Na
void Audio_InitIIC(void)
{
	INTC_SetVectAddr(NUM_IIC,Isr_IIC);
	INTC_Enable(NUM_IIC);	
	IIC_Open(AUDIO_IICCLK);
}

//////////
// Function Name : Audio_CloseIICPort
// Function Desctiption : This function close IIC Interface.
// Input : None
// Output : None
// Version : 0.0
// Author : Sung-Hyun, Na
void Audio_CloseIICPort(void)
{
	IIC_Close();	
	INTC_Disable(NUM_IIC);
}

//////////
// Function Name : WM8753_IICWrite
// Function Desctiption : CMD to WM8753 Codec using IIC I/F
// Input : RegAddr(7bit), Data(9bit)
// Output : None
// Version : 0.0
// Author : Sung-Hyun, Na
void WM8753_IICWrite(u8 rhs_uRegAddr, u32 rhs_uData)
{
	u8 ucRegAddr, ucData;
	ucData = (u8)(rhs_uData & 0xff);
	ucRegAddr = ((rhs_uData & 0x100) >> 8) | (rhs_uRegAddr << 1);
	IIC_Write(WM8753ID, ucRegAddr, ucData);						//Codec ID : 0x34 On SMDK 6410,6400
}

//////////
// Function Name : WM8580_IICWrite
// Function Desctiption : CMD to WM85080 Codec using IIC I/F
// Input : RegAddr(7bit), Data(9bit)
// Output : None
// Version : 0.0
// Author : Sung-Hyun, Na
void WM8580_IICWrite(u8 rhs_uRegAddr, u32 rhs_uData)
{
	u8 ucRegAddr, ucData;
	ucData = (u8)(rhs_uData & 0xff);
	ucRegAddr = ((rhs_uData & 0x100) >> 8) | (rhs_uRegAddr << 1);
	IIC_Write(WM8580ID, ucRegAddr, ucData);					//Codec ID : 0x34 On SMDK 6410,6400
}

//////////
// Function Name : WM8990_IICWrite
// Function Desctiption : This function write WM8990 Codec 16bits register value.
// Input : 	rhs_uRegAddr - Register Address
// 			rhs_uData - Register Value
// Output : None
// Version : 0.0
// Author : Sunghyun, Na
void WM8990_IICWrite(u8 rhs_uRegAddr, u32 rhs_uData)
{
	IIC_Write16(WM8990ID, rhs_uRegAddr, (u16) rhs_uData);			//Codec ID : 0x34
}

//////////
// Function Name : WM8990_IICRead
// Function Desctiption : This function read WM8990 Codec Register Value.
// Input : 
// Output : None
// Version : 0.0
// Author : Sunghyun, Na
u16 WM8990_IICRead(u16 rhs_uRegAddr)
{
//	return IIC_Read16((WM8990ID | 0x1), rhs_uRegAddr);
}


void STAC9767_InitPCMIn(SerialDataFormat eFormat, u32 eSampleRate, OPMode eOpmode, PCMWordLength eWordLen, AudioSource eSource, CodecPort eCodecPort)
{
	AC97_CodecCmd(WRITE,0x00,0x683F);			//codec soft reset 			
	AC97_CodecCmd(WRITE,0x2A,0x0001);		//variable rate enable	
	UART_Printf("VRA Enable(1)/Disable(0): 0x%x\n",(0x1&AC97_CodecCmd(READ,0x2A,0x0001)));

	if(eSampleRate == 8000)					//VRA On: 8KHz	
		AC97_CodecCmd(WRITE,0x32,0x1f40);		
	else if(eSampleRate == 44100)				//VRA On: 44.1KHz
		AC97_CodecCmd(WRITE,0x32,0xac44);		
	else if(eSampleRate == 22050)				//VRA On: 22.05KHz
		AC97_CodecCmd(WRITE,0x32,0x5622);	 	
	else 									//VRA Off: 48KHz
		AC97_CodecCmd(WRITE,0x32,0xbb80);	
	AC97_CodecCmd(WRITE,0x26,(1<<9));		//all power on except DAC Block
	UART_Printf("\nAC97 Codec 0x26 Reg.: 0x%x\n\n", AC97_CodecCmd(READ,0x26,0x0000));
	if ( eSource == LINEIN)
	{
		AC97_CodecCmd(WRITE,0x10,0x1010);			//line in volume on
		AC97_CodecCmd(WRITE,0x6e,0x0000);			//All Analog Mode, ADC Input select => left slot3, right slot4
		AC97_CodecCmd(WRITE,0x1a,0x0505);			//record source select => Stereo Mix
		AC97_CodecCmd(WRITE,0x1c,0x0909);			//record gain is initial
		AC97_CodecCmd(WRITE,0x78,0x0001);			//ADC HPF Bypass
		AC97_CodecCmd(WRITE,0x20,0x0000);			//General Reg.
	}
	else 
	{
		AC97_CodecCmd(WRITE,0x20,0x0000);			//MIC1 Selected
		AC97_CodecCmd(WRITE,0x6e,0x0024);			//ADC Input Slot => left slot6, right slot9, MIC GAIN VAL =1
		AC97_CodecCmd(WRITE,0x0e,0x0040);			//BOOSTEN =1
		AC97_CodecCmd(WRITE,0x1a,0x0000);			//Left, Right => MIC
		AC97_CodecCmd(WRITE,0x1c,0xff);		
		AC97_CodecCmd(WRITE,0x78,0x0001);			//ADC HPF Bypass
	}		
}

void STAC9767_InitPCMOut(SerialDataFormat eFormat, u32 eSampleRate, OPMode eOpmode, PCMWordLength eWordLen, CodecPort eCodecPort)
{	
	
	AC97_CodecCmd(WRITE,0x00,0x683F);		//codec soft reset 		
	AC97_CodecCmd(WRITE,0x2A,0x0001);	//variable rate enable	
	if(eSampleRate==8000)					//DAC Sampling frequency 8kHz
	{
		AC97_CodecCmd(WRITE,0x2C,0x1f40);
	}
	else if(eSampleRate==48000)				//DAC Sampling frequency 48kHz
	{					
		AC97_CodecCmd(WRITE,0x2C,0xbb80);
	}
	else if(eSampleRate==44100)				//DAC Sampling frequency 44.1kHz
	{	
		AC97_CodecCmd(WRITE,0x2C,0xac44);
	}
	else if(eSampleRate==22050)				//DAC Sampling frequency 22.05kHz
	{		
		AC97_CodecCmd(WRITE,0x2C,0x5622);		
	}
	AC97_CodecCmd(WRITE,0x26, (1<<8));	// all power on except ADC blcok
	UART_Printf("AC97 Codec 0x26 Reg.: 0x%x\n\n", AC97_CodecCmd(READ,0x26,0x0000));
	AC97_CodecCmd(WRITE,0x18,0x0000);		// PCM out volume on
	AC97_CodecCmd(WRITE,0x20,0x0000);		// general purpose
	AC97_CodecCmd(WRITE,0x04,0x1A1A);	// Aux out(HP out) volume on
	AC97_CodecCmd(READ,0x04,0x00000);	//HP out volume 
}

//////////
// Function Name : 
// Function Desctiption : 
// Input : Serial Data Format, Sample Rate, Operation mode, PCM Word Length, SMDK Line CodecClk Source
// Output : None
// Version : 0.0
// Author : Sunghyun, Na
void WM8753_CodecInitPCMIn(SerialDataFormat eFormat, u32 eSampleRate, OPMode eOpmode, PCMWordLength eWordLen, AudioSource eSource, CodecPort eCodecPort)
{	
	Audio_InitIICPort();
	Audio_InitIIC();
	WM8753_IICWrite(0x1f, 0x000);	//Reset
	WM8753_IICWrite(0x01, 0x008);	//DAC Control Mute	
	WM8753_IICWrite(0x02, 0x000);	//ADC Control
	
	if (eFormat == DURING_PCMSYNC_HIGH)				//PCM Audio I/F 16bit
	{
		WM8753_IICWrite(0x03, 0x1b3);
		WM8753_IICWrite(0x04, 0x002);	//HiFi Audio I/F	
	}
	else if (eFormat == AFTER_PCMSYNC_HIGH)
	{
		WM8753_IICWrite(0x03, 0x1a3);
		WM8753_IICWrite(0x04, 0x002);	//HiFi Audio I/F	
	}	
	else if (eFormat == I2SFormat)						// I2S I/F 16bit, 24bit
	{
		
		if ( eWordLen == Word24)
		{
			WM8753_IICWrite(0x03, 0x10a | (u32) eOpmode << 6);	//Voice I/F
			WM8753_IICWrite(0x04, 0x00a | (u32) eOpmode << 6);	//HiFi Audio I/F	
		}
		else if ( eWordLen == Word16)
		{
			WM8753_IICWrite(0x03, 0x102 | (u32) eOpmode << 6);	//Voice I/F
			WM8753_IICWrite(0x04, 0x002 | (u32) eOpmode << 6);	//HiFi Audio I/F
		}
	}
	else if (eFormat == MSBJustified)
	{
		
		if ( eWordLen == Word24)
		{
			WM8753_IICWrite(0x03, 0x109 | (u32) eOpmode << 6);	//Voice I/F
			WM8753_IICWrite(0x04, 0x009 | (u32) eOpmode << 6);	//HiFi Audio I/F
		}
		else if ( eWordLen == Word16)
		{
			WM8753_IICWrite(0x03, 0x101 | (u32) eOpmode << 6);	//Voice I/F
			WM8753_IICWrite(0x04, 0x001 | (u32) eOpmode << 6);	//HiFi Audio I/F
		}

	}
	else if (eFormat == LSBJustified)
	{
		if ( eWordLen == Word24)
		{
			WM8753_IICWrite(0x03, 0x108 | (u32) eOpmode << 6);	//Voice I/F
			WM8753_IICWrite(0x04, 0x008 | (u32) eOpmode << 6);	//HiFi Audio I/F
		}
		else if ( eWordLen == Word16)
		{
			WM8753_IICWrite(0x03, 0x100 | (u32) eOpmode << 6);	//Voice I/F
			WM8753_IICWrite(0x04, 0x000 | (u32) eOpmode << 6);	//HiFi Audio I/F
		}
	}
	if ( eOpmode == Master)
	{
		if (eCodecPort ==  CodecPort_2nd)
			WM8753_IICWrite(0x05, 0x000);	//Interface Control Voice Codec and Direction of VFX(I2SLRCLK) 
		else
			WM8753_IICWrite(0x05, 0x008);	//Interface Control HiFI AUDIO DAC with Voice Codec ADC	and Direction of LRC(I2SLRCLK) 
			
		WM8753_IICWrite(0x07, 0x097); 		//Sample Rate Control (2), Don't care in case of slave mode
		#if (WM8753MASTERCLK == CDCLK_I2SCDCLK)
		WM8753_IICWrite(0x34, 0x004);		//Clock Control << Clock for Voice Codec = MCLK or PLL1 Voice Codec same as HiFi DAC
		if ( eSampleRate == 48000)		
			WM8753_IICWrite(0x06, 0x000);	//CDCLK : 24.576MHz, Sync Rate : 48KHz
		else if (eSampleRate == 44100)		
			WM8753_IICWrite(0x06, 0x020);	//CDCLK : 16.934MHz, Sync Rate : 44.1KHz	0x022			
		else 							
			WM8753_IICWrite(0x06, 0x000);
		#elif (WM8753MASTERCLK == CDCLK_OSC)		
		WM8753_IICWrite(0x34, 0x004);		//Clock Control << Clock for Voice Codec = MCLK or PLL1 Voice Codec same as HiFi DAC			 		
		#endif		
	}
	else 
	{
		if (eCodecPort ==  CodecPort_2nd)
			WM8753_IICWrite(0x05, 0x042);	//Interface Control Voice Codec and Direction of VFX(I2SLRCLK) 
		else
			WM8753_IICWrite(0x05, 0x089);	//Interface Control HiFI AUDIO DAC with Voice Codec ADC	and Direction of LRC(I2SLRCLK) 
		
		#if 1
		WM8753_IICWrite(0x34, 0x004);	//Clock Control << Clock for Voice Codec = MCLK for Voice Codec and HiFi DAC
		WM8753_IICWrite(0x35, 0x000);	//PLL1 Control (1)		
		WM8753_IICWrite(0x36, 0x083);	//PLL1 Control (2)
		WM8753_IICWrite(0x37, 0x024);	//PLL1 Control (3)
		WM8753_IICWrite(0x38, 0x1ba);	//PLL1 Control (4)
		#else
		WM8753_IICWrite(0x34, 0x014);	//Clock Control << Clock for Voice Codec = PLL1 for Voice Codec and HiFi DAC
		WM8753_IICWrite(0x35, 0x047);	//PLL1 Control (1) : PLL1 Enable Fin = 12MHz, Fout = 12.288MHz 
		WM8753_IICWrite(0x36, 0x103);	//PLL1 Control (2) : PLL1 N Value & K Value N : 0x8 K : 0xC49BA
		WM8753_IICWrite(0x37, 0x024);	//PLL1 Control (3) : PLL1 K Value
		WM8753_IICWrite(0x38, 0x1ba);	//PLL1 Control (4) : PLL1 K Value			
		#endif
		
		WM8753_IICWrite(0x39, 0x000);	//PLL2 Control (1)
		WM8753_IICWrite(0x3a, 0x083);	//PLL2 Control (2)
		WM8753_IICWrite(0x3b, 0x024);	//PLL2 Control (3)
		WM8753_IICWrite(0x3c, 0x1ba);	//PLL2 Control (4)		

		// Normal Mode for 12.288MHz In
		switch(eSampleRate)
		{
			case 8000:
				WM8753_IICWrite(0x07, 0x127); 	//Sample Rate Control (2) In Master Mode it is decided that divider of I2SSCLK(VXCLK, BCLK) : I2SSCLK = I2SCDCLK / 4 0x093 /8 0x0df / 16 0x127 
				WM8753_IICWrite(0x06, 0x00c);	//Sample Rate Control 		12.288MHz In, 8Khz
				break;
			case 11025:
				WM8753_IICWrite(0x07, 0x127); 	//Sample Rate Control (2) In Master Mode it is decided that divider of I2SSCLK(VXCLK, BCLK) : I2SSCLK = I2SCDCLK / 4 0x093 /8 0x0df / 16 0x127 
				WM8753_IICWrite(0x06, 0x030);	//Sample Rate Control 		12.288MHz In, 11.025Khz
				break;
			case 16000:

				WM8753_IICWrite(0x07, 0x127); 	//Sample Rate Control (2) In Master Mode it is decided that divider of I2SSCLK(VXCLK, BCLK) : I2SSCLK = I2SCDCLK / 4 0x093 /8 0x0df / 16 0x127 
				WM8753_IICWrite(0x06, 0x014);	//Sample Rate Control 		12.288MHz In, 16Khz
				break;
			case 22050:
				WM8753_IICWrite(0x07, 0x127); 	//Sample Rate Control (2) In Master Mode it is decided that divider of I2SSCLK(VXCLK, BCLK) : I2SSCLK = I2SCDCLK / 4 0x093 /8 0x0df / 16 0x127 
				WM8753_IICWrite(0x06, 0x032);	//Sample Rate Control 		12.288MHz In, 22.05Khz
				break;
			case 32000:

				WM8753_IICWrite(0x07, 0x0df); 	//Sample Rate Control (2) In Master Mode it is decided that divider of I2SSCLK(VXCLK, BCLK) : I2SSCLK = I2SCDCLK / 4 0x093 /8 0x0df / 16 0x127 
				WM8753_IICWrite(0x06, 0x018);	//Sample Rate Control 		12.288MHz In, 32Khz
				break;
			case 44100:
				WM8753_IICWrite(0x07, 0x093); 	//Sample Rate Control (2) In Master Mode it is decided that divider of I2SSCLK(VXCLK, BCLK) : I2SSCLK = I2SCDCLK / 4 0x093 /8 0x0df / 16 0x127 
				WM8753_IICWrite(0x06, 0x020);	//Sample Rate Control 		12.288MHz In, 44.1Khz
				break;
			case 48000:
				WM8753_IICWrite(0x07, 0x093); 	//Sample Rate Control (2) In Master Mode it is decided that divider of I2SSCLK(VXCLK, BCLK) : I2SSCLK = I2SCDCLK / 4 0x093 /8 0x0df / 16 0x127 
				WM8753_IICWrite(0x06, 0x000);	//Sample Rate Control 		12.288MHz In, 48Khz
				break;
			case 88200:

				WM8753_IICWrite(0x07, 0x003); 	//Sample Rate Control (2) In Master Mode it is decided that divider of I2SSCLK(VXCLK, BCLK) : I2SSCLK = I2SCDCLK /1 0x003 / 4 0x093 /8 0x0df / 16 0x127 
				WM8753_IICWrite(0x06, 0x03c);	//Sample Rate Control 		12.288MHz In, 88.2Khz
				break;
			case 96000:
				WM8753_IICWrite(0x07, 0x003); 	//Sample Rate Control (2) In Master Mode it is decided that divider of I2SSCLK(VXCLK, BCLK) : I2SSCLK = I2SCDCLK / 4 0x093 /8 0x0df / 16 0x127 
				WM8753_IICWrite(0x06, 0x01c);	//Sample Rate Control 		12.288MHz In, 96Khz
				break;
			default:
				WM8753_IICWrite(0x07, 0x0df); 	//Sample Rate Control (2) In Master Mode it is decided that divider of I2SSCLK(VXCLK, BCLK) : I2SSCLK = I2SCDCLK / 4 0x093 /8 0x0df / 16 0x127 
				WM8753_IICWrite(0x06, 0x000);	//Sample Rate Control 		12.288MHz In, 48Khz
				break;
		}
	}
	
	WM8753_IICWrite(0x08, 0x0ff); 	//Left DAC Volume
	WM8753_IICWrite(0x09, 0x0ff); 	//Right DAC Volume
	WM8753_IICWrite(0x0c, 0x07b); 	//ALC 1
	WM8753_IICWrite(0x0d, 0x000); 	//ALC 2
	WM8753_IICWrite(0x0e, 0x032); 	//ALC 3
	WM8753_IICWrite(0x0f, 0x000); 	//Noise Gate 
	WM8753_IICWrite(0x10, 0x00f); 	//Left ADC Volume
	WM8753_IICWrite(0x11, 0x00f); 	//Right ADC Volume
	WM8753_IICWrite(0x12, 0x0c0); 	//Additional Control
	WM8753_IICWrite(0x13, 0x000); 	//Three D Control
	
	if (eSource == MICIN)
	{
		WM8753_IICWrite(0x14, 0x0e0); 	//Power Management(1) << Power up VMID[50K ohm]; VREF >>
		WM8753_IICWrite(0x15, 0x1ff); 	//Power Management(2) << Power up ADCL/R >>
	}
	else 
	{
		WM8753_IICWrite(0x14, 0x0c0); 	//Power Management(1) << Power up VMID[50K ohm]; VREF >>
		WM8753_IICWrite(0x15, 0x00c); 	//Power Management(2) << Power up ADCL/R >>
	}
	
	WM8753_IICWrite(0x16, 0x000); 	//Power Management(3)
	WM8753_IICWrite(0x17, 0x000); 	//Power Management(4)
	WM8753_IICWrite(0x18, 0x000); 	//ID Register
	WM8753_IICWrite(0x19, 0x000); 	//Codec Interupt Polarty
	WM8753_IICWrite(0x1a, 0x000);	//Codec Interupt Enable
	WM8753_IICWrite(0x1b, 0x000);	//GPIO Control (1)
	WM8753_IICWrite(0x1c, 0x000);	//GPIO Control (2)

	WM8753_IICWrite(0x20, 0x055);	//Record Mix (1)
	WM8753_IICWrite(0x21, 0x005);	//Record Mix (2)
	WM8753_IICWrite(0x22, 0x050);	//Left Out Mix(1)
	WM8753_IICWrite(0x23, 0x055);	//Left Out Mix(2)
	WM8753_IICWrite(0x24, 0x050);	//Rigth Out Mix(1)
	WM8753_IICWrite(0x25, 0x055);	//Right Out Mix(2)
	WM8753_IICWrite(0x26, 0x050);	//Mono Out Mix(1)
	WM8753_IICWrite(0x27, 0x055);	//Mono Out Mix(2)

	WM8753_IICWrite(0x28, 0x079);	//LOUT1 Volume
	WM8753_IICWrite(0x29, 0x079);	//ROUT1 Volume
	WM8753_IICWrite(0x2a, 0x079);	//LOUT2 Volume
	WM8753_IICWrite(0x2b, 0x079);	//ROUT2 Volume
	WM8753_IICWrite(0x2c, 0x079);	//MONO Out
	WM8753_IICWrite(0x2d, 0x000);	//Output Control
	WM8753_IICWrite(0x2e, 0x005);	//ADC Input Mode << Set L/R ADC input select to Line 1/2 '01' >>
	
	// MIC IN
	// WM8753_IICWrite(0x2f, 0x060);	//Input Control (1)
	// WM8753_IICWrite(0x30, 0x002);	//Input Control (2)
	// WM8753_IICWrite(0x33, 0x001);	//MIC Bias Comp Control 

	// LINE IN
	WM8753_IICWrite(0x2f, 0x000);	//Input Control (1)
	WM8753_IICWrite(0x30, 0x000);	//Input Control (2)
	WM8753_IICWrite(0x33, 0x000);	//MIC Bias Comp Control 	
	
	WM8753_IICWrite(0x31, 0x097);	//Left Input Volume
	WM8753_IICWrite(0x32, 0x097);	//Right Input Volume	
	
	WM8753_IICWrite(0x3d, 0x000);	//Bias Control
	WM8753_IICWrite(0x3f, 0x000);	//Additional Control
	
	Audio_CloseIICPort();
	
}

void WM8753_CodecInitPCMOut(SerialDataFormat eFormat, u32 eSampleRate, OPMode eOpmode, PCMWordLength eWordLen, CodecPort eCodecPort)
{
	Audio_InitIICPort();	
	Audio_InitIIC();
	
	WM8753_IICWrite(0x1f, 0x000);	//Reset

	WM8753_IICWrite(0x14, 0x0dc);	//Power Management(1)
	WM8753_IICWrite(0x17, 0x003);	//Power Management(4)
	Delay(1000);
	
	WM8753_IICWrite(0x01, 0x000);	//DAC Control No Mute
	WM8753_IICWrite(0x02, 0x000);	//ADC Control

	if (eFormat == DURING_PCMSYNC_HIGH)
	{
		WM8753_IICWrite(0x03, 0x1b3);
		WM8753_IICWrite(0x04, 0x0b3);	//HiFi Audio I/F	 
	}
	else if (eFormat == AFTER_PCMSYNC_HIGH)
	{
		WM8753_IICWrite(0x03, 0x1a3);
		WM8753_IICWrite(0x04, 0x0a3);	//HiFi Audio I/F
	}
	else if (eFormat == I2SFormat)
	{
		
		if ( eWordLen == Word24)
		{
			WM8753_IICWrite(0x03, 0x10a |(u32) eOpmode << 6);	//Voice I/F
			WM8753_IICWrite(0x04, 0x00a |(u32) eOpmode << 6);	//HiFi Audio I/F	
		}
		else if ( eWordLen == Word16)
		{
			WM8753_IICWrite(0x03, 0x102 |(u32) eOpmode << 6);	//Voice I/F
			WM8753_IICWrite(0x04, 0x002 |(u32) eOpmode << 6);	//HiFi Audio I/F
		}
	}
	else if (eFormat == MSBJustified)
	{
		
		if ( eWordLen == Word24)
		{
			WM8753_IICWrite(0x03, 0x109 |(u32) eOpmode << 6);	//Voice I/F
			WM8753_IICWrite(0x04, 0x009 |(u32) eOpmode << 6);	//HiFi Audio I/F
		}
		else if ( eWordLen == Word16)
		{
			WM8753_IICWrite(0x03, 0x101 |(u32) eOpmode << 6);	//Voice I/F
			WM8753_IICWrite(0x04, 0x001 |(u32) eOpmode << 6);	//HiFi Audio I/F
		}

	}
	else if (eFormat == LSBJustified)
	{
		if ( eWordLen == Word24)
		{
			WM8753_IICWrite(0x03, 0x108 |(u32) eOpmode << 6);	//Voice I/F
			WM8753_IICWrite(0x04, 0x008 |(u32) eOpmode << 6);	//HiFi Audio I/F
		}
		else if ( eWordLen == Word16)
		{
			WM8753_IICWrite(0x03, 0x100 |(u32) eOpmode << 6);	//Voice I/F
			WM8753_IICWrite(0x04, 0x000 |(u32) eOpmode << 6);	//HiFi Audio I/F
		}
	}	
	
	if ( eOpmode == Master)				//Codec Slave 
	{
		if (eCodecPort ==  CodecPort_2nd)
		{
			WM8753_IICWrite(0x05, 0x000);	//Interface Control Voice Codec and Direction of VFX(I2SLRCLK) 
			WM8753_IICWrite(0x20, 0x055);	//Record Mix (1)
			WM8753_IICWrite(0x21, 0x005);	//Record Mix (2)
			WM8753_IICWrite(0x22, 0x050);	//Left Out Mix(1)
			WM8753_IICWrite(0x23, 0x155);	//Left Out Mix(2)
			WM8753_IICWrite(0x24, 0x050);	//Rigth Out Mix(1)
			WM8753_IICWrite(0x25, 0x155);	//Right Out Mix(2)
			WM8753_IICWrite(0x26, 0x050);	//Mono Out Mix(1)
			WM8753_IICWrite(0x27, 0x055);	//Mono Out Mix(2)
		}
		else
		{
			WM8753_IICWrite(0x05, 0x008);	//Interface Control HiFI AUDIO DAC with Voice Codec ADC	and Direction of LRC(I2SLRCLK) 
			WM8753_IICWrite(0x20, 0x055);	//Record Mix (1)
			WM8753_IICWrite(0x21, 0x005);	//Record Mix (2)
			WM8753_IICWrite(0x22, 0x150);	//Left Out Mix(1)
			WM8753_IICWrite(0x23, 0x055);	//Left Out Mix(2)
			WM8753_IICWrite(0x24, 0x150);	//Rigth Out Mix(1)
			WM8753_IICWrite(0x25, 0x055);	//Right Out Mix(2)
			WM8753_IICWrite(0x26, 0x050);	//Mono Out Mix(1)
			WM8753_IICWrite(0x27, 0x055);	//Mono Out Mix(2)
		}
			
			WM8753_IICWrite(0x07, 0x097); 	//Sample Rate Control (2), Don't care in case of slave mode
		#if (WM8753MASTERCLK == CDCLK_I2SCDCLK)				
			WM8753_IICWrite(0x34, 0x004);	//Clock Control << Clock for Voice Codec = MCLK or PLL1 Voice Codec same as HiFi DAC			
			
			if ( eSampleRate == 48000)		WM8753_IICWrite(0x06, 0x000);	//Sync Rate Control 512fs 	CDCLK : 24.576MHz, Sync Rate : 48KHz
			else if (eSampleRate == 44100)		WM8753_IICWrite(0x06, 0x020);	//Sync Rate Control 384fs 	CDCLK : 16.934MHz, Sync Rate : 44.1KHz
			
		#elif (WM8753MASTERCLK == CDCLK_OSC)				//16.9344 OSC on SMDK 6400 Rev0.2	
			
			WM8753_IICWrite(0x34, 0x004);	//Clock Control << Clock for Voice Codec = MCLK or PLL1 Voice Codec same as HiFi DAC
			WM8753_IICWrite(0x35, 0x000);	//PLL1 Control (1)
			WM8753_IICWrite(0x36, 0x083);	//PLL1 Control (2)
			WM8753_IICWrite(0x37, 0x024);	//PLL1 Control (3)
			WM8753_IICWrite(0x38, 0x1ba);	//PLL1 Control (4)

			WM8753_IICWrite(0x39, 0x000);	//PLL2 Control (1)
			WM8753_IICWrite(0x3a, 0x083);	//PLL2 Control (2)
			WM8753_IICWrite(0x3b, 0x024);	//PLL2 Control (3)
			WM8753_IICWrite(0x3c, 0x1ba);	//PLL2 Control (4)

			//12MHz Oscillator
			if (eSampleRate == 8000)
				WM8753_IICWrite(0x06, ( (0x3<<1) |(1<<0) ));
			else if (eSampleRate == 11025) 
				WM8753_IICWrite(0x06, ( (0x19<<1) | (1<<0) ));
			else if (eSampleRate == 16000) 
				WM8753_IICWrite(0x06, ( (0x0a<<1) | (1<<0) ));
			else if (eSampleRate == 22050) 
				WM8753_IICWrite(0x06, ( (0x1b<<1) | (1<<0) ));
			else if (eSampleRate == 32000) 
				WM8753_IICWrite(0x06, ( (0x0c<<1) | (1<<0) ));
			else if (eSampleRate == 44100) 
				WM8753_IICWrite(0x06, ( (0x11<<1) | (1<<0) ));
			else if (eSampleRate == 48000) 
				WM8753_IICWrite(0x06, ( (0x0<<1) | (1<<0) ));
			else if (eSampleRate == 88200) 
				WM8753_IICWrite(0x06, ( (0x1f<<1) | (1<<0) ));
			else if (eSampleRate == 96000) 
				WM8753_IICWrite(0x06, ( (0x0e<<1) | (1<<0) ));
			else
				WM8753_IICWrite(0x06, ( (0x00<<1) | (1<<0) ));		
		#endif
	}

	else									// Codec Master  Clk Source is 12 MHz OSCIN from 6410 on I2SCDCLK
	{
		if (eCodecPort ==  CodecPort_2nd)
		{
			WM8753_IICWrite(0x05, 0x042);	//Interface Control Voice Codec and Direction of VFX(I2SLRCLK) 		0x042
			WM8753_IICWrite(0x20, 0x055);	//Record Mix (1)
			WM8753_IICWrite(0x21, 0x005);	//Record Mix (2)
			WM8753_IICWrite(0x22, 0x050);	//Left Out Mix(1)
			WM8753_IICWrite(0x23, 0x155);	//Left Out Mix(2)
			WM8753_IICWrite(0x24, 0x050);	//Rigth Out Mix(1)
			WM8753_IICWrite(0x25, 0x155);	//Right Out Mix(2)
			WM8753_IICWrite(0x26, 0x050);	//Mono Out Mix(1)
			WM8753_IICWrite(0x27, 0x055);	//Mono Out Mix(2)
		}		
		else
		{
			WM8753_IICWrite(0x05, 0x089);	//Interface Control HiFI AUDIO DAC with Voice Codec ADC	and Direction of LRC(I2SLRCLK) 0x089
			WM8753_IICWrite(0x20, 0x055);	//Record Mix (1)
			WM8753_IICWrite(0x21, 0x005);	//Record Mix (2)
			WM8753_IICWrite(0x22, 0x150);	//Left Out Mix(1)
			WM8753_IICWrite(0x23, 0x055);	//Left Out Mix(2)
			WM8753_IICWrite(0x24, 0x150);	//Rigth Out Mix(1)
			WM8753_IICWrite(0x25, 0x055);	//Right Out Mix(2)
			WM8753_IICWrite(0x26, 0x050);	//Mono Out Mix(1)
			WM8753_IICWrite(0x27, 0x055);	//Mono Out Mix(2)		
		}			
		#if 1							// No use PLL1 
		WM8753_IICWrite(0x34, 0x004);	//Clock Control << Clock for Voice Codec = MCLK for Voice Codec and HiFi DAC		
		WM8753_IICWrite(0x35, 0x000);	//PLL1 Control (1)		
		WM8753_IICWrite(0x36, 0x083);	//PLL1 Control (2)
		WM8753_IICWrite(0x37, 0x024);	//PLL1 Control (3)
		WM8753_IICWrite(0x38, 0x1ba);	//PLL1 Control (4)
		#else							// Using PLL1
		WM8753_IICWrite(0x34, 0x014);	//Clock Control << Clock for Voice Codec = PLL1 for Voice Codec and HiFi DAC
		WM8753_IICWrite(0x35, 0x047);	//PLL1 Control (1) : PLL1 Enable Fin = 12MHz, Fout = 12.288MHz 
		WM8753_IICWrite(0x36, 0x103);	//PLL1 Control (2) : PLL1 N Value & K Value N : 0x8 K : 0xC49BA
		WM8753_IICWrite(0x37, 0x024);	//PLL1 Control (3) : PLL1 K Value
		WM8753_IICWrite(0x38, 0x1ba);	//PLL1 Control (4) : PLL1 K Value			
		#endif 	
		WM8753_IICWrite(0x39, 0x000);	//PLL2 Control (1)
		WM8753_IICWrite(0x3a, 0x083);	//PLL2 Control (2)
		WM8753_IICWrite(0x3b, 0x024);	//PLL2 Control (3)
		WM8753_IICWrite(0x3c, 0x1ba);	//PLL2 Control (4)				
		switch(eSampleRate)
		{
			case 8000:
				WM8753_IICWrite(0x07, 0x127); 	//Sample Rate Control (2) In Master Mode it is decided that divider of I2SSCLK(VXCLK, BCLK) : I2SSCLK = I2SCDCLK / 4 0x093 /8 0x0df / 16 0x127
				WM8753_IICWrite(0x06, 0x00c);	//Sample Rate Control 	12.288MHz In, 8Khz
				break;
			case 11025:
				WM8753_IICWrite(0x07, 0x127); 	//Sample Rate Control (2) In Master Mode it is decided that divider of I2SSCLK(VXCLK, BCLK) : I2SSCLK = I2SCDCLK / 4 0x093 /8 0x0df / 16 0x127
				WM8753_IICWrite(0x06, 0x030);	//Sample Rate Control 	12.288MHz In, 11.025Khz
				break;
			case 16000:
				WM8753_IICWrite(0x07, 0x127); 	//Sample Rate Control (2) In Master Mode it is decided that divider of I2SSCLK(VXCLK, BCLK) : I2SSCLK = I2SCDCLK / 4 0x093 /8 0x0df / 16 0x127
				WM8753_IICWrite(0x06, 0x014);	//Sample Rate Control 	12MHz In, 16Khz
				break;
			case 22050:
				WM8753_IICWrite(0x07, 0x127); 	//Sample Rate Control (2) In Master Mode it is decided that divider of I2SSCLK(VXCLK, BCLK) : I2SSCLK = I2SCDCLK / 4 0x093 /8 0x0df / 16 0x127
				WM8753_IICWrite(0x06, 0x032);	//Sample Rate Control 	12MHz In, 22.05Khz
				break;
			case 32000:

				WM8753_IICWrite(0x07, 0x0df); 	//Sample Rate Control (2) In Master Mode it is decided that divider of I2SSCLK(VXCLK, BCLK) : I2SSCLK = I2SCDCLK / 4 0x093 /8 0x0df / 16 0x127
				WM8753_IICWrite(0x06, 0x018);	//Sample Rate Control 	12MHz In, 32Khz
				break;
			case 44100:
				WM8753_IICWrite(0x07, 0x093); 	//Sample Rate Control (2) In Master Mode it is decided that divider of I2SSCLK(VXCLK, BCLK) : I2SSCLK = I2SCDCLK / 4 0x093 /8 0x0df / 16 0x127
				WM8753_IICWrite(0x06, 0x020);	//Sample Rate Control 	12MHz In, 44.1Khz
				break;
			case 48000:
				WM8753_IICWrite(0x07, 0x093); 	//Sample Rate Control (2) In Master Mode it is decided that divider of I2SSCLK(VXCLK, BCLK) : I2SSCLK = I2SCDCLK / 4 0x093 /8 0x0df / 16 0x127
				WM8753_IICWrite(0x06, 0x000);	//Sample Rate Control 	12MHz In, 48Khz
				break;
			case 88200:

				WM8753_IICWrite(0x07, 0x003); 	//Sample Rate Control (2) In Master Mode it is decided that divider of I2SSCLK(VXCLK, BCLK) : I2SSCLK = I2SCDCLK / 4 0x093 /8 0x0df / 16 0x127
				WM8753_IICWrite(0x06, 0x03c);	//Sample Rate Control 	12MHz In, 88.2Khz
				break;
			case 96000:
				WM8753_IICWrite(0x07, 0x003); 	//Sample Rate Control (2) In Master Mode it is decided that divider of I2SSCLK(VXCLK, BCLK) : I2SSCLK = I2SCDCLK / 4 0x093 /8 0x0df / 16 0x127
				WM8753_IICWrite(0x06, 0x01c);	//Sample Rate Control 	12MHz In, 96Khz
				break;
			default:
				WM8753_IICWrite(0x07, 0x0df); 	//Sample Rate Control (2) In Master Mode it is decided that divider of I2SSCLK(VXCLK, BCLK) : I2SSCLK = I2SCDCLK / 4 0x093 /8 0x0df / 16 0x127
				WM8753_IICWrite(0x06, 0x000);	//Sample Rate Control 	12MHz In, 48Khz
				break;				

		}
	}
	
	
	WM8753_IICWrite(0x08, 0x0ff); 	//Left DAC Volume
	WM8753_IICWrite(0x09, 0x0ff); 	//Right DAC Volume
	WM8753_IICWrite(0x0a, 0x00f); 	//Bass Control
	WM8753_IICWrite(0x0b, 0x00f); 	//Treble Control
	WM8753_IICWrite(0x0c, 0x07b); 	//ALC 1
	WM8753_IICWrite(0x0d, 0x000); 	//ALC 2
	WM8753_IICWrite(0x0e, 0x032); 	//ALC 3
	WM8753_IICWrite(0x0f, 0x000); 	//Noise Gate 
	WM8753_IICWrite(0x10, 0x1c3); 	//Left ADC Volume
	WM8753_IICWrite(0x11, 0x1c3); 	//Right ADC Volume
	WM8753_IICWrite(0x12, 0x0c0); 	//Additional Control
	WM8753_IICWrite(0x13, 0x000); 	//Three D Control
	WM8753_IICWrite(0x15, 0x000); 	//Power Management(2) << Power up ADCL/R 0x00c>>
	WM8753_IICWrite(0x18, 0x000); 	//ID Register
	WM8753_IICWrite(0x19, 0x000); 	//Codec Interupt Polarty
	WM8753_IICWrite(0x1a, 0x000);	//Codec Interupt Enable
	WM8753_IICWrite(0x1b, 0x000);	//GPIO Control (1)
	WM8753_IICWrite(0x1c, 0x000);	//GPIO Control (2)	
	
	WM8753_IICWrite(0x28, 0x159);	//LOUT1 Volume
	WM8753_IICWrite(0x29, 0x159);	//ROUT1 Volume
	WM8753_IICWrite(0x2a, 0x059);	//LOUT2 Volume
	WM8753_IICWrite(0x2b, 0x059);	//ROUT2 Volume
	WM8753_IICWrite(0x2c, 0x079);	//MONO Out
	WM8753_IICWrite(0x2d, 0x000);	//Output Control
	WM8753_IICWrite(0x2e, 0x005);	//ADC Input Mode << Set L/R ADC input select to Line 1/2 '01' >>
	WM8753_IICWrite(0x2f, 0x000);	//Input Control (1)
	WM8753_IICWrite(0x30, 0x000);	//Input Control (2)
	WM8753_IICWrite(0x31, 0x097);	//Left Input Volume
	WM8753_IICWrite(0x32, 0x097);	//Right Input Volume
	WM8753_IICWrite(0x33, 0x000);	//MIC Bias Comp Control	

	WM8753_IICWrite(0x3d, 0x000);	//Bias Control
	WM8753_IICWrite(0x3f, 0x000);	//Additional Control
		
	WM8753_IICWrite(0x16, 0x180); 	//Power Management(3)

	Audio_CloseIICPort();
}
void WM8580_CodecCLKOut(u32 uClockout)
{
	Audio_InitIICPort();
	Audio_InitIIC();

	WM8580_IICWrite(0x33, 0x038);								//Power Down 2 : OSC, PLLA and PLLB enable, SPDI/F Clk Disabled
	WM8580_IICWrite(0x07, 0x1f4);								//PLLB 4 : MCLK OUT OSCCLKOUT
	Audio_CloseIICPort();	

}
void WM8580_CodecInitPCMIn(SerialDataFormat eFormat, u32 eSampleRate, OPMode eOpmode, PCMWordLength eWordLen, AudioSource eSource, CodecPort eCodecPort)
{
	Audio_InitIICPort();
	Audio_InitIIC();
	WM8580_IICWrite(0x35, 0x000);								//Reset WM8580	
	WM8580_IICWrite(0x32, 0x07c);								//Power Down 1 : ADC Enable, DACs Disable, Digital Interfase Enable	
	WM8580_IICWrite(0x33, 0x03f);								//Power Down 2 : OSC, PLL and SPDI/F Clk Disabled
	if ( eCodecPort == CodecPort_1st )								//Primary Audio Interface : I2S Multichannel
	{
		WM8580_IICWrite(0x08, 0x03c);							//CLKSEL : MCLK is source of All DACs, ADC & SPDI MCLK
		if ( eOpmode == Master)									//Master : 6410		Slave : WM8580
		{			
			WM8580_IICWrite(0x09, 0x002 | eOpmode << 5);						//PAIF 1	Master Reciever	 			
			WM8580_IICWrite(0x0a, 0x002 | eOpmode << 5);						//PAIF 2	Master Transmitte 	
		}		
		else if ( eOpmode == Slave)								//Master : WM8580 Slave : 6410
		{
			WM8580_IICWrite(0x09, 0x000 | eOpmode << 5);						//PAIF 1	Master Reciever	 768fs, 64 BCLKs/LRCLK 		//256fs : 010 384fs : 011 512fs : 100 768fs : 101
			WM8580_IICWrite(0x0a, 0x025 | eOpmode << 5);						//PAIF 2	Master Transmitte 0x112 or 0x102		
		}		
		WM8580_IICWrite(0x1d, 0x140);							//ADC Control 1		
		if (eFormat == I2SFormat)
		{
			WM8580_IICWrite(0x0c, 0x182 | eWordLen << 2);		//PAIF 3	Receiver Audio format
			WM8580_IICWrite(0x0d, 0x082 | eWordLen << 2);		//PAIF 4
		}
		else if (eFormat == LSBJustified)
		{
			WM8580_IICWrite(0x0c, 0x181 | eWordLen << 2);		//PAIF 3	Receiver Audio format
			WM8580_IICWrite(0x0d, 0x082 | eWordLen << 2);		//PAIF 4
		}
		else if (eFormat == MSBJustified)
		{
			WM8580_IICWrite(0x0c, 0x180 | eWordLen << 2);		//PAIF 3	Receiver Audio format
			WM8580_IICWrite(0x0d, 0x080 | eWordLen << 2);		//PAIF 4
		}
		else 
			Assert(0);
	}
	else if ( eCodecPort == CodecPort_2nd)	//Secondry Audio Interface : I2S, PCM IF
	{
		WM8580_IICWrite(0x08, 0x01c);							//CLKSEL : MCLK is source of All ADC, DAC & SPDIF
		if ( eOpmode == Master)									// Master : 6410	Slave : WM8580	
		{	
			WM8580_IICWrite(0x0b, 0x0c0);						//SAIF 1	Slave Interface	 			
		}		
		else if ( eOpmode == Slave)								//Master : WM8580 	Slave : 6410
		{
			WM8580_IICWrite(0x0b, 0x0e2);						//SAIF 1	Master Reciever	 768fs, 64 BCLKs/LRCLK 		//256fs : 010 384fs : 011 512fs : 100 768fs : 101
		}	
		WM8580_IICWrite(0x1d, 0x140);							//ADC Control 1		
		if (eFormat == I2SFormat)
		{
			WM8580_IICWrite(0x0e, 0x0c2 | eWordLen << 2);		//SAIF 2	Receiver Audio format
			WM8580_IICWrite(0x0d, 0x102 | eWordLen << 2);		//PAIF 4	Receiver Audio format
		}
		else if (eFormat == LSBJustified)
		{
			WM8580_IICWrite(0x0e, 0x0c0 | eWordLen << 2);		//SAIF 2	Receiver Audio format
			WM8580_IICWrite(0x0d, 0x100 | eWordLen << 2);		//PAIF 4	Receiver Audio format
		}
		else if (eFormat == MSBJustified)
		{
			WM8580_IICWrite(0x0e, 0x0c1 | eWordLen << 2);		//SAIF 2	Receiver Audio format
			WM8580_IICWrite(0x0d, 0x101 | eWordLen << 2);		//PAIF 4	Receiver Audio format
		}
		else if (eFormat == AFTER_PCMSYNC_HIGH)
		{
			WM8580_IICWrite(0x0e, 0x0e3);						//SAIF 2	Receiver Audio format		0x0e3
			WM8580_IICWrite(0x0d, 0x133);						//PAIF 4	Receiver Audio format		0x133			
		}
		else if (eFormat == DURING_PCMSYNC_HIGH)
		{
			WM8580_IICWrite(0x0e, 0x0f3);						//SAIF 2	Receiver Audio format		0x0f3
			WM8580_IICWrite(0x0d, 0x123);						//PAIF 4	Receiver Audio format		0x123
		}	
		else
			Assert(0);
	}	
	Audio_CloseIICPort();	
	/*
	//Secondrt Audio Interface (SAIF) RX Configuration
	WM8580_IICWrite(0x0b, 0x000);				//SAIF 1	
	WM8580_IICWrite(0x0e, 0x000);				//SAIF 2		
	
	WM8580_IICWrite(0x05, 0x000);				//PLL B
	WM8580_IICWrite(0x06, 0x000);				//PLL B
	WM8580_IICWrite(0x07, 0x000);				//PLL B	
	
	WM8580_IICWrite(0x0f, 0x000);				//DAC Control 1	
	WM8580_IICWrite(0x10, 0x100);				//DAC Control 2
	WM8580_IICWrite(0x11, 0x100);				//DAC Control 3
	WM8580_IICWrite(0x12, 0x100);				//DAC Control 4
	WM8580_IICWrite(0x13, 0x100);				//DAC Control 5
	
	WM8580_IICWrite(0x14, 0x100);				//Digital Attenuation DACL1
	WM8580_IICWrite(0x15, 0x100);				//Digital Attenuation DACR2
	WM8580_IICWrite(0x16, 0x100);				//Digital Attenuation DACL2
	WM8580_IICWrite(0x17, 0x100);				//Digital Attenuation DACR2 
	WM8580_IICWrite(0x18, 0x100);				//Digital Attenuation DACL3
	WM8580_IICWrite(0x19, 0x100);				//Digital Attenuation DACR3	
	WM8580_IICWrite(0x1c, 0x100);				//Master Digital Attenuation
	
	
	WM8580_IICWrite(0x1e, 0x100);				//SPDTXCHAN 0
	WM8580_IICWrite(0x1f, 0x100);				//SPDTXCHAN 1	
	WM8580_IICWrite(0x20, 0x200);				//SPDTXCHAN 2
	WM8580_IICWrite(0x21, 0x200);				//SPDTXCHAN 3
	WM8580_IICWrite(0x22, 0x200);				//SPDTXCHAN 4
	WM8580_IICWrite(0x23, 0x200);				//SPDTXCHAN 5
	
	WM8580_IICWrite(0x24, 0x200);				//SPD MODE
	WM8580_IICWrite(0x25, 0x200);				//INTMASK
	WM8580_IICWrite(0x26, 0x200);				//GPO1 Control
	WM8580_IICWrite(0x27, 0x200);				//GPO2 Control
	WM8580_IICWrite(0x28, 0x200);				//GPO3 Control
	WM8580_IICWrite(0x29, 0x200);				//GPO4 Control
	WM8580_IICWrite(0x2a, 0x200);				//GPO5 Control 
	
	WM8580_IICWrite(0x2b, 0x200);				//INTSTAT 
	
	WM8580_IICWrite(0x2c, 0x200);				//SPDRXCHAN 1
	WM8580_IICWrite(0x2d, 0x200);				//SPDRXCHAN 2
	WM8580_IICWrite(0x2e, 0x200);				//SPDRXCHAN 3
	WM8580_IICWrite(0x2f, 0x200);				//SPDRXCHAN 4	
	WM8580_IICWrite(0x30, 0x300);				//SPDRXCHAN 5
	
	WM8580_IICWrite(0x31, 0x300);				//SPTSTAT	
	
	WM8580_IICWrite(0x34, 0x300);				//Read Back
	*/
}

void WM8580_CodecInitPCMOut(SerialDataFormat eFormat, u32 eSampleRate, OPMode eOpmode, PCMWordLength eWordLen, CodecPort eCodecPort)
{
	Audio_InitIICPort();
	Audio_InitIIC();
	WM8580_IICWrite(0x35, 0x000);								//Reset WM8580
	if ( eCodecPort == CodecPort_1st )								//Primary Audio Interface : I2S Multichannel
	{
		WM8580_IICWrite(0x32, 0x022);							//Power Down 1: ADC Disable, DACs Enable, Digital Interface Enable 
		WM8580_IICWrite(0x33, 0x03f);							//Power Down 2: OSC, PLL and SPDI/F Clk Disabled
		WM8580_IICWrite(0x08, 0x03c);							//CLKSEL : All ADC, DAC & SPDIF CLk source are MCLK		
		if ( eOpmode == Master)									//Master : 6410		Slave : WM8580
		{
			WM8580_IICWrite(0x09, 0x002 | eOpmode << 5);						//PAIF 1					
			WM8580_IICWrite(0x0a, 0x002 | eOpmode << 5);						//PAIF 2	
		}	
		else if ( eOpmode == Slave)								// Master : WM8580 	Slave : 6410
		{
			WM8580_IICWrite(0x09, 0x025);						//PAIF 1	Master Reciever	 768fs, 64 BCLKs/LRCLK 		//256fs : 010 384fs : 011 512fs : 100 768fs : 101
			WM8580_IICWrite(0x0a, 0x000);						//PAIF 2	Master Transmitte 0x112 or 0x102		
		}		
		if (eFormat == I2SFormat)
		{
			WM8580_IICWrite(0x0c, 0x182 | eWordLen << 2);		//PAIF 3	Receiver Audio format
			WM8580_IICWrite(0x0d, 0x082 | eWordLen << 2);		//PAIF 4
		}
		else if (eFormat == LSBJustified)
		{
			WM8580_IICWrite(0x0c, 0x181 | eWordLen << 2);		//PAIF 3	Receiver Audio format
			WM8580_IICWrite(0x0d, 0x082 | eWordLen << 2);		//PAIF 4

		}
		else if (eFormat == MSBJustified)
		{
			WM8580_IICWrite(0x0c, 0x180 | eWordLen << 2);		//PAIF 3	Receiver Audio format
			WM8580_IICWrite(0x0d, 0x080 | eWordLen << 2);		//PAIF 4
		}
		WM8580_IICWrite(0x1c, 0x1ff);				//Master Digital Attenuation		
	}
	else if ( eCodecPort == CodecPort_2nd)	//Secondry Audio Interface : I2S Multichannel
	{
		WM8580_IICWrite(0x32, 0x038);							//Power Down 1: ADC Disable, DAC1 Enable, DAC2 and DAC3 are disable, Digital Interface Enable 
		WM8580_IICWrite(0x33, 0x038);							//Power Down 2: OSC, PLL Enable, SPDI/F Clk Disabled
		WM8580_IICWrite(0x08, 0x010);							//CLKSEL : All ADC, DAC & SPDIF CLk source are MCLK	
		WM8580_IICWrite(0x1d, 0x140);							//ADC Control 1		
		if ( eOpmode == Master)									// Master : 6410	Slave : WM8580
		{
			WM8580_IICWrite(0x0b, 0x0c2);						//SAIF 1	Master Transmiter Reciever	 			
		}
		
		else if ( eOpmode == Slave)								// Master : WM8580 	Slave : 6410
		{
			WM8580_IICWrite(0x0b, 0x0e2);						//SAIF 1	Slave Reciever	 768fs, 64 BCLKs/LRCLK 		//256fs : 010 384fs : 011 512fs : 100 768fs : 101
		}				
		if (eFormat == I2SFormat)
		{
			WM8580_IICWrite(0x0e, 0x042 | eWordLen << 2);		//SAIF 2	Receiver Audio format
			WM8580_IICWrite(0x0c, 0x102 | eWordLen << 2);		//PAIF 3	Receiver Audio format
			WM8580_IICWrite(0x0d, 0x102 | eWordLen << 2);		//PAIF 4	Receiver Audio format
		}
		else if (eFormat == LSBJustified)
		{
			WM8580_IICWrite(0x0e, 0x040 | eWordLen << 2);		//SAIF 2	Receiver Audio format
			WM8580_IICWrite(0x0c, 0x100 | eWordLen << 2);		//PAIF 3	Receiver Audio format
			WM8580_IICWrite(0x0d, 0x100 | eWordLen << 2);		//PAIF 4	Receiver Audio format
		}
		else if (eFormat == MSBJustified)
		{
			WM8580_IICWrite(0x0e, 0x041 | eWordLen << 2);		//SAIF 2	Receiver Audio format
			WM8580_IICWrite(0x0c, 0x101 | eWordLen << 2);		//PAIF 3	Receiver Audio format
			WM8580_IICWrite(0x0d, 0x101 | eWordLen << 2);		//PAIF 3	Receiver Audio format
		}
		else if (eFormat == AFTER_PCMSYNC_HIGH)
		{
			WM8580_IICWrite(0x0e, 0x063);						//SAIF 2	Receiver Audio format		0x063
			WM8580_IICWrite(0x0c, 0x123);						//PAIF 3	Receiver Audio format		0x123						
		}
		else if (eFormat == DURING_PCMSYNC_HIGH)
		{
			WM8580_IICWrite(0x0e, 0x073);						//SAIF 2	Receiver Audio format		0x073
			WM8580_IICWrite(0x0c, 0x133);						//PAIF 3	Receiver Audio format		0x133				
		}
		else
			Assert(0);
	}
	WM8580_IICWrite(0x0f, 0x024);				//DAC Control 1	
	if (eFormat == DURING_PCMSYNC_HIGH || eFormat == AFTER_PCMSYNC_HIGH)
		WM8580_IICWrite(0x10, 0x005);			//DAC Control 2	Left & Right DAC Souce : Left Channel
	else
		WM8580_IICWrite(0x10, 0x009);			//DAC Control 2	Left DAC : Left Channel, Right DAC : Right Channel
	WM8580_IICWrite(0x11, 0x000);				//DAC Control 3
	WM8580_IICWrite(0x12, 0x000);				//DAC Control 4
	WM8580_IICWrite(0x13, 0x000);				//DAC Control 5
	WM8580_IICWrite(0x1c, 0x1cf);				//Master Digital Attenuation
	Audio_CloseIICPort();
	/*switch(eSampleRate)
		{
			case 96000:
				//24.576MHz 
				WM8580_IICWrite(0x00, 0x1ba);				//PLL A K-Value : C49BA 
				WM8580_IICWrite(0x01, 0x024);				//PLL A N-Value : 8
				WM8580_IICWrite(0x02, 0x082);				//PLL A Divider : 
				WM8580_IICWrite(0x03, 0x002);				//PLL A 
				break;
			case 48000:
				//12.288MHz 
				WM8580_IICWrite(0x00, 0x1ba);				//PLL A K-Value : C49BA 
				WM8580_IICWrite(0x01, 0x024);				//PLL A N-Value : 8
				WM8580_IICWrite(0x02, 0x082);				//PLL A 
				WM8580_IICWrite(0x03, 0x006);				//PLL A 
				break;
			case 32000:
				//8.192MHz 
				WM8580_IICWrite(0x00, 0x1ba);				//PLL A K-Value : C49BA 
				WM8580_IICWrite(0x01, 0x024);				//PLL A N-Value : 8
				WM8580_IICWrite(0x02, 0x082);				//PLL A 
				WM8580_IICWrite(0x03, 0x00c);				//PLL A 
				break;
			case 16000:
				//6.144MHz 
				WM8580_IICWrite(0x00, 0x1ba);				//PLL A K-Value : C49BA 
				WM8580_IICWrite(0x01, 0x024);				//PLL A N-Value : 8
				WM8580_IICWrite(0x02, 0x082);				//PLL A 
				WM8580_IICWrite(0x03, 0x00a);				//PLL A 
				break;
			case 8000:
				//4.096MHz 
				WM8580_IICWrite(0x00, 0x1ba);				//PLL A K-Value : C49BA 
				WM8580_IICWrite(0x01, 0x024);				//PLL A N-Value : 8
				WM8580_IICWrite(0x02, 0x082);				//PLL A 
				WM8580_IICWrite(0x03, 0x00e);				//PLL A 
				break;
			case 88200:
				//22.5792MHz 
				WM8580_IICWrite(0x00, 0x089);				//PLL A K-Value : 21B089
				WM8580_IICWrite(0x01, 0x0d8);				//PLL A N-Value : 7
				WM8580_IICWrite(0x02, 0x078);				//PLL A 
				WM8580_IICWrite(0x03, 0x002);				//PLL A 
				break;
			case 44100:
				//11.2896MHz 
				WM8580_IICWrite(0x00, 0x089);				//PLL A K-Value : 21B089 
				WM8580_IICWrite(0x01, 0x0d8);				//PLL A N-Value : 7
				WM8580_IICWrite(0x02, 0x078);				//PLL A 
				WM8580_IICWrite(0x03, 0x006);				//PLL A 
				break;
			case 22050:
				//5.6448MHz 
				WM8580_IICWrite(0x00, 0x089);				//PLL A K-Value : 21B089 
				WM8580_IICWrite(0x01, 0x0d8);				//PLL A N-Value : 7
				WM8580_IICWrite(0x02, 0x078);				//PLL A 
				WM8580_IICWrite(0x03, 0x00a);				//PLL A 
				break;
			case 11025:
				//2.8224MHz 
				WM8580_IICWrite(0x00, 0x089);				//PLL A K-Value : 21B089 
				WM8580_IICWrite(0x01, 0x0d8);				//PLL A N-Value : 7
				WM8580_IICWrite(0x02, 0x078);				//PLL A 
				WM8580_IICWrite(0x03, 0x002);				//PLL A 
				break;
			default:
				//24.576MHz 
				WM8580_IICWrite(0x00, 0x1ba);				//PLL A K-Value : C49BA 
				WM8580_IICWrite(0x01, 0x024);				//PLL A N-Value : 8
				WM8580_IICWrite(0x02, 0x082);				//PLL A 
				WM8580_IICWrite(0x03, 0x002);				//PLL A 
				break;
		}
		*/
}

void WM9713_CodecInitPCMIn(SerialDataFormat eFormat, u32 eSampleRate, OPMode eOpmode, PCMWordLength eWordLen, AudioSource eSource,CodecPort eCodecPort)
{
	#ifdef __AC97_H__
	AC97_CodecCmd(WRITE,0x26, 0x4f00);		// Enable PR5(Internal Clock, AC-link I/F)
	AC97_CodecCmd(WRITE,0x26, 0x4700);		// Enable PR3(VREF, I/P PGA's, DAC's, ADC's, Mixer, O/P's) 	
	AC97_CodecCmd(WRITE,0x3c, 0xfbff);			// Enable MBIAS generator
	Delay(1000);	
	AC97_CodecCmd(WRITE,0x26, 0x4300);		// Enable PR2(I/P PGA's and mixers)
	
	if (eFormat == ACLinkSlot34)					// Enable ADC L/R
		AC97_CodecCmd(WRITE,0x3C, 0xfbc3);	
	else if (eFormat == ACLinkSlot6)
		AC97_CodecCmd(WRITE,0x3C, 0xfbcf);	
	
	AC97_CodecCmd(WRITE,0x26, 0x4200);		// Enable Stereo ADC 				//4100
	AC97_CodecCmd(WRITE,0x26, 0x0200);		// Enable PR6 (O/P PGA's)						
	AC97_CodecCmd(WRITE,0x3E, 0xff9f);			// Enable LINE L/R PGA			26 0100
				
	
	AC97_CodecCmd(WRITE,0x2A,0x1);			//Variable Rate Enable	
	UART_Printf("VRA Enable(1)/Disable(0): 0x%x\n",(0x1&AC97_CodecCmd(READ,0x2A,0x0000)));
	if(eSampleRate == 8000)						//ADC Sampling frequency 8kHz
		AC97_CodecCmd(WRITE,0x32,0x1f40);	
	else if(eSampleRate == 44100)					//ADC Sampling frequency 44.1kHz
		AC97_CodecCmd(WRITE,0x32,0xac44);
	else if(eSampleRate == 22050)					//ADC Sampling frequency 22.05kHz
		AC97_CodecCmd(WRITE,0x32,0x5622);	 	
	else if(eSampleRate == 48000)					//ADC Sampling frequency 48kHz
		AC97_CodecCmd(WRITE,0x32,0xbb80);
	else
		Assert(0);								//Sample Rate is not supported. 
	//UART_Printf("\nAC97 Codec 0x32 Reg.: 0x%x\n\n", AC97_CodecCmd(READ,0x32,0x0000));
	if ( eFormat == ACLinkSlot34)
	{
		//AC97_CodecCmd(WRITE,0x3C, 0xfbc3);	// Enable ADC L/R					//fbf3
		AC97_CodecCmd(WRITE,0x14, 0xfe12);	// Record Mux Source Selection: LINE L/R
		AC97_CodecCmd(WRITE,0x1c, 0x00a0);
		AC97_CodecCmd(WRITE,0x04, 0x0303);
		AC97_CodecCmd(WRITE,0x12, 0x1010);	// Unmute ADC and Set ADC Recoding Volume	
	}
	else if (eFormat == ACLinkSlot6)
	{
		AC97_CodecCmd(WRITE,0x5C, 0x2);		// ADC Slot Mapping: Left(Slot 6), Right(Slot 9)	
		AC97_CodecCmd(WRITE,0x14, 0xfe12);	// Record Mux Source Selection: LINE L/R
		AC97_CodecCmd(WRITE,0x1c, 0x00a0);
		AC97_CodecCmd(WRITE,0x12, 0x1010);	// Unmute ADC and Set ADC Recoding Volume		
	}
	////////////////////////////////////////////////////////
	// codec setting to hear sound while PCM encoding 
	//uAc97cmd = AC97_CodecCmd(READ,0x14, 0x0000);
	//uAc97cmd =  uAc97cmd &  ~(3 << 14) & (~ (5 << 11));
	//AC97_CodecCmd(WRITE,0x14, 0x1612);
	//AC97_CodecCmd(WRITE,0x1c, 0x00a0);
	//AC97_CodecCmd(WRITE,0x04,0x0707);
	//UART_Printf("%x\n",AC97_CodecCmd(READ,0x14, 0x0000));	
	//UART_Printf("%x\n",AC97_CodecCmd(READ,0x0a, 0x0000));
	////////////////////////////////////////////////////////
	#else
	UART_Printf("AC97 Controller code is not included\n");
	#endif	
}

void WM9713_InitPCMOut(SerialDataFormat eFormat, u32 eSampleRate, OPMode eOpmode, PCMWordLength eWordLen, CodecPort eCodecPort)
{	
	#ifdef __AC97_H__
 	AC97_CodecCmd(WRITE,0x26, 0x4f00);	// Enable PR5(Internal Clock, AC-link I/F)
	AC97_CodecCmd(WRITE,0x26, 0x4700);	// Enable PR3(VREF, I/P PGA's, DAC's, ADC's, Mixer, O/P's)
 	
	AC97_CodecCmd(WRITE,0x3c, 0xfbff);		// Enable MBIAS generator
	Delay(1000);

	AC97_CodecCmd(WRITE,0x26, 0x4300);	// Enable PR2(I/P PGA's and mixers)
	AC97_CodecCmd(WRITE,0x3C, 0xfbf3);		// Enable HPL/R Mixer
	AC97_CodecCmd(WRITE,0x26, 0x4100);	// Enable PR1(Stereo DAC)
	AC97_CodecCmd(WRITE,0x3C, 0xfb33);	// Enable DAC L/R
	AC97_CodecCmd(WRITE,0x26, 0x0100);	// Enable PR6 (O/P PGA's)
	AC97_CodecCmd(WRITE,0x3E, 0xf9ff);		// Enable PR6 (O/P PGA's)

	AC97_CodecCmd(WRITE,0x2A,0x1);		//Variable Rate Enable	
	if(eSampleRate==8000)
		AC97_CodecCmd(WRITE,0x2C,0x1f40);		//DAC Sampling frequency 8kHz
	else if(eSampleRate==48000)
		AC97_CodecCmd(WRITE,0x2C,0xbb80);	//DAC Sampling frequency 48kHz
	else if(eSampleRate==44100)
		AC97_CodecCmd(WRITE,0x2C,0xac44);		//DAC Sampling frequency 44.1kHz
	else if(eSampleRate==22050)
		AC97_CodecCmd(WRITE,0x2C,0x5622);		//DAC Sampling frequency 22.05kHz
	else
		Assert(0);
	AC97_CodecCmd(WRITE,0x12,0x8000);		//Disable ADC because it makes noise when ADC is turn on
	AC97_CodecCmd(WRITE,0x1c, 0x00a0);	// HPL/R PGA input select HPMIXL/R
	AC97_CodecCmd(WRITE,0x04,0x0707);		// Set HPL/R Volume 
	AC97_CodecCmd(READ,0x04,0x00000);	//HP out volume 
	AC97_CodecCmd(WRITE,0x0c,0x6808);		// Unmute DAC to HP mixer path
	AC97_CodecCmd(WRITE,0x04,0x0A0A);	// Unmute HPL/R
	#endif	
}

//////////
// Function Name : WM9713_CodecInit
// Function Desctiption : Initialize WM9713(AC97/I2S/PCM) Codec.
// Input : 			eCh  - TX / RX
// 					eFormat  - Interface data format
// 					eSampleRate  - Sample Rate
// 					eOpmode  - Operating Mode of AP. 
// 					eWordLen  - PCM Data Length
// 					eSource  - Audio source of ADC
// 					CodecPort  - Codec interface port
// Output : None
// Version : 0.0
// Author : Sunghyun, Na
void WM9713_CodecInit(AUDIO_Interface eCh, SerialDataFormat eFormat, u32 eSampleRate, OPMode eOpmode, PCMWordLength eWordLen, AudioSource eSource, CodecPort eCodecPort)
{
	switch(eCh)
	{
		case AUDIO_Tx:
			AC97_CodecCmd(WRITE,0x26, 0x4f00);	//Enable PR5(Internal Clock, AC-link I/F)
			AC97_CodecCmd(WRITE,0x26, 0x4700);	//Enable PR3(VREF, I/P PGA's, DAC's, ADC's, Mixer, O/P's)
		 	AC97_CodecCmd(WRITE,0x3c, 0xfbff);		//Enable MBIAS generator
			Delay(1000);
			AC97_CodecCmd(WRITE,0x26, 0x4300);	//Enable PR2(I/P PGA's and mixers)
			AC97_CodecCmd(WRITE,0x3C, 0xfbf3);		//Enable HPL/R Mixer
			AC97_CodecCmd(WRITE,0x26, 0x4100);	//Enable PR1(Stereo DAC)
			AC97_CodecCmd(WRITE,0x3C, 0xfb33);	//Enable DAC L/R
			AC97_CodecCmd(WRITE,0x26, 0x0100);	//Enable PR6 (O/P PGA's)
			AC97_CodecCmd(WRITE,0x3E, 0xf9ff);		//Enable PR6 (O/P PGA's)
			if (eSampleRate >= 48000)
			{
				AC97_CodecCmd(WRITE,0x2A,0x0);		//Variable Rate Disable	
				AC97_CodecCmd(WRITE,0x2C,0xbb80);	//DAC Sampling frequency 48kHz
			}
			else
			{
				AC97_CodecCmd(WRITE,0x2A,0x1);			//Variable Rate Enable	
				AC97_CodecCmd(WRITE,0x2C,eSampleRate);	//DAC Sampling frequency
			}
			UART_Printf("VRA Enable(1)/Disable(0): 0x%x\n",(0x1&AC97_CodecCmd(READ,0x2A,0x0000)));
			AC97_CodecCmd(WRITE,0x12,0x8000);		//Disable ADC because it makes noise when ADC is turn on
			AC97_CodecCmd(WRITE,0x1c, 0x00a0);	// HPL/R PGA input select HPMIXL/R
			AC97_CodecCmd(WRITE,0x04,0x0707);		// Set HPL/R Volume 			
			AC97_CodecCmd(WRITE,0x0c,0x6808);		// Unmute DAC to HP mixer path
			AC97_CodecCmd(WRITE,0x04,0x0A0A);	// Unmute HPL/R
			// codec setting to hear sound while PCM encoding -> need to Modify
			//uAc97cmd = AC97_CodecCmd(READ,0x14, 0x0000);
			//uAc97cmd =  uAc97cmd &  ~(3 << 14) & (~ (5 << 11));
			//AC97_CodecCmd(WRITE,0x14, 0x1612);
			//AC97_CodecCmd(WRITE,0x1c, 0x00a0);
			//AC97_CodecCmd(WRITE,0x04,0x0707);
			//UART_Printf("%x\n",AC97_CodecCmd(READ,0x14, 0x0000));	
			//UART_Printf("%x\n",AC97_CodecCmd(READ,0x0a, 0x0000));			
			break;
			
		case AUDIO_Rx:
			AC97_CodecCmd(WRITE,0x26, 0x4f00);		//Enable PR5(Internal Clock, AC-link I/F)
			AC97_CodecCmd(WRITE,0x26, 0x4700);		//Enable PR3(VREF, I/P PGA's, DAC's, ADC's, Mixer, O/P's) 	
			AC97_CodecCmd(WRITE,0x3c, 0xfbff);			//Enable MBIAS generator
			Delay(1000);	
			AC97_CodecCmd(WRITE,0x26, 0x4300);		//Enable PR2(I/P PGA's and mixers)
			if (eFormat == ACLinkSlot34)					//Enable ADC L/R
				AC97_CodecCmd(WRITE,0x3C, 0xfbc3);	
			else if (eFormat == ACLinkSlot6)
				AC97_CodecCmd(WRITE,0x3C, 0xfbcf);				
			AC97_CodecCmd(WRITE,0x26, 0x4200);		//Enable Stereo ADC 				//4100
			AC97_CodecCmd(WRITE,0x26, 0x0200);		//Enable PR6 (O/P PGA's)						
			AC97_CodecCmd(WRITE,0x3E, 0xbf9f);			//Enable LINE L/R PGA			26 0100			
			if (eSampleRate >= 48000)
			{
				AC97_CodecCmd(WRITE,0x2A,0x0);		//Variable Rate Disable	
				AC97_CodecCmd(WRITE,0x32,0xbb80);	//ADC Sampling frequency 48kHz
			}
			else
			{
				AC97_CodecCmd(WRITE,0x2A,0x1);			//Variable Rate Enable	
				AC97_CodecCmd(WRITE,0x32,eSampleRate);	//ADC Sampling frequency
			}
			UART_Printf("VRA Enable(1)/Disable(0): 0x%x\n",(0x1&AC97_CodecCmd(READ,0x2A,0x0000)));		
			if ( eFormat == ACLinkSlot34)
			{
				//AC97_CodecCmd(WRITE,0x3C, 0xfbc3);	// Enable ADC L/R					//fbf3
				AC97_CodecCmd(WRITE,0x14, 0xfe12);	// Record Mux Source Selection: LINE L/R
				AC97_CodecCmd(WRITE,0x1c, 0x00a0);
				AC97_CodecCmd(WRITE,0x04, 0x0303);
				AC97_CodecCmd(WRITE,0x12, 0x1010);	// Unmute ADC and Set ADC Recoding Volume	
			}
			else if (eFormat == ACLinkSlot6)
			{
				AC97_CodecCmd(WRITE,0x5C, 0x2);		// ADC Slot Mapping: Left(Slot 6), Right(Slot 9)	
				AC97_CodecCmd(WRITE,0x14, 0xfe12);	// Record Mux Source Selection: LINE L/R
				AC97_CodecCmd(WRITE,0x1c, 0x00a0);
				AC97_CodecCmd(WRITE,0x12, 0x1010);	// Unmute ADC and Set ADC Recoding Volume		
			}				
			break;
		case AUDIO_TxRx:
		default:
			AC97_CodecCmd(WRITE,0x26, 0x4f00);	//Enable PR5(Internal Clock, AC-link I/F)
			AC97_CodecCmd(WRITE,0x26, 0x4700);	//Enable PR3(VREF, I/P PGA's, DAC's, ADC's, Mixer, O/P's)
			AC97_CodecCmd(WRITE,0x3c, 0xfbff);		//Enable MBIAS generator
			Delay(1000);
			AC97_CodecCmd(WRITE,0x26, 0x4300);	//Enable PR2(I/P PGA's and mixers)
			AC97_CodecCmd(WRITE,0x3C, 0xfb03);	//Enable ADC L/R
			if (eSource == LINEIN)					
				AC97_CodecCmd(WRITE,0x14, 0xfe12);	//Record Mux Source Selection: LINE L/R
			else if (eSource == MICIN)
				AC97_CodecCmd(WRITE,0x14, 0xfe40);	//Record Mux Source Selection: MICA Enable 20dB gain Booster
			AC97_CodecCmd(WRITE,0x26, 0x4000);	//Enable PR1/PR0 (Stereo DACs and ADCs)
			AC97_CodecCmd(WRITE,0x26, 0x0000);	//Enable PR6 (O/P PGA's)		
			AC97_CodecCmd(WRITE,0x3E, 0xb990);	//Enable PGAs of LINE In L/R HPL,HPR and microphone bias
			if (eSampleRate >= 48000)
			{
				AC97_CodecCmd(WRITE,0x2A,0x0);		//Variable Rate Disable	
				AC97_CodecCmd(WRITE,0x2C,0xbb80);	//DAC Sampling frequency 48kHz
				AC97_CodecCmd(WRITE,0x32,0xbb80);	//ADC Sampling frequency 48kHz
			}
			else
			{
				AC97_CodecCmd(WRITE,0x2A,0x1);			//Variable Rate Enable	
				AC97_CodecCmd(WRITE,0x2C,eSampleRate);	//DAC Sampling frequency
				AC97_CodecCmd(WRITE,0x32,eSampleRate);	//ADC Sampling frequency
			}
			UART_Printf("VRA Enable(1)/Disable(0): 0x%x\n",(0x1&AC97_CodecCmd(READ,0x2A,0x0000)));	
			AC97_CodecCmd(WRITE,0x04, 0x0a0a);	//HeadPhone output Volume
			AC97_CodecCmd(WRITE,0x0c, 0x6808);	//Unmute DAC to HP mixer path
			AC97_CodecCmd(WRITE,0x12, 0x0f0f);		//Unmute ADC and Set ADC Recoding Volume, Standard Record Gain : 22.5dB	
			AC97_CodecCmd(WRITE,0x1c, 0x00a0);	//Control input PGA 			
			if ( eFormat == ACLinkSlot34)
				AC97_CodecCmd(WRITE,0x5C, 0x0);		// ADC Slot Mapping: Left(Slot 3), Right(Slot 4)					
			else if (eFormat == ACLinkSlot6)
				AC97_CodecCmd(WRITE,0x5C, 0x2);		// ADC Slot Mapping: Left(Slot 6), Right(Slot 9)					
			break;	
	}
}

//////////
// Function Name : WM9713_GetVolume
// Function Desctiption : This function gets Audio Codec Volume.
// Input : 			eCh  - TX / RX
// Output : None
// Version : 0.0
// Author : Sunghyun, Na
u32 WM9713_GetVolume(AUDIO_Interface eCh)
{
	u32 uVolRegister;
	if (eCh == AUDIO_Rx)
	{
		uVolRegister = AC97_CodecCmd(READ,0x12,0x00000);	//HP out volume 
		uVolRegister &= (0x3f);
		return uVolRegister;
	}
	else 
	{
		uVolRegister = AC97_CodecCmd(READ,0x04,0x00000);	//HP out volume 
		uVolRegister &= (0x3f);
		return uVolRegister;
	}
}	

//////////
// Function Name : WM9713_SetVolume
// Function Desctiption : This function sets Audio Codec Gain.
// Input : 			eCh  - TX / RX
// Output : u8 - Limited Volume Range
// Version : 0.0
// Author : Sunghyun, Na
u8 WM9713_SetVolume(AUDIO_Interface eCh, s32 uVolume)
{
	u16 uVolRegister;
	if (eCh == AUDIO_Rx)
	{
		if ( uVolume >= 0xf || uVolume <= 0x0 )
		{
			return FALSE;	
		}
		else 
		{
			uVolRegister = AC97_CodecCmd(READ,0x12,0);			//Read ADC Gain
			uVolRegister &= ~(0xf << 8) & ~(0xf << 0);
			uVolRegister |= (uVolume << 8) | (uVolume << 0);
			AC97_CodecCmd(WRITE,0x12,(u16) uVolRegister);				//ADC Gain		
			return TRUE;
		}
	}
	else 
	{
		if ( uVolume < WM9713_MAXVOL || uVolume > WM9713_MINVOL )
		{
			return FALSE;	
		}
		else
		{
			uVolRegister = AC97_CodecCmd(READ, 0x04, 0);		//Read HP out volume Register
			uVolRegister &= ~(0x3f << 8) & ~(0x3f << 0);
			uVolRegister |= ((u16) uVolume << 8) | ((u16) uVolume << 0);
			AC97_CodecCmd(WRITE,0x04,(u16) uVolRegister);				//HP out volume 
			return TRUE;
		}
	}
}	

//////////
// Function Name : WM8990_CodecInitPCMIn
// Function Desctiption : Codec Initialization that WM8990 ADC enable to give Digital Data
// Input : 			eFormat  - Interface data format
// 					eSampleRate  - Sample Rate
// 					eOpmode  - Operating Mode of AP. 
// 					eWordLen  - PCM Data Length
// 					eSource  - Audio source of ADC
// 					CodecPort  - Codec interface port
// Output : None
// Version : 0.0
// Author : Sunghyun, Na
void WM8990_CodecInitPCMIn(SerialDataFormat eFormat, u32 eSampleRate, OPMode eOpmode, PCMWordLength eWordLen, AudioSource eSource, CodecPort eCodecPort)
{
	Audio_InitIICPort();
	Audio_InitIIC();
	#if 1
	WM8990_IICWrite(0x00, 0x8990);			// Software Codec Reset 
	WM8990_IICWrite(0x01, 0x0003);			// Enable Vmid = 50K, Vref
	Delay(1000);		
	WM8990_IICWrite(0x02, 0x0303);			// Enable AIN MUX, ADC 
	WM8990_IICWrite(0x03, 0x0000);			// Disable Output	
	if ( eCodecPort == CodecPort_1st )					
	{
		if ( eOpmode == Slave)					// Codec master
		{
			WM8990_IICWrite(0x08, 0x8000);
			WM8990_IICWrite(0x0a, 0x0400);
			WM8990_IICWrite(0x06, 0x000a);
			WM8990_IICWrite(0x07, 0x0000);
		}
		else										// Codec Slave
		{
			WM8990_IICWrite(0x08,  0x0000);
		}
	}	
	else if ( eCodecPort == CodecPort_2nd )	
	{
		if ( eOpmode == Slave)					// Codec master
		{
			WM8990_IICWrite(0x07, 0x0000);
			WM8990_IICWrite(0x08, 0x8000);
			WM8990_IICWrite(0x0a, 0x0400);
			WM8990_IICWrite(0x06, 0x000a);
		}
		else										// Codec Slave
		{
			WM8990_IICWrite(0x08,  (u32) eOpmode << 14 | 0x2000);
		}
	}	
	switch(eFormat)
	{
		case MSBJustified:
			if (eWordLen == Word24)	
				WM8990_IICWrite(0x04, 0x4048);		//24bit Left justified 			
			else
				WM8990_IICWrite(0x04, 0x4008);		//16bit Left justified 		
			break;			
		case LSBJustified:
			if (eWordLen == Word24)
				WM8990_IICWrite(0x04, 0x4040);		//24bit Right justified 			
			else 
				WM8990_IICWrite(0x04, 0x4000);		//16bit Right justified 	
			break;		
		case AFTER_PCMSYNC_HIGH:
			WM8990_IICWrite(0x04, 0x4118);			//16bit DSP Format		
			break;			
		case DURING_PCMSYNC_HIGH:
			WM8990_IICWrite(0x04, 0x4198);			//16bit DSP Format
			break;			
		case I2SFormat:
			if (eWordLen == Word24)	
				WM8990_IICWrite(0x04, 0x4050);		//24bit I2S 			
			else
				WM8990_IICWrite(0x04, 0x4010);		//16bit I2S
			break;
		default:
			Assert(0);
			break;			
	}
	WM8990_IICWrite(0x2b, 0x0140);			// Input Left Mixer
	WM8990_IICWrite(0x2c, 0x0140);			// Input Right Mixer		
	WM8990_IICWrite(0x0e, 0x0100);			// Enable HPF
	WM8990_IICWrite(0x0f, 0x01c0);			// Left ADC Volume	
	WM8990_IICWrite(0x10, 0x01c0);			// Right ADC Volume	
	#else
	//Will be updated for MIC IN
	WM8990_IICWrite(0x01, 0x0003);			// Enable Vmid = 50K, Vref, SPK
	WM8990_IICWrite(0x02, 0x6242);			// Enable AIN, ADC, LIN1 Enable_CLK
	WM8990_IICWrite(0x03, 0x0000);			// Disable Output
	WM8990_IICWrite(0x04, 0x4010);			// I2S 16Bit
	WM8990_IICWrite(0x18, 0x011f);			// Lin2Vol = +30dB	
	WM8990_IICWrite(0x28, 0x0030);			// LI2MNBST = 0dB
	WM8990_IICWrite(0x29, 0x0020);			// LI2MNBST = 0dB
	WM8990_IICWrite(0x27, 0x0000);			// AIN MODE = 00, From Left Input Mixer	
	WM8990_IICWrite(0x0e, 0x0100);			// Enable HPF
	WM8990_IICWrite(0x0f, 0x01c0);			// LADCVOL
	#endif
}


//////////
// Function Name : WM8990_CodecInitPCMOut
// Function Desctiption : Codec Initialization that WM8990 ADC enable to give Digital Data
// Input : 			eFormat  - Interface data format
// 					eSampleRate  - Sample Rate
// 					eOpmode  - Operating Mode of AP. 
// 					eWordLen  - PCM Data Length
// 					CodecPort  - Codec interface port
// Output : None
// Version : 0.0
// Author : Sunghyun, Na
void WM8990_CodecInitPCMOut(SerialDataFormat eFormat, u32 eSampleRate, OPMode eOpmode, PCMWordLength eWordLen, CodecPort eCodecPort)
{
	Audio_InitIICPort();
	Audio_InitIIC();	
	WM8990_IICWrite(0x00, 0x8990);			// Software Codec Reset 
	WM8990_IICWrite(0x39, 0x0046);			// Enable POBCTRL, SOFT_ST, BUFIOEN and BUFDCOPEN
	WM8990_IICWrite(0x01, 0x0300);			// Enable L/R Out
	WM8990_IICWrite(0x03, 0x0033);			// Enable left and fight output mixers (DACL & DACR remain enabled)
	WM8990_IICWrite(0x38, 0x0000);			// Disable DIS_LOUT and DIS_ROUT	
	WM8990_IICWrite(0x01, 0x3020);			// Enable WMID SEL = 2 * 50K Ohm Divider (L/R Out remain)
	Delay(50);
	WM8990_IICWrite(0x01, 0x0303);			// Enable VREF, Disable OUT3, AC Coupled mode
	WM8990_IICWrite(0x39, 0x0000);			// Disable POBCTRL and SOFT_ST, BUFIOEN and BUFDCONPEN remain enabled
	//if ( eCodecPort == CodecPort_1st )					// Codec Operation is Slave
	//	WM8990_IICWrite(0x08,  (u32) eOpmode << 15 | 0x0);
	//else if ( eCodecPort == CodecPort_2nd )	
	//	WM8990_IICWrite(0x08,  (u32) eOpmode << 14 | 0x2000);
	if ( eCodecPort == CodecPort_1st )					// Codec Operation is Slave
	{
		if ( eOpmode == Slave)
		{
			WM8990_IICWrite(0x06, 0x000a);
			WM8990_IICWrite(0x07, 0x0000);
			WM8990_IICWrite(0x08, 0x8800);
			WM8990_IICWrite(0x09, 0x0802);
			WM8990_IICWrite(0x0a, 0x0400);
			
		}
		else
			WM8990_IICWrite(0x08,  0x0000);
	}
	else if ( eCodecPort == CodecPort_2nd )	
	{
		if ( eOpmode == Slave)
		{
			WM8990_IICWrite(0x07, 0x0000);
			WM8990_IICWrite(0x08, 0x8000);
			WM8990_IICWrite(0x0a, 0x0400);
			WM8990_IICWrite(0x06, 0x000a);
		}
		else
			WM8990_IICWrite(0x08,  (u32) eOpmode << 14 | 0x2000);
	}	
	switch(eFormat)
	{
		case MSBJustified:
			if (eWordLen == Word24)	
				WM8990_IICWrite(0x04, 0x4048);		//24bit Left justified 			
			else 					
				WM8990_IICWrite(0x04, 0x4008);		//16bit Left justified 		
			break;			
		case LSBJustified:
			if (eWordLen == Word24)
				WM8990_IICWrite(0x04, 0x4040);		//24bit Right justified 			
			else 					
				WM8990_IICWrite(0x04, 0x4000);		//16bit Right justified 	
			break;			
		case AFTER_PCMSYNC_HIGH:
			WM8990_IICWrite(0x04, 0x4118);			//16bit PCM I/F 		
			WM8990_IICWrite(0x05, 0x0000);			//16bit PCM I/F 		
			break;			
		case DURING_PCMSYNC_HIGH:
			WM8990_IICWrite(0x04, 0x4198);			//16bit PCM I/F 	
			WM8990_IICWrite(0x05, 0x0000);			//16bit PCM I/F 		
			break;			
		case I2SFormat:
			if (eWordLen == Word24)	
				WM8990_IICWrite(0x04, 0x4050);		//24bit I2S 			
			else 					
				WM8990_IICWrite(0x04, 0x4010);		//16bit I2S
			break;
		default:
			Assert(0);
			break;				
	}
	WM8990_IICWrite(0x2d, 0x0001);			// Enable Left DAC to left mixer
	WM8990_IICWrite(0x2e, 0x0001);			// Enable Right DAC to right mixer	
	Delay(50);
	WM8990_IICWrite(0x1c, 0x00e7);			// LOUT VOL (HP) = -18dB
	WM8990_IICWrite(0x1d, 0x01e7);			// ROUT VOL (HP) = -18dB, Enable OPVU -> load volume setting to both left and right
	WM8990_IICWrite(0x0a, 0x00c0);			// DAC Digital Soft Mute enable an DAC unmute set
}

//////////
// Function Name : WM8990_CodecInitPCMIn
// Function Desctiption : Codec Initialization that WM8990 ADC enable to give and DAC enable to take PCM Data.
// Input : 			eFormat  - Interface data format
// 					eSampleRate  - Sample Rate
// 					eOpmode  - Operating Mode of AP. 
// 					eWordLen  - PCM Data Length
// 					eSource  - Audio source of ADC
// 					CodecPort  - Codec interface port
// Output : None
// Version : 0.0
// Author : Sunghyun, Na
void WM8990_CodecInitFullDuplex(SerialDataFormat eFormat, u32 eSampleRate, OPMode eOpmode, PCMWordLength eWordLen, AudioSource eSource, CodecPort eCodecPort)
{

	//Data In////////////////////////////////////////////////////////////
	Audio_InitIICPort();
	Audio_InitIIC();
	WM8990_IICWrite(0x00, 0x8990);			// Software Codec Reset 
	WM8990_IICWrite(0x01, 0x0303);			// Enable VREF, Disable OUT3, AC Coupled mode
	Delay(1000);
	WM8990_IICWrite(0x02, 0x0303);			// Enable AIN MUX, ADC 
	WM8990_IICWrite(0x03, 0x0033);			// Enable left and fight output mixers (DACL & DACR remain enabled)
	switch(eFormat)
	{
		case MSBJustified:
			if (eWordLen == Word24)	
				WM8990_IICWrite(0x04, 0x4048);		//24bit Left justified 			
			else 					
				WM8990_IICWrite(0x04, 0x4008);		//16bit Left justified 		
			break;			
		case LSBJustified:
			if (eWordLen == Word24)
				WM8990_IICWrite(0x04, 0x4040);		//24bit Right justified 			
			else 					
				WM8990_IICWrite(0x04, 0x4000);		//16bit Right justified 	
			break;			
		case AFTER_PCMSYNC_HIGH:
			WM8990_IICWrite(0x04, 0x0118);			//16bit PCM I/F 		
			WM8990_IICWrite(0x05, 0x0000);			//Left DAC source speak out Stereo
			break;			
		case DURING_PCMSYNC_HIGH:
			WM8990_IICWrite(0x04, 0x0198);			//16bit PCM I/F 
			WM8990_IICWrite(0x05, 0x0000);			//Left DAC source speak out Stereo	
			break;			
		case I2SFormat:
			if (eWordLen == Word24)	
				WM8990_IICWrite(0x04, 0x4050);		//24bit I2S 			
			else 					
				WM8990_IICWrite(0x04, 0x4010);		//16bit I2S
			break;
		default:
			Assert(0);
			break;				
	}
	if ( eCodecPort == CodecPort_1st )					// Codec Operation is Slave
	{
		if ( eOpmode == Slave)
		{
			WM8990_IICWrite(0x06, 0x000a);
			WM8990_IICWrite(0x07, 0x0000);
			WM8990_IICWrite(0x08, 0x8800);
			WM8990_IICWrite(0x09, 0x0802);
			WM8990_IICWrite(0x0a, 0x0400);
			
		}
		else
			WM8990_IICWrite(0x08,  0x0000);
	}
	else if ( eCodecPort == CodecPort_2nd )	
	{
		if ( eOpmode == Slave)
		{
			WM8990_IICWrite(0x07, 0x0000);
			WM8990_IICWrite(0x08, 0x8000);
			WM8990_IICWrite(0x0a, 0x0400);
			WM8990_IICWrite(0x06, 0x000a);
		}
		else
			WM8990_IICWrite(0x08,  (u32) eOpmode << 14 | 0x2000);
	}		
	WM8990_IICWrite(0x2b, 0x0140);			// Input Left Mixer
	WM8990_IICWrite(0x2c, 0x0140);			// Input Right Mixer	
	WM8990_IICWrite(0x2d, 0x0001);			// Enable Left DAC to left mixer
	WM8990_IICWrite(0x2e, 0x0001);			// Enable Right DAC to right mixer	
	Delay(50);
	WM8990_IICWrite(0x0a, 0x00c0);			// DAC Digital Soft Mute enable an DAC unmute set
	WM8990_IICWrite(0x0e, 0x0100);			// Enable HPF
	WM8990_IICWrite(0x0f, 0x01c0);			// Left ADC Volume	
	WM8990_IICWrite(0x10, 0x01c0);			// Right ADC Volume	
	WM8990_IICWrite(0x1c, 0x01ef);			// LOUT VOL (HP) = -18dB
	WM8990_IICWrite(0x1d, 0x01ef);			// ROUT VOL (HP) = -18dB, Enable OPVU -> load volume setting to both left and right
	WM8990_IICWrite(0x38, 0x0000);			// Disable DIS_LOUT and DIS_ROUT	
	Delay(50);
	WM8990_IICWrite(0x39, 0x0000);			// Disable POBCTRL and SOFT_ST, BUFIOEN and BUFDCONPEN remain enabled
}



void Parser_32to24(u32* rhs_pStartAddr, u32 rhs_uSize, u32 *rhs_pNewAddr)
{
	u8* pBufferAddr = (u8 *)rhs_pNewAddr;				//able to change
	u8* pTempAddr = (u8 *)rhs_pStartAddr;
	s32 uSize = (rhs_uSize/4)*3;						//for word access
	s32 uCnt = 0;
	
	do
	{
		for (uCnt = 0;uCnt < 3;uCnt++)
		{
			*pBufferAddr++ = *pTempAddr++;			
			uSize--;
		}
		pTempAddr++;
	}while(uSize >= 0);
	UART_Printf("End Address is 0x%x\n", (u32) pBufferAddr);
}

void Parser_24to32(u32* rhs_pStartAddr, u32 rhs_uSize, u32 *rhs_pNewAddr)
{
	u8* pBufferAddr = (u8 *)rhs_pNewAddr;				//able to change
	u8* pTempAddr = (u8 *)rhs_pStartAddr;
	s32 uSize = (rhs_uSize/3)*4;						//for word access
	s32 uCnt = 0;
	
	do
	{
		for (uCnt = 0;uCnt < 3;uCnt++)
		{
			*pBufferAddr++ = *pTempAddr++;			
			uSize--;
		}
		*pBufferAddr++ = 0;
	}while(uSize >= 0);
}

void Decomp32to24(u32* rhs_pStartAddr, u32 rhs_uSize, u32 *rhs_pNewAddr)
{
	u32* pBufferAddr = rhs_pNewAddr;				//able to change
	u32* pTempAddr = rhs_pStartAddr;
	s32 sSize = rhs_uSize;
	u32 uTemp;	
	
	do
	{
		uTemp = *pTempAddr;
		uTemp = uTemp >> 8;
		*pBufferAddr++ = uTemp;
		sSize = sSize - 4;		
	}while(sSize >= 0);
}

u32* Wave_Parser(u32 uWaveStartAddr, u8* uTotch, u32* uSampleRate, u8* uBitperch, u32* uSize)
{
	u32* uWaveDataAddr;
	
	u8* pch=(u8 *)(uWaveStartAddr+8);//8 is wave loc offset
	u16* u16data=(u16 *)(uWaveStartAddr+0x16);
	u32* u32data=(u32 *)(uWaveStartAddr+0x18);
	
	if(pch[0] == 'W' && pch[1] == 'A' && pch[2] == 'V' && pch[3] == 'E')
	{
		*uTotch = *u16data;
		*uSampleRate = *u32data;
		
		*uBitperch=*(unsigned short *)(uWaveStartAddr+0x22);
		
		
		pch=(unsigned char *)(uWaveStartAddr+0x28-4);
		if(pch[0] == 'd' && pch[1] == 'a' && pch[2] == 't' && pch[3] == 'a')
		{
			*uSize = *(unsigned int *)(uWaveStartAddr+0x28);
			*uWaveDataAddr = (uWaveStartAddr+0x28+4);			
		}
		else
		{
			pch=(unsigned char *)(uWaveStartAddr+0x40-4);
			if(pch[0] == 'd' && pch[1] == 'a' && pch[2] == 't' && pch[3] == 'a')		
			{
				*uSize = *(unsigned int *)(uWaveStartAddr+0x40);
				*uWaveDataAddr = (uWaveStartAddr+0x40+4);				
			}
			else
			{
			
				pch=(unsigned char *)(uWaveStartAddr+0x4c-4);
				if(pch[0] == 'd' && pch[1] == 'a' && pch[2] == 't' && pch[3] == 'a')		
				{
					*uSize = *(unsigned int *)(uWaveStartAddr+0x4c);
					*uWaveDataAddr = (uWaveStartAddr+0x4c+4);				
				}
				else
				{			
					pch=(unsigned char *)(uWaveStartAddr+0x7c-4);
					if(pch[0] == 'd' && pch[1] == 'a' && pch[2] == 't' && pch[3] == 'a')		
					{
						*uSize = *(unsigned int *)(uWaveStartAddr+0x7c);
						*uWaveDataAddr = (uWaveStartAddr+0x7c+4);					
					}
					else
						*uSize = 0;
				}
			}
			
		}		
		
		UART_Printf("wave parsed result : totch : %d, samplerate : %d, bitperch : %d, size : %d byte",*uTotch, *uSampleRate, *uBitperch, *uSize);		
		return uWaveDataAddr;
	}
	else return 0;
}


// Ver 0.3 


//////////
// Function Name : WM8753_CodecInit
// Function Desctiption : This function initialeze ADC and DAC of WM8753 Input Condition
// Input : Serial Data Format, Sample Rate, Operation mode, PCM Word Length, SMDK Line CodecClk Source
// Output : None
// Version : 0.0
// Author : Sunghyun, Na
void WM8753_CodecInit(AUDIO_Interface eIFMode, SerialDataFormat eFormat, u32 eSampleRate, OPMode eOpmode, PCMWordLength eWordLen, AudioSource eSource, CodecPort eCodecPort)
{
	Audio_InitIICPort();
	Audio_InitIIC();
	switch(eIFMode)
	{	
		case AUDIO_Rx:
			switch(eSource)
			{
				case LINEIN:
					break;
				case MICIN:
					break;
				default:
					Assert(0);
					break;
			}
			WM8753_IICWrite(0x01, 0x008);	//DAC Control Mute	
			WM8753_IICWrite(0x02, 0x000);	//ADC Control
			break;
		case AUDIO_Tx:
			WM8753_IICWrite(0x14, 0x0dc);	//Power Management(1)
			WM8753_IICWrite(0x17, 0x003);	//Power Management(4)
			Delay(1000);			
			WM8753_IICWrite(0x01, 0x000);	//DAC Control No Mute
			WM8753_IICWrite(0x02, 0x000);	//ADC Control
			break;
		case AUDIO_TxRx:
			switch(eSource)
			{
				case LINEIN:
					break;
				case MICIN:
					break;
				default:
					Assert(0);
					break;
			}
			break;
		default:
			Assert(0);
			break;
	}

	switch(eCodecPort)
	{

	}
	

}

void WM8753_SetPLL(u8 usActive, u32 uInputFreq, u32 uOutputFreq)
{
	Audio_InitIICPort();
	Audio_InitIIC();
}

//////////
// Function Name : WM8990_InitCodec
// Function Desctiption : This function initialeze ADC and/or DAC of WM8990 by parameter.
// Input : Serial Data Format, Sample Rate, Operation mode, PCM Word Length, SMDK Line CodecClk Source
// Output : None
// Version : 0.0
// Author : Sunghyun, Na
void WM8990_InitCodec(AUDIO_Interface eIFMode, SerialDataFormat eFormat, u32 eSampleRate, OPMode eOpmode, PCMWordLength eWordLen, AudioSource eSource, CodecPort eCodecPort)
{
	Audio_InitIICPort();
	Audio_InitIIC();
	WM8990_IICWrite(0x00, 0x8990);			// Software Codec Reset 
	switch(eIFMode)
	{
		case AUDIO_Tx:
			break;
		case AUDIO_Rx:
			break;
		case AUDIO_TxRx:
			break;
		default:
			Assert(0);
			break;

	}

}

void WM8990_SetPLL()
{

}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#if 0
#define IICOutp32(offset, x)	Outp32(offset, x)
#define IICInp32(offset) 		Inp32(offset)
void PCM_CODEC_IICWrite(u32 uSlaveAddr, u32 uAddr, u8 uData)
{
	u32 i;
	u8 uI2cData[2];
	s32 uI2cDataCount;
	u32 uI2cPt;	

	#if ( PCM_CODEC == AK2430)
		

		uI2cData[0]   = (unsigned char)uAddr;
		uI2cData[1]   = uData;
		uI2cDataCount = 2;
		uI2cPt = 0;

		IICOutp32(rIICCON0, (1<<7) | (0<<6) | (1<<5) | (0xf)); //Enable ACK, Prescaler IICCLK=PCLK/16, Enable interrupt, Transmit clock value Tx clock=IICCLK/16
		IICOutp32(rIICSTAT0, 0x10);	//IIC bus data output enable(Rx/Tx)
		IICOutp32(rIICLC0, (1<<2)|(1)); 	//Filter enable, 5 clocks SDA output delay    //

		//Data Write Phase
		IICOutp32(rIICDS0, uSlaveAddr); //0xa0
		IICOutp32(rIICSTAT0, 0xf0);      

		while(uI2cDataCount != -1)
		{
			if(IICInp32(rIICCON0)& 0x10)
			{                  

				if((uI2cDataCount--)==0)
				{
					IICOutp32(rIICSTAT0, 0xd0);	//stop MasTx condition 
					IICOutp32(rIICCON0, 0xaf);   //resumes IIC operation.

					Delay(1);  //wait until stop condtion is in effect.
					break;    
				}

			IICOutp32(rIICDS0, uI2cData[uI2cPt++]); 

			for(i=0;i<10;i++);	//for setup time until rising edge of IICSCL
				IICOutp32(rIICCON0, 0xaf); 	//resumes IIC operation.

			}      
		}

		IICOutp32(rIICSTAT0, 0xd0); 	//Master Tx condition, Stop(Write), Output Enable 
		IICOutp32(rIICCON0, 0xaf);	//Resumes IIC operation. 

		Delay(1);  //Wait until stop condtion is in effect.      
	
	
	#elif ( PCM_CODEC == WM8753)	

		uI2cData[0]   = (unsigned char)uAddr;
		uI2cData[1]   = uData;
		uI2cDataCount = 2;
		uI2cPt = 0;

		IICOutp32(rIICCON0, (1<<7) | (0<<6) | (1<<5) | (0xf)); 	//Enable ACK, Prescaler IICCLK=PCLK/16, Enable interrupt, Transmit clock value Tx clock=IICCLK/16
		IICOutp32(rIICSTAT0, 0x10);							//IIC bus data output enable(Rx/Tx)
		IICOutp32(rIICLC0, (1<<2)|(3)); 						//Filter enable, 15 clocks SDA output delay    //

		//Data Write Phase
		IICOutp32(rIICDS0, uSlaveAddr); 	//0xa0
		IICOutp32(rIICSTAT0, 0xf0);      

		while(uI2cDataCount != -1)
		{
			if(IICInp32(rIICCON0)& 0x10)
			{                  

				if((uI2cDataCount--)==0)
				{
					IICOutp32(rIICSTAT0, 0xd0);		//stop MasTx condition 
					IICOutp32(rIICCON0, 0xaf);  		//resumes IIC operation.

					Delay(1);  //wait until stop condtion is in effect.
					break;    
				}

				IICOutp32(rIICDS0, uI2cData[uI2cPt++]); 

				for(i=0;i<10;i++);	//for setup time until rising edge of IICSCL
					IICOutp32(rIICCON0, 0xaf); 	//resumes IIC operation.

			}      
		}

		IICOutp32(rIICSTAT0, 0xd0); 	//Master Tx condition, Stop(Write), Output Enable 
		IICOutp32(rIICCON0, 0xaf);	//Resumes IIC operation. 

		Delay(1);  //Wait until stop condtion is in effect.      
	
	
	#else
		Assert(0);
	
	#endif

}


u8 PCM_CODEC_IICRead(u32 uSlaveAddr, u8 uAddr)
{
	u8  uI2cData;
	s32 uI2cDataCount;
	u32 i;

	#if ( PCM_CODEC == AK2430)	

		uI2cData  = uAddr;
		uI2cDataCount = 1;

		//Register Address Write Phase
		IICOutp32(rIICCON,0 (1<<7) | (0<<6) | (1<<5) | (0<<4) | (0xf));//Enable ACK, Prescaler IICCLK=PCLK/16, Enable interrupt, Transmit clock value Tx clock=IICCLK/16
		IICOutp32(rIICSTAT0, 0x10); //IIC bus data output enable(Rx/Tx)	
		IICOutp32(rIICLC0, (1<<2)|(1)); //Filter enable, 15 clocks SDA output delay    		

		IICOutp32(rIICDS0, uSlaveAddr);
		IICOutp32(rIICSTAT0, 0xf0);	//MasTx,Start 


		while(uI2cDataCount!=-1)
		{
			if(IICInp32(rIICCON0) & 0x10) 
			{	
				//Tx/Rx Interrupt Enable
				if((uI2cDataCount--)==0)
				{
					break;                
				}
				IICOutp32(rIICDS0, uI2cData);
				for(i=0;i<10;i++); 	//for setup time until rising edge of IICSCL
					IICOutp32(rIICCON0, 0xaf);	//resumes IIC operation.	
			}
		}   

		uI2cDataCount = 1;
		IICOutp32(rIICCON0, (1<<7) | (0<<6) | (1<<5) | (0<<4) | (0xf));

		//Register Data Read Phase 
		IICOutp32(rIICDS0, uSlaveAddr);

		IICOutp32(rIICSTAT0, 0xb0);	//Master Rx,Start

		while(uI2cDataCount!=-1)
		{
			if(IICInp32(rIICCON0) & 0x10)	//Interrupt pending 
			{
				if((uI2cDataCount--)==0)
				{
					uI2cData = IICInp32(rIICDS0);

					IICOutp32(rIICSTAT0, 0x90);		//Stop MasRx condition 
					IICOutp32(rIICCON0, 0xaf);       //Resumes IIC operation.

					Delay(1);                    //Wait until stop condtion is in effect.
					//Too long time... 
					//The pending bit will not be set after issuing stop condition.
					break;    
				}

				if((uI2cDataCount)==0)
					IICOutp32(rIICCON0, 0x2f);		//Resumes IIC operation with NOACK. 
				else 
					IICOutp32(rIICCON0, 0xaf);		//Resumes IIC operation with ACK

			}
		}


		return  uI2cData;
	

	#elif ( PCM_CODEC == WM8753)	
	
		uI2cData  = uAddr;
		uI2cDataCount = 1;

		//Register Address Write Phase
		IICOutp32(rIICCON0, (1<<7) | (0<<6) | (1<<5) | (0<<4) | (0xf));//Enable ACK, Prescaler IICCLK=PCLK/16, Enable interrupt, Transmit clock value Tx clock=IICCLK/16
		IICOutp32(rIICSTAT0, 0x10); //IIC bus data output enable(Rx/Tx)	
		IICOutp32(rIICLC0, (1<<2)|(1)); //Filter enable, 15 clocks SDA output delay    		

		IICOutp32(rIICDS0, uSlaveAddr);
		IICOutp32(rIICSTAT0, 0xf0);	//MasTx,Start 


		while(uI2cDataCount!=-1)
		{
			if(IICInp32(rIICCON0) & 0x10) 
			{	//Tx/Rx Interrupt Enable
				if((uI2cDataCount--)==0)
				{
					break;                
				}
					IICOutp32(rIICDS0, uI2cData);
					for(i=0;i<10;i++); 	//for setup time until rising edge of IICSCL
						IICOutp32(rIICCON0, 0xaf);	//resumes IIC operation.	
				}
		}   

		uI2cDataCount = 1;
		IICOutp32(rIICCON0, (1<<7) | (0<<6) | (1<<5) | (0<<4) | (0xf));

		//Register Data Read Phase 
		IICOutp32(rIICDS0, uSlaveAddr);
		IICOutp32(rIICSTAT0, 0xb0);	//Master Rx,Start

		while(uI2cDataCount!=-1)
		{
			if(IICInp32(rIICCON0) & 0x10)	//Interrupt pending 
			{
				if((uI2cDataCount--)==0)
				{
					uI2cData = IICInp32(rIICDS0);

					IICOutp32(rIICSTAT0, 0x90);		//Stop MasRx condition 
					IICOutp32(rIICCON0, 0xaf);       //Resumes IIC operation.

					Delay(1);                    //Wait until stop condtion is in effect.
					//Too long time... 
					//The pending bit will not be set after issuing stop condition.
					break;    
				}

				if((uI2cDataCount)==0)
					IICOutp32(rIICCON0, 0x2f);		//Resumes IIC operation with NOACK. 
				else 
					IICOutp32(rIICCON0, 0xaf);		//Resumes IIC operation with ACK
	
			}
		}

		return  uI2cData;
	
	
	#else	
		Assert(0);
	#endif


}

//////////
// Function Name : 
// Function Desctiption : 
// Input : Sync Rate, MSB Position, SCLK, CLKSRC
// Output : None
// Version : 0.0
// Author : Yoh-Han Lee
 

void PCM_CodecInitPCMIn(u32 eSync, u32 eSclk, SerialDataFormat eMSBPos,  PCM_CLKSRC eClkSrc)
{
	#if ( PCM_CODEC_NAME == AK2430)
	
	if(eSclk == 128000)
		uCodecSet = 0x0;
	else if(eSclk == 256000)
		uCodecSet = 0x1;
	else if(eSclk == 512000)
		uCodecSet = 0x2;

	PCM_CODEC_IICWrite(0x9e, 0x18, 0x07);	//MSTCLK_I = 19.2MHz

	if(eClkSrc ==PCM_PCMCDCLK)
		PCM_CODEC_IICWrite(0x9e, 0x1B, 0x0);	//PCM Codec Master Mode
	else
		PCM_CODEC_IICWrite(0x9e, 0x1B, 0x6);	//PCM Codec Slave Mode

	PCM_CODEC_IICWrite(0x9e, 0x1E, uCodecSet);	//DLCK = 128K,256kHz, or 512K, 14bit linear code (2's complement  format)

	PCM_CODEC_IICWrite(0x9e, 0x0D, 0x5);	//0 dB
	PCM_CODEC_IICWrite(0x9e, 0x06, 0x40);	//POP Mute Off

	PCM_CODEC_IICWrite(0x9e, 0x03, 0x01);	//CKI Buff On other blocks Off
	Delay(1);

	PCM_CODEC_IICWrite(0x9e, 0x03, 0x09);	//PLL2, CKI Buff On and other blocks Off
	Delay(300);

	PCM_CODEC_IICWrite(0x9e, 0x05, 0x10);	//TXSUM On and other blocks Off
	PCM_CODEC_IICWrite(0x9e, 0x05, 0x30);	//PCM Codec, TX Sum On and other blocks Off
	Delay(50);

	PCM_CODEC_IICWrite(0x9e, 0x0B, 0x11);	//sw_COI, sw_TX1 Close and other sw Open
	PCM_CODEC_IICWrite(0x9e, 0x05, 0x35);	//MIC AMP1, MIC BIAS1, PCM CODEC, TX SUM On and other bolcks OFF
	Delay(1600);
	
	#elif ( PCM_CODEC_NAME == WM9713)
	
	if(AC97_InitACLINK())
	{

		AC97_CodecCmd(WRITE,0x26, 0x4f00);		// Enable PR5(Internal Clock, AC-link I/F)
		AC97_CodecCmd(WRITE,0x26, 0x4700);		// Enable PR3(VREF, I/P PGA's, DAC's, ADC's, Mixer, O/P's)

		AC97_CodecCmd(WRITE,0x3C, 0xfbff);		// Enable MBIAS generator

		Delay(1000);
		
	#if 1
		AC97_CodecCmd(WRITE,0x26, 0x4300);		// Enable I/P PGA's nad Mixers
		AC97_CodecCmd(WRITE,0x3C, 0xfbcf);		// Enable ADC L 0xfbcf

		AC97_CodecCmd(WRITE,0x26, 0x4200);		// Enable Stereo ADC 
		AC97_CodecCmd(WRITE,0x26, 0x0200);		// Enable PR6 (O/P PGA's)

		//AC97_CodecCmd(WRITE,0x3E, 0xffbf);		// Enable LINE L PGA
		
		if (AUDIOIN == LINEIN)
			AC97_CodecCmd(WRITE,0x3E, 0xffaf);		// Enable LINE L/R PGA
		else if (AUDIOIN == MICIN)
			AC97_CodecCmd(WRITE,0x3E, 0xfff0);		// Enable MIC L/R PGA
		
		AC97_CodecCmd(WRITE,0x2A,0x1);			//Variable Rate Enable	
		UART_Printf("VRA Enable(1)/Disable(0): 0x%x\n",(0x1&AC97_CodecCmd(READ,0x2A,0x0001)));
		AC97_CodecCmd(WRITE,0x32, 0x1f40);		// ADC SR = 8kHz
		//AC97_CodecCmd(WRITE,0x14, 0xfe52);		// Record Mux Source Selection: LINE L/R			//11 111 11 0 0 1 010 010	 =  1111 1110 0101 0010
		if (AUDIOIN == LINEIN)
		{
			AC97_CodecCmd(WRITE,0x14, 0xfe52);		// Record Mux Source Selection: LINE L/R	 0xfe12
		}
		else if (AUDIOIN == MICIN)
		{
			AC97_CodecCmd(WRITE,0x22, 0x4040);		//MIC Preamp Contorl : MIC2A only, 12dB, MICBias
			AC97_CodecCmd(WRITE,0x10, 0x68);			//Unmute MIC routing : unmute MICA, MICA only 
			AC97_CodecCmd(WRITE,0x14, 0xfe00);		//Record Mux Source Selection: MICA
		}

		AC97_CodecCmd(WRITE,0x12, 0x1010);
		AC97_CodecCmd(WRITE,0x04,0x0707);
		AC97_CodecCmd(WRITE,0x12, 0x1010);		// Unmute ADC and Set ADC Recoding Volume
		
		//AC97_CodecCmd(WRITE,0x5C, 0x0008);	// ADC High-Pass Filter On -> this function remove noise where is no input
		//AC97_CodecCmd(WRITE,0x5A, 0x0020);	// HPF Corner Freq.
		
		//AC97_CodecCmd(WRITE,0x60, 0xf0f0); 		//ALC control 1111 1111 1111 1111
		AC97_CodecCmd(WRITE,0x62, 0x04fbf);		//ALC On : Upper 2 bytes are relate on ALC and Lower 2 bytes are relate on Noise Gate 
		

		AC97_CodecCmd(WRITE,0x12, 0x3f00);		// Unmute ADC and Set ADC Recoding Volume	

		if (eMSBPos == DURING_PCMSYNC_HIGH)	
			AC97_CodecCmd(WRITE,0x36, 0xa6b3);	// PCM IF=DSP B type, 16Bit, Slave Mode, Fs=8kHz		1010 0110 1110 0011
		else 										//AFTER_PCMSYNC_HIGH = Dsp  Mode A
			AC97_CodecCmd(WRITE,0x36, 0xa6a3);	// PCM IF=DSP A type, 16Bit, Slave Mode, Fs=8kHz		1010 0110 1010 0011
		//AC97_CodecCmd(WRITE,0x44, 0x0b80);	// PCM CLK = 8kHz									0000 1011 1000 0000
		AC97_CodecCmd(WRITE,0x4C, 0xffde);			// GPIO config. For PCM IF (Slave mode) 

	#else
		AC97_CodecCmd(WRITE,0x42, 0x0000);
		AC97_CodecCmd(WRITE,0x26, 0x4300);
		AC97_CodecCmd(WRITE,0x3c, 0xebde);
		AC97_CodecCmd(WRITE,0x26, 0x4200);
		AC97_CodecCmd(WRITE,0x26, 0x020d);
		AC97_CodecCmd(WRITE,0x3e, 0xdfef);
		AC97_CodecCmd(WRITE,0x32, 0x1f40);
		AC97_CodecCmd(WRITE,0x08, 0xdf40);
		AC97_CodecCmd(WRITE,0x12, 0x0000);
		AC97_CodecCmd(WRITE,0x14, 0xfe1b);
		AC97_CodecCmd(WRITE,0x18, 0xff20);
		AC97_CodecCmd(WRITE,0x1c, 0x8000);
		if (g_oPCMState.PCMMSBPosition == DURING_PCMSYNC_HIGH)	
			AC97_CodecCmd(WRITE,0x36, 0xa6e3);		// PCM IF=DSP B type, 16Bit, Slave Mode, Fs=8kHz		1010 0110 1110 0011
		else 															//AFTER_PCMSYNC_HIGH = Dsp  Mode A
			AC97_CodecCmd(WRITE,0x36, 0xa6a3);		// PCM IF=DSP A type, 16Bit, Slave Mode, Fs=8kHz		1010 0110 1010 0011
		AC97_CodecCmd(WRITE,0x44, 0x0b80);		// PCM CLK = 8kHz									0000 1011 1000 0000
		AC97_CodecCmd(WRITE,0x4C, 0xffde);		// GPIO config. For PCM IF (Slave mode) 
	#endif				
	}

	#elif ( PCM_CODEC_NAME == WM8753)
	
	//PCM_CODEC_IICWrite(0x34, 0x3e, 0x00);	//Reset
	PCM_CODEC_IICWrite(0x34, 0x1f, 0x00);	//Reset

	PCM_CODEC_IICWrite(0x34, 0x02, 0x08);	//DAC Control Mute
	PCM_CODEC_IICWrite(0x34, 0x04, 0x00);	//ADC Control
	
	if (eMSBPos == DURING_PCMSYNC_HIGH)
		PCM_CODEC_IICWrite(0x34, 0x07, 0xb3);	//PCM Audio I/F
	else 
		PCM_CODEC_IICWrite(0x34, 0x07, 0xa3);	//PCM Audio I/F
		
	PCM_CODEC_IICWrite(0x34, 0x08, 0x0a);	//HiFi Audio I/F
	PCM_CODEC_IICWrite(0x34, 0x0a, 0x00);	//Interface Control << Voice Codec >>

	//PCM_CODEC_IICWrite(0x34, 0x0c, 0x34);	//Sync Rate Control 
	if (eSync == 8000)
		PCM_CODEC_IICWrite(0x34, 0x0c, 0x0c);	//Sync Rate Control 8KHz
	else if (eSync == 16000)     
		PCM_CODEC_IICWrite(0x34, 0x0c, 0x14);	//Sync Rate Control 16KHz 
	else if (eSync == 32000)
		PCM_CODEC_IICWrite(0x34, 0x0c, 0x18);	//Sync Rate Control 32KHz 
	else if (eSync == 48000)
		PCM_CODEC_IICWrite(0x34, 0x0c, 0x00);	//Sync Rate Control 48KHz 
	else if (eSync == 96000)	
		PCM_CODEC_IICWrite(0x34, 0x0c, 0x1e);	//Sync Rate Control 96KHz 
		
	PCM_CODEC_IICWrite(0x34, 0x0e, 0x97); 	//Sample Rate Control (2), Don't care in case of slave mode
	PCM_CODEC_IICWrite(0x34, 0x10, 0xff); 	//Left DAC Volume
	PCM_CODEC_IICWrite(0x34, 0x12, 0xff); 	//Right DAC Volume
	PCM_CODEC_IICWrite(0x34, 0x18, 0x7b); 	//ALC 1
	PCM_CODEC_IICWrite(0x34, 0x1a, 0x00); 	//ALC 2
	PCM_CODEC_IICWrite(0x34, 0x1c, 0x32); 	//ALC 3
	PCM_CODEC_IICWrite(0x34, 0x1e, 0x00); 	//Noise Gate 
	PCM_CODEC_IICWrite(0x34, 0x21, 0xc3); 	//Left ADC Volume
	PCM_CODEC_IICWrite(0x34, 0x23, 0xc3); 	//Right ADC Volume
	PCM_CODEC_IICWrite(0x34, 0x24, 0xc0); 	//Additional Control
	PCM_CODEC_IICWrite(0x34, 0x26, 0x00); 	//Three D Control
	PCM_CODEC_IICWrite(0x34, 0x28, 0xc0); 	//Power Management(1) << Power up VMID[50K ohm]; VREF >>
	PCM_CODEC_IICWrite(0x34, 0x2a, 0x0c); 	//Power Management(2) << Power up ADCL/R >>
	PCM_CODEC_IICWrite(0x34, 0x2c, 0x00); 	//Power Management(3)
	PCM_CODEC_IICWrite(0x34, 0x2e, 0x00); 	//Power Management(4)
	PCM_CODEC_IICWrite(0x34, 0x30, 0x00); 	//ID Register
	PCM_CODEC_IICWrite(0x34, 0x32, 0x00); 	//Int. Polarty
	PCM_CODEC_IICWrite(0x34, 0x34, 0x00);	//Int. Enable
	PCM_CODEC_IICWrite(0x34, 0x36, 0x00);	//GPIO Control (1)
	PCM_CODEC_IICWrite(0x34, 0x38, 0x00);	//GPIO Control (2)

	PCM_CODEC_IICWrite(0x34, 0x40, 0x55);	//Record Mix (1)
	PCM_CODEC_IICWrite(0x34, 0x42, 0x05);	//Record Mix (2)
	PCM_CODEC_IICWrite(0x34, 0x44, 0x50);	//Left Out Mix(1)
	PCM_CODEC_IICWrite(0x34, 0x46, 0x55);	//Left Out Mix(2)
	PCM_CODEC_IICWrite(0x34, 0x48, 0x50);	//Rigth Out Mix(1)
	PCM_CODEC_IICWrite(0x34, 0x4a, 0x55);	//Right Out Mix(2)
	PCM_CODEC_IICWrite(0x34, 0x4c, 0x50);	//Mono Out Mix(1)
	PCM_CODEC_IICWrite(0x34, 0x4e, 0x55);	//Mono Out Mix(2)

	PCM_CODEC_IICWrite(0x34, 0x50, 0x79);	//LOUT1 Volume
	PCM_CODEC_IICWrite(0x34, 0x52, 0x79);	//ROUT1 Volume
	PCM_CODEC_IICWrite(0x34, 0x54, 0x79);	//LOUT2 Volume
	PCM_CODEC_IICWrite(0x34, 0x56, 0x79);	//ROUT2 Volume
	PCM_CODEC_IICWrite(0x34, 0x58, 0x79);	//MONO Out
	PCM_CODEC_IICWrite(0x34, 0x5a, 0x00);	//Output Control
	PCM_CODEC_IICWrite(0x34, 0x5c, 0x05);	//ADC Input Mode << Set L/R ADC input select to Line 1/2 '01' >>
	PCM_CODEC_IICWrite(0x34, 0x5e, 0x00);	//Input Control (1)
	PCM_CODEC_IICWrite(0x34, 0x60, 0x00);	//Input Control (2)
	PCM_CODEC_IICWrite(0x34, 0x62, 0x97);	//Left Input Volume
	PCM_CODEC_IICWrite(0x34, 0x64, 0x97);	//Right Input Volume
	PCM_CODEC_IICWrite(0x34, 0x66, 0x00);	//MIC Bias Comp Control

	PCM_CODEC_IICWrite(0x34, 0x68, 0x04);	//Clock Control << Clock for Voice Codec = MCLK or PLL1
	PCM_CODEC_IICWrite(0x34, 0x6a, 0x00);	//PLL1 Control (1)
	PCM_CODEC_IICWrite(0x34, 0x6c, 0x83);	//PLL1 Control (2)
	PCM_CODEC_IICWrite(0x34, 0x6e, 0x24);	//PLL1 Control (3)
	PCM_CODEC_IICWrite(0x34, 0x71, 0xba);	//PLL1 Control (4)

	PCM_CODEC_IICWrite(0x34, 0x72, 0x00);	//PLL2 Control (1)
	PCM_CODEC_IICWrite(0x34, 0x74, 0x83);	//PLL2 Control (2)
	PCM_CODEC_IICWrite(0x34, 0x76, 0x24);	//PLL2 Control (3)
	PCM_CODEC_IICWrite(0x34, 0x79, 0xba);	//PLL2 Control (4)

	PCM_CODEC_IICWrite(0x34, 0x7a, 0x00);	//Bias Control
	PCM_CODEC_IICWrite(0x34, 0x7e, 0x00);	//Additional Control
	
	#endif
}

void PCM_CodecExitPCMIn(AUDIO_PORT ePort)
{

	#if (PCM_CODEC_NAME == AK2430)
	PCM_CODEC_IICWrite(0x9e, 0x05, 0x30);	//MIC Amp1, MIC Bias1 Off	
	Delay(1300);
	PCM_CODEC_IICWrite(0x9e, 0x0B, 0x00);	//sw_COI, sw_TX1 Open	
	PCM_CODEC_IICWrite(0x9e, 0x05, 0x00);	//TX SUM, PCM Codec Off
	
	#elif ( PCM_CODEC_NAME == WM9713)
	AC97_CodecCmd(WRITE,0x3E, 0xffff);		//Disable LINE L/R output PGA's
	AC97_CodecCmd(WRITE,0x26, 0xff00);		//Disable I/P PGA's nad Mixers	
	
	#endif
}


void PCM_CodecInitPCMOut(u32 eSync, u32 eSclk, SerialDataFormat eMSBPos,  PCM_CLKSRC eClkSrc)
{

	
	#if (PCM_CODEC == AK2430)
	

	if(eSclk == 128000)
		uCodecSet = 0x0;
	else if(eSclk == 256000)
		uCodecSet = 0x1;
	else if(eSclk == 512000)
		uCodecSet = 0x2;

	PCM_CODEC_IICWrite(0x9e, 0x18, 0x07);		//MSTCLK_I = 19.2MHz

	if(eClkSrc ==PCM_PCMCDCLK)
		PCM_CODEC_IICWrite(0x9e, 0x1B, 0x0);		//PCM Codec Master Mode
	else
		PCM_CODEC_IICWrite(0x9e, 0x1B, 0x6);		//PCM Codec Slave Mode
        	
	PCM_CODEC_IICWrite(0x9e, 0x1E, uCodecSet);	//DLCK = 128K,256kHz, or 512K, 14bit linear code (2's complement  format)
	PCM_CODEC_IICWrite(0x9e, 0x0C, 0x00);		//0 dB
	PCM_CODEC_IICWrite(0x9e, 0x10, 0x1F);		//three dB
	PCM_CODEC_IICWrite(0x9e, 0x11, 0x1F);  		 //three dB
	PCM_CODEC_IICWrite(0x9e, 0x06, 0x40);		//POP Mute Off     
	PCM_CODEC_IICWrite(0x9e, 0x03, 0x01);		//CKI Buff On other blocks Off
	Delay(1); 
	PCM_CODEC_IICWrite(0x9e, 0x03, 0x09);		//PLL2, CKI Buff On and other blocks Off
	Delay(300);
	PCM_CODEC_IICWrite(0x9e, 0x04, 0x01);		//RXSUM On and other blocks Off
	PCM_CODEC_IICWrite(0x9e, 0x05, 0x20);		//PCM Codec On and other blocks Off
	Delay(50);
	PCM_CODEC_IICWrite(0x9e, 0x07, 0x20);		//sw_COL Close and other sw Open
	PCM_CODEC_IICWrite(0x9e, 0x08, 0x20);		//sw_COR Close and othr sw Open
	PCM_CODEC_IICWrite(0x9e, 0x09, 0x14);		//sw_EPL, sw_EPR Amp output
	PCM_CODEC_IICWrite(0x9e, 0x04, 0x31);		//EPL/R Amp(RXSUM) On and other blocks Off
	Delay(1600);
	
	#elif ( PCM_CODEC == WM9713)
	
	if(AC97_InitACLINK())
	{
		AC97_CodecCmd(WRITE,0x26, 0x4f00);		// Enable PR5(Internal Clock, AC-link I/F)
		AC97_CodecCmd(WRITE,0x26, 0x4700);		// Enable PR3(VREF, I/P PGA's, DAC's, ADC's, Mixer, O/P's)

		AC97_CodecCmd(WRITE,0x3C, 0xfbff);		// Enable MBIAS generator
		Delay(1000);

		AC97_CodecCmd(WRITE,0x26, 0x4300);		// Enable I/P PGA's nad Mixers
		AC97_CodecCmd(WRITE,0x3C, 0xebf3);		// Enable VXDAC, L/R HP
		AC97_CodecCmd(WRITE,0x26, 0x4100);		// Enable DAC
		AC97_CodecCmd(WRITE,0x26, 0x0100);		// Enable PR6 (O/P PGA's)
		AC97_CodecCmd(WRITE,0x3E, 0xf9ff);		// Enable HPL/R output PGA's

		AC97_CodecCmd(WRITE,0x1C, 0x00a0);		// HPL/R PGA input select: HPMIXL/R
		AC97_CodecCmd(WRITE,0x04, 0x8a8a);		// Set HL/R Volume = -6dB

		AC97_CodecCmd(WRITE,0x2A,0x1);			//Variable Rate Enable	
		UART_Printf("VRA Enable(1)/Disable(0): 0x%x\n",(0x1&AC97_CodecCmd(READ,0x2A,0x0001)));
		AC97_CodecCmd(WRITE,0x2E, 0x1f40);		// AUXDAC = 8kHz

		AC97_CodecCmd(WRITE,0x12,0x8000);		//Disable ADC because it makes noise when ADC is turn on
		AC97_CodecCmd(WRITE,0x18, 0x02aa);		// Unmute VXDAC to HPMIXL/R
		AC97_CodecCmd(WRITE,0x04, 0x0f0f);		// Unmute HPL/R

		if (eSync == DURING_PCMSYNC_HIGH)			//DURING_PCMSYNC_HIGH = Dsp  Mode B
			AC97_CodecCmd(WRITE,0x36, 0xa6b3);		// PCM IF=DSP B type, 16Bit, Slave Mode, Fs=8kHz		1010 0110 0110 0011
		else 															//AFTER_PCMSYNC_HIGH = Dsp  Mode A
			AC97_CodecCmd(WRITE,0x36, 0xa6a3);		// PCM IF=DSP A type, 16Bit, Slave Mode, Fs=8kHz		1010 0110 0010 0011
		AC97_CodecCmd(WRITE,0x44, 0x0b80);		// PCM CLK = 8kHz
		AC97_CodecCmd(WRITE,0x4C, 0xffde);		// GPIO config. For PCM IF (Slave mode) 
	}
	

	#elif ( PCM_CODEC == WM8753)
	
	PCM_CODEC_IICWrite(0x34, 0x1f, 0x00);	//Reset

	PCM_CODEC_IICWrite(0x34, 0x28, 0xd0);	//PWR Management(1) << Power up VMID[50Kohm]; VREF; VDAC >>
	PCM_CODEC_IICWrite(0x34, 0x2e, 0x03);	//PWR Management(4) << Power up L/RMIX >>
	Delay(1000);
	
	PCM_CODEC_IICWrite(0x34, 0x02, 0x08);	//DAC Control Mute
	PCM_CODEC_IICWrite(0x34, 0x04, 0x00);	//ADC Control
	
	if (eSync == DURING_PCMSYNC_HIGH)
		PCM_CODEC_IICWrite(0x34, 0x07, 0xb3);	//PCM Audio I/F Mode B
	else 
		PCM_CODEC_IICWrite(0x34, 0x07, 0xa3);	//PCM Audio I/F Mode A
	PCM_CODEC_IICWrite(0x34, 0x08, 0x0a);	//HiFi Audio I/F
	
	PCM_CODEC_IICWrite(0x34, 0x0a, 0x33);	//Interface Control << Voice Codec >>
	
	if (eSync == 8000)
		PCM_CODEC_IICWrite(0x34, 0x0c, 0x0c);	//Sync Rate Control 8KHz 
	else if (eSync == 16000)     
		PCM_CODEC_IICWrite(0x34, 0x0c, 0x14);	//Sync Rate Control 16KHz 
	else if (eSync == 32000)
		PCM_CODEC_IICWrite(0x34, 0x0c, 0x18);	//Sync Rate Control 32KHz
	else if (eSync == 48000)
		PCM_CODEC_IICWrite(0x34, 0x0c, 0x00);	//Sync Rate Control 48KHz
	else if (eSync == 96000)	
		PCM_CODEC_IICWrite(0x34, 0x0c, 0x1e);	//Sync Rate Control 96KHz
		
	PCM_CODEC_IICWrite(0x34, 0x0e, 0x97); 	//Sample Rate Control (2), Don't care in case of slave mode
	PCM_CODEC_IICWrite(0x34, 0x10, 0xff); 	//Left DAC Volume
	PCM_CODEC_IICWrite(0x34, 0x12, 0xff); 	//Right DAC Volume
	PCM_CODEC_IICWrite(0x34, 0x14, 0x0f); 	//Bass Control
	PCM_CODEC_IICWrite(0x34, 0x16, 0x0f); 	//Treble Control
	PCM_CODEC_IICWrite(0x34, 0x18, 0x7b); 	//ALC 1
	PCM_CODEC_IICWrite(0x34, 0x1a, 0x00); 	//ALC 2
	PCM_CODEC_IICWrite(0x34, 0x1c, 0x32); 	//ALC 3
	PCM_CODEC_IICWrite(0x34, 0x1e, 0x00); 	//Noise Gate 
	PCM_CODEC_IICWrite(0x34, 0x21, 0xc3); 	//Left ADC Volume
	PCM_CODEC_IICWrite(0x34, 0x23, 0xc3); 	//Right ADC Volume
	PCM_CODEC_IICWrite(0x34, 0x24, 0xc0); 	//Additional Control
	PCM_CODEC_IICWrite(0x34, 0x26, 0x00); 	//Three D Control
	PCM_CODEC_IICWrite(0x34, 0x2a, 0x00); 	//Power Management(2) 
	PCM_CODEC_IICWrite(0x34, 0x30, 0x00); 	//ID Register
	PCM_CODEC_IICWrite(0x34, 0x32, 0x00); 	//Int. Polarty
	PCM_CODEC_IICWrite(0x34, 0x34, 0x00);	//Int. Enable
	PCM_CODEC_IICWrite(0x34, 0x36, 0x00);	//GPIO Control (1)
	PCM_CODEC_IICWrite(0x34, 0x38, 0x00);	//GPIO Control (2)
	PCM_CODEC_IICWrite(0x34, 0x40, 0x55);	//Record Mix (1)
	PCM_CODEC_IICWrite(0x34, 0x42, 0x05);	//Record Mix (2)
	PCM_CODEC_IICWrite(0x34, 0x44, 0x50);	//Left Out Mix(1)
	PCM_CODEC_IICWrite(0x34, 0x47, 0x55);	//Left Out Mix(2) << Set the VXD2LO bit (Voice DAC to Left Output >>
	PCM_CODEC_IICWrite(0x34, 0x48, 0x50);	//Rigth Out Mix(1)
	PCM_CODEC_IICWrite(0x34, 0x4b, 0x55);	//Right Out Mix(2) << Set the VXD2RO bit (Voice DAC to Right Output) >>
	PCM_CODEC_IICWrite(0x34, 0x4c, 0x50);	//Mono Out Mix(1)
	PCM_CODEC_IICWrite(0x34, 0x4e, 0x55);	//Mono Out Mix(2)
	PCM_CODEC_IICWrite(0x34, 0x51, 0x79);	//LOUT1 Volume << Set Left OUtput 1 Volume Update bit to '1' & Volume Level to Default >>
	PCM_CODEC_IICWrite(0x34, 0x53, 0x79);	//ROUT1 Volume << Set Right OUtput 1 Volume Update bit to '1' & Volume Level to Default >>
	PCM_CODEC_IICWrite(0x34, 0x54, 0x79);	//LOUT2 Volume
	PCM_CODEC_IICWrite(0x34, 0x56, 0x79);	//ROUT2 Volume
	PCM_CODEC_IICWrite(0x34, 0x58, 0x79);	//MONO Out
	PCM_CODEC_IICWrite(0x34, 0x5a, 0x00);	//Output Control
	PCM_CODEC_IICWrite(0x34, 0x5c, 0x00);	//ADC Input Mode 
	PCM_CODEC_IICWrite(0x34, 0x5e, 0x00);	//Input Control (1)
	PCM_CODEC_IICWrite(0x34, 0x60, 0x00);	//Input Control (2)
	PCM_CODEC_IICWrite(0x34, 0x62, 0x97);	//Left Input Volume
	PCM_CODEC_IICWrite(0x34, 0x64, 0x97);	//Right Input Volume
	PCM_CODEC_IICWrite(0x34, 0x66, 0x00);	//MIC Bias Comp Control
	PCM_CODEC_IICWrite(0x34, 0x68, 0x04);	//Clock Control << Clock for Voice Codec = MCLK or PLL1
	PCM_CODEC_IICWrite(0x34, 0x6a, 0x00);	//PLL1 Control (1)
	PCM_CODEC_IICWrite(0x34, 0x6c, 0x83);	//PLL1 Control (2)
	PCM_CODEC_IICWrite(0x34, 0x6e, 0x24);	//PLL1 Control (3)
	PCM_CODEC_IICWrite(0x34, 0x71, 0xba);	//PLL1 Control (4)
	PCM_CODEC_IICWrite(0x34, 0x72, 0x00);	//PLL2 Control (1)
	PCM_CODEC_IICWrite(0x34, 0x74, 0x83);	//PLL2 Control (2)
	PCM_CODEC_IICWrite(0x34, 0x76, 0x24);	//PLL2 Control (3)
	PCM_CODEC_IICWrite(0x34, 0x79, 0xba);	//PLL2 Control (4)
	PCM_CODEC_IICWrite(0x34, 0x7a, 0x00);	//Bias Control
	PCM_CODEC_IICWrite(0x34, 0x7e, 0x00);	//Additional Control
	PCM_CODEC_IICWrite(0x34, 0x2d, 0x80); 	//Power Management(3) <<Power up L/ROUT1 outputs >>
		
	
	#endif
}



void PCM_CodecExitPCMOut(void)
{
	#if ( PCM_CODEC == AK2430)
	
		PCM_CODEC_IICWrite(0x9e, 0x04, 0x01);	//EPL/R Amp Off		
		Delay(1300);

		PCM_CODEC_IICWrite(0x9e, 0x07, 0x00);	//sw_COL Close and other sw Open
	   	PCM_CODEC_IICWrite(0x9e, 0x08, 0x00);	//sw_COR Close and othr sw Open
	   	PCM_CODEC_IICWrite(0x9e, 0x09, 0x00);	//sw_EPL, sw_EPR Amp output

		PCM_CODEC_IICWrite(0x9e, 0x04, 0x00);	//RXSUM Off	
		PCM_CODEC_IICWrite(0x9e, 0x05, 0x00);	//PCM Codec Off
	

	#elif ( PCM_CODEC == WM9713)
	
		AC97_CodecCmd(WRITE,0x3E, 0xffff);		//Disable HPL/R output PGA's
		AC97_CodecCmd(WRITE,0x26, 0xff00);		//Disable I/P PGA's nad Mixers
	
	#endif
	
}
#endif

