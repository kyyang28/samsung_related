#ifndef __AUDIO_H__
#define __AUDIO_H__
 
  
#ifdef __cplusplus
extern "C" {
#endif

#include "def.h"
#include "option.h"
#include "library.h"
#include "sfr6410.h"
#include "system.h"
#include "intc.h"

#define AUDIO_IICCLK			25000


#define WM8580MASTERCLK	CDCLK_I2SCDCLK
#define WM8753MASTERCLK	CDCLK_I2SCDCLK
#define CDCLK_I2SCDCLK		0
#define CDCLK_OSC			1
#define CDCLK_I2SMULTI		2

#define AUDIO_NUM			2
#define WM8753ID			0x34
#define WM8580ID			0x36
#define WM8990ID			0x34	//In SMDK 6400 Rev0.2, IIC Line of WM8753 or WM8580  shoud be disconnected when WM8990 is connected

#define WM9713_MAXVOL		0x0
#define WM9713_MINVOL		0x20
typedef enum
{
	AUDIO_PORT0 = 0,
	AUDIO_PORT1 = 1,
	AUDIO_PORT2 = 2
}AUDIO_PORT;

typedef enum
{
	AUDIOCon_AC97,
	AUDIOCon_I2S,
	AUDIOCon_PCM,
	AUDIOCon_I2SMulti,	
}AUDIO_Controller;

typedef enum
{
	AUDIO_Tx = 0,
	AUDIO_Rx = 1,
	AUDIO_TxRx = 3	
}AUDIO_Interface;

typedef enum
{
	AK2430 = 0,
	WM9713 = 1,		//There is some noise in WM9713 ADC Path on PCM interface
	WM8753 = 2, 
	STAC9767 = 3,
	WM8580 = 4,
	WM8990 = 5,
}AudioCodec;

typedef enum
{
	CodecPort_1st 		= 0,
	CodecPort_2nd 		= 1,
	CodecPort_3rd 		= 2,
}CodecPort;

typedef enum
{
	I2SFormat 				= 0,
	MSBJustified 				= 1,
	LSBJustified 				= 2,
	AFTER_PCMSYNC_HIGH 	= 3,
	DURING_PCMSYNC_HIGH 	= 4,
	ACLinkSlot34				= 5,
	ACLinkSlot6				= 6,
}SerialDataFormat;

typedef enum
{
	Master = 0,
	Slave = 1,
}OPMode;

typedef enum
{
	Word16 	= 0,
	Word8	= 1,
	Word24	= 2,
	Word20	= 3,
}PCMWordLength;




typedef enum
{
	LINEIN 	= 0,
	MICIN	= 1,
}AudioSource;

typedef enum
{
	Stereo		= 0,
	MonoLeft	= 1,
	MonoRight	= 2,
	Channel5_1	= 3,	
}AudioOutPutMode;


typedef enum
{
	CodecSource_I2S = 0,
	CodecSource_OSC = 1
}CodecClkSource;

void Audio_InitIICPort(void);
void Audio_CloseIICPort(void);

void WM8753_IICWrite(u8 rhs_uRegAddr, u32 rhs_uData);
void WM8580_IICWrite(u8 rhs_uRegAddr, u32 rhs_uData);
void WM8990_IICWrite(u8 rhs_uRegAddr, u32 rhs_uData);
u16 WM8990_IICRead(u16 rhs_uRegAddr);

void STAC9767_InitPCMIn(SerialDataFormat eFormat, u32 eSampleRate, OPMode eOpmode, PCMWordLength eWordLen, AudioSource eSource, CodecPort eCodecPort);
void STAC9767_InitPCMOut(SerialDataFormat eFormat, u32 eSampleRate, OPMode eOpmode, PCMWordLength eWordLen, CodecPort eCodecPort);

void WM8753_CodecInitPCMIn(SerialDataFormat eFormat, u32 eSampleRate, OPMode eOpmode, PCMWordLength eWordLen, AudioSource eSource, CodecPort eCodecPort);
void WM8753_CodecInitPCMOut(SerialDataFormat eFormat, u32 eSampleRate, OPMode eOpmode, PCMWordLength eWordLen, CodecPort eCodecPort);

void WM8580_CodecCLKOut(u32 uClockout);
void WM8580_CodecInitPCMIn(SerialDataFormat eFormat, u32 eSampleRate, OPMode eOpmode, PCMWordLength eWordLen, AudioSource eSource, CodecPort eCodecPort);
;void WM8580_CodecInitPCMOut(SerialDataFormat eFormat, u32 eSampleRate, OPMode eOpmode, PCMWordLength eWordLen, CodecPort eCodecPort);

void WM9713_CodecInitPCMIn(SerialDataFormat eFormat, u32 eSampleRate, OPMode eOpmode, PCMWordLength eWordLen, AudioSource eSource,CodecPort eCodecPort);
void WM9713_InitPCMOut(SerialDataFormat eFormat, u32 eSampleRate, OPMode eOpmode, PCMWordLength eWordLen, CodecPort eCodecPort);
void WM9713_CodecInit(AUDIO_Interface eCh, SerialDataFormat eFormat, u32 eSampleRate, OPMode eOpmode, PCMWordLength eWordLen, AudioSource eSource, CodecPort eCodecPort);
u32 WM9713_GetVolume(AUDIO_Interface eCh);
u8 WM9713_SetVolume(AUDIO_Interface eCh, s32 uVolume);

void WM8990_CodecInitPCMIn(SerialDataFormat eFormat, u32 eSampleRate, OPMode eOpmode, PCMWordLength eWordLen, AudioSource eSource, CodecPort eCodecPort);
void WM8990_CodecInitPCMOut(SerialDataFormat eFormat, u32 eSampleRate, OPMode eOpmode, PCMWordLength eWordLen, CodecPort eCodecPort);
void WM8990_CodecInitFullDuplex(SerialDataFormat eFormat, u32 eSampleRate, OPMode eOpmode, PCMWordLength eWordLen, AudioSource eSource, CodecPort eCodecPort);

void Parser_32to24(u32* rhs_pStartAddr, u32 rhs_uSize, u32 *rhs_pNewAddr);
void Parser_24to32(u32* rhs_pStartAddr, u32 rhs_uSize, u32 *rhs_pNewAddr);
void Decomp32to24(u32* rhs_pStartAddr, u32 rhs_uSize, u32 *rhs_pNewAddr);
u32* Wave_Parser(u32 uWaveStartAddr, u8* uTotch, u32* uSampleRate, u8* uBitperch, u32* uSize);


#ifdef __cplusplus
}
#endif

#endif /*__AUDIO_H__*/

