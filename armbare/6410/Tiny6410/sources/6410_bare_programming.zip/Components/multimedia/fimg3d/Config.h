/*******************************************************************************
 *
 *	ViP model for FIMGSE
 *		version 1.0
 *
 *	fimg_config.h
 *
 *	by cheolkyoo.kim
 *	Graphics IP Team in AP, Mobile Solution Development,
 *	System LSI Division, Semiconductor Business,
 *	Samsung Electronics
 *
 *	Copyright (c) 2005 FIMG team
 *
 *	All rights reserved. No part of this program may be reproduced, stored
 *	in a retrieval system, or tranmitted, in any form or by any means,
 *	electronic, mechanical, photocopying, recording, or otherwise, without
 *	the prior written permission of the author.
 *
 *	2006.  3.  27	by cheolkyoo.kim
 *		Controls configuration of FIMG build variants
 *
 *	$RCSfile: fimg_config.h,v $
 *	$Revision: 1.1 $
 *	$Author: cheolkyoo.kim $
 *	$Date: 2006/03/30 02:24:31 $
 *	$Locker:  $
 *
 *	$Source: C:/CVS/CVSrepository/FIMG-3DSE_SW/fimg3dse_fpga/fimg3d/include/fimg_config.h,v $
 *	$State: Exp $
 *	$Log: fimg_config.h,v $
 *	Revision 1.1  2006/03/30 02:24:31  cheolkyoo.kim
 *	Thomas-20060330@comment: Initial commit
 *	
 ******************************************************************************/
#if !defined(__CONFIG_H__)
#define __CONFIG_H__

// Display Resolutions
#define WVGA_LANDSCAPE  0 //WVGA (Wide VGA) screens have 800x480 pixels.
#define WVGA_PORTRAIT   1
#define HVGA_LANDSCAPE  2 //HVGA (Half-size VGA) screens have 480��320 pixels (3:2 aspect ratio).
#define HVGA_PORTRAIT   3
#define QVGA_LANDSCAPE  4 //QVGA (Quarter VGA) screens have 320x240 pixels.
#define QVGA_PORTRAIT   5

#define DISPLAY_RESOLUTION      (WVGA_LANDSCAPE)

#if   (DISPLAY_RESOLUTION == WVGA_LANDSCAPE)
    #define DISPLAY_WIDTH   800
    #define DISPLAY_HEIGHT  480
#elif (DISPLAY_RESOLUTION == WVGA_PORTRAIT)
    #define DISPLAY_WIDTH   480
    #define DISPLAY_HEIGHT  800
#elif (DISPLAY_RESOLUTION == HVGA_LANDSCAPE)
    #define DISPLAY_WIDTH   480
    #define DISPLAY_HEIGHT  320
#elif (DISPLAY_RESOLUTION == HVGA_PORTRAIT)
    #define DISPLAY_WIDTH   320
    #define DISPLAY_HEIGHT  480
#elif (DISPLAY_RESOLUTION == QVGA_LANDSCAPE)
    #define DISPLAY_WIDTH   320
    #define DISPLAY_HEIGHT  240
#else
    #define DISPLAY_WIDTH   240
    #define DISPLAY_HEIGHT  320
#endif


#define FIMG_LCDCON1		    0x77100020

#define FIMG_COLOR_BUFFER	    0x51000000	// WVGA F/B = 0X17_7000 : ~0X5117_7000
#define FIMG_COLOR_BUFFER_F	    0x51000000	// WVGA F/B = 0X17_7000 : ~0X5117_7000
#define FIMG_COLOR_BUFFER_B	    0x510BB800	// WVGA F/B = 0X17_7000 : ~0X5117_7000
#define FIMG_COLOR_BUFFER_0    	0x51000000	// WVGA F/B = 0X17_7000 : ~0X5117_7000
#define FIMG_COLOR_BUFFER_1    	0x51200000	// WVGA F/B = 0X17_7000 : ~0X5117_7000
#define FIMG_COLOR_BUFFER_2    	0x51400000	// WVGA F/B = 0X17_7000 : ~0X5117_7000
#define FIMG_DEPTH_BUFFER	    0x51600000	// 
#define FIMG_TEXTURE_MEMORY	    0x52000000  //
#define FIMG_GEOMETRY_MEMORY	0x52600000

#define SCREEN_WIDTH_SIZE		(DISPLAY_WIDTH)
#define SCREEN_HEIGHT_SIZE		(DISPLAY_HEIGHT)
#define LCD_HORIZONTAL_SIZE 	(DISPLAY_WIDTH)
#define LCD_VERTICAL_SIZE		(DISPLAY_HEIGHT)
#define BYTES_PER_PIXEL			4
#define LCD_XSIZE_TFT_240320	(DISPLAY_WIDTH)
#define LCD_YSIZE_TFT_240320	(DISPLAY_HEIGHT)
#define LCD_FRAME_BUFFER_XSIZE	(DISPLAY_WIDTH)
#define LCD_FRAME_BUFFER_YSIZE	(DISPLAY_HEIGHT)

#define CLEAR_SCREEN_SIZE	    (SCREEN_WIDTH_SIZE * SCREEN_HEIGHT_SIZE * BYTES_PER_PIXEL)
#define FRAME_BUFFER_SIZE	    (LCD_FRAME_BUFFER_XSIZE * LCD_FRAME_BUFFER_YSIZE * BYTES_PER_PIXEL)


#endif	/* __CONFIG_H__ */


