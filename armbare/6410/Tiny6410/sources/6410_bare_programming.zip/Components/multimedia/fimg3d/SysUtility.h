/**
 * Samsung Project
 * Copyright (c) 2007-2008 Mobile XG, Samsung Electronics, Inc.
 * All right reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file    SysUtility.h
 * @brief   This is the header file for the functions depended by system.
 * @author  Thomas, Kim
 * @version 1.5
 */
 
#if !defined(__SYS_UTILITY_H__)
#define __SYS_UTILITY_H_


#include "Defines.h"

extern "C" {
#include "fgl.h"
}

const default_reg gb_default_regs[] =
{
    { r_pipeline_state, 0, {FGGB_PIPESTATE,         0} },
    { r_cache_ctrl,     1, {FGGB_CACHECTL,          0} },
    { r_sw_reset,       0, {FGGB_RESET,             0} },
    { r_int_pending,    1, {FGGB_INTPENDING,        0} },
    { r_int_mask,       1, {FGGB_INTMASK,           0} },
    { r_pipeline_mask,  1, {FGGB_PIPEMASK,          0} },
    { r_pipeline_taget, 1, {FGGB_PIPETGTSTATE,      0} },
    { r_int_state,      0, {FGGB_PIPEINTSTATE,      0} }
};


const default_reg hi_default_regs[] =
{
    { r_fifo_empty_space, 0, {FGHI_DWSPACE,    0} },
    { r_fifo_entry_port,  0, {FGHI_DWENTRY,    0} },
    { r_hi_ctrl,          1, {FGHI_CONTROL,    0} },
    { r_idx_offset,       1, {FGHI_IDXOFFSET,  0} },
    { r_vtxbuf_addr,      1, {FGHI_VBADDR,     0} },
    { r_vtxbuf_entry_port,0, {FGHI_VBDATA,     0} },
    { r_attrib_ctrl0, 1, { FGHI_ATTRIB,         0} },
    { r_attrib_ctrl1, 1, {(FGHI_ATTRIB + 0x4 ), 0} },
    { r_attrib_ctrl2, 1, {(FGHI_ATTRIB + 0x8 ), 0} },
    { r_attrib_ctrl3, 1, {(FGHI_ATTRIB + 0xC ), 0} },
    { r_attrib_ctrl4, 1, {(FGHI_ATTRIB + 0x10), 0} },
    { r_attrib_ctrl5, 1, {(FGHI_ATTRIB + 0x14), 0} },
    { r_attrib_ctrl6, 1, {(FGHI_ATTRIB + 0x18), 0} },
    { r_attrib_ctrl7, 1, {(FGHI_ATTRIB + 0x1C), 0} },
    { r_attrib_ctrl8, 1, {(FGHI_ATTRIB + 0x20), 0} },
    { r_attrib_ctrl9, 1, {(FGHI_ATTRIB + 0x24), 0} },
    { r_vtxbuf_ctrl0, 1, {FGHI_ATTRIB_VBCTRL, 0} },
    { r_vtxbuf_ctrl1, 1, {(FGHI_ATTRIB_VBCTRL + 0x4 ), 0} },
    { r_vtxbuf_ctrl2, 1, {(FGHI_ATTRIB_VBCTRL + 0x8 ), 0} },
    { r_vtxbuf_ctrl3, 1, {(FGHI_ATTRIB_VBCTRL + 0xC ), 0} },
    { r_vtxbuf_ctrl4, 1, {(FGHI_ATTRIB_VBCTRL + 0x10), 0} },
    { r_vtxbuf_ctrl5, 1, {(FGHI_ATTRIB_VBCTRL + 0x14), 0} },
    { r_vtxbuf_ctrl6, 1, {(FGHI_ATTRIB_VBCTRL + 0x18), 0} },
    { r_vtxbuf_ctrl7, 1, {(FGHI_ATTRIB_VBCTRL + 0x1C), 0} },
    { r_vtxbuf_ctrl8, 1, {(FGHI_ATTRIB_VBCTRL + 0x20), 0} },
    { r_vtxbuf_ctrl9, 1, {(FGHI_ATTRIB_VBCTRL + 0x24), 0} },
    { r_vtxbuf_base0, 1, {FGHI_ATTRIB_VBBASE, 0} },
    { r_vtxbuf_base1, 1, {(FGHI_ATTRIB_VBBASE + 0x4 ), 0} },
    { r_vtxbuf_base2, 1, {(FGHI_ATTRIB_VBBASE + 0x8 ), 0} },
    { r_vtxbuf_base3, 1, {(FGHI_ATTRIB_VBBASE + 0xC ), 0} },
    { r_vtxbuf_base4, 1, {(FGHI_ATTRIB_VBBASE + 0x10), 0} },
    { r_vtxbuf_base5, 1, {(FGHI_ATTRIB_VBBASE + 0x14), 0} },
    { r_vtxbuf_base6, 1, {(FGHI_ATTRIB_VBBASE + 0x18), 0} },
    { r_vtxbuf_base7, 1, {(FGHI_ATTRIB_VBBASE + 0x1C), 0} },
    { r_vtxbuf_base8, 1, {(FGHI_ATTRIB_VBBASE + 0x20), 0} },
    { r_vtxbuf_base9, 1, {(FGHI_ATTRIB_VBBASE + 0x24), 0} },
};


const default_reg vs_default_regs[] =
{
    {r_vs_config,       1, {FGVS_CONFIG,            0}},
    {r_inter_status,    0, {FGVS_STATUS,            0}},
    {r_pc_range,        1, {FGVS_PCRANGE,           0}},
    {r_vs_attrib_num,   1, {FGVS_ATTRIBNUM,         0}},
    {r_in_attrib_idx0,  1, {FGVS_INATTRIBINDEX0,    0}},
    {r_in_attrib_idx1,  1, {FGVS_INATTRIBINDEX1,    0}},
    {r_in_attrib_idx2,  1, {FGVS_INATTRIBINDEX2,    0}},
    {r_out_attrib_idx0, 1, {FGVS_OUTATTRIBINDEX0,   0}},
    {r_out_attrib_idx1, 1, {FGVS_OUTATTRIBINDEX1,   0}},
    {r_out_attrib_idx2, 1, {FGVS_OUTATTRIBINDEX2,   0}}
};


const default_reg pe_default_regs[] =
{
    {r_vtx_context,           1, {FGPE_VERTEX_CONTEXT,          0}},
    {r_viewport_center_xcord, 1, {FGPE_VIEWPORT_OX,             0}},
    {r_viewport_center_ycord, 1, {FGPE_VIEWPORT_OY,             0}},
    {r_viewport_half_width,   1, {FGPE_VIEWPORT_HALF_PX,        0}},
    {r_viewport_half_height,  1, {FGPE_VIEWPORT_HALF_PY,        0}},
    {r_half_depth_range,      1, {FGPE_DEPTHRANGE_HALF_F_SUB_N, 0}},
    {r_average_near_far,      1, {FGPE_DEPTHRANGE_HALF_F_ADD_N, 0}}
};

const default_reg ra_default_regs[] =
{
    {r_pixel_sampos,        1, {FGRA_PIXSAMP,       0}},
    {r_depth_offset_en,     1, {FGRA_DOFFEN,        0}},
    {r_depth_offset_factor, 1, {FGRA_DOFFFACTOR,    0}},
    {r_depth_offset_unit,   1, {FGRA_DOFFUNITS,     0}},
    {r_depth_offset_rval,   1, {FGRA_DOFFRIN,       0}},
    {r_backface_cull,       1, {FGRA_BFCULL,        0}},
    {r_clip_ycord,          1, {FGRA_YCLIP,         0}},
    {r_lod_ctrl,            1, {FGRA_LODCTL,        0}},
    {r_clip_xcord,          1, {FGRA_XCLIP,         0}},
    {r_point_width,         1, {FGRA_PWIDTH,        0}},
    {r_point_size_min,      1, {FGRA_PSIZE_MIN,     0}},
    {r_point_size_max,      1, {FGRA_PSIZE_MAX,     0}},
    {r_coord_replace,       1, {FGRA_COORDREPLACE,  0}},
    {r_line_width,          1, {FGRA_LWIDTH,        0}}
};


const default_reg ps_default_regs[] =
{
    {r_exe_mode,        1, {FGPS_EXEMODE,   0}},
    {r_pc_start,        1, {FGPS_PCSTART,   0}},
    {r_pc_end,          1, {FGPS_PCEND,     0}},
    {r_pc_copy,         1, {FGPS_PCCOPY,    0}},
    {r_ps_attrib_num,   1, {FGPS_ATTRIBNUM, 0}},
    {r_inbuf_status,    0, {FGPS_IBSTATUS,  0}}
};

const default_reg tu_default_regs[] =
{
    {r_tex0_ctrl,           1, {FGTU_TSTA0,                   0}},
    {r_tex0_usize,          1, {FGTU_USIZE0,                  0}},
    {r_tex0_vsize,          1, {FGTU_VSIZE0,                  0}},
    {r_tex0_psize,          1, {FGTU_WSIZE0,                  0}},
    {r_tex0_l1_offset,      1, {FGTU_MIPMAP_OFFSET0,          0}},
    {r_tex0_l2_offset,      1, {(FGTU_MIPMAP_OFFSET0 + 0x4 ), 0}},
    {r_tex0_l3_offset,      1, {(FGTU_MIPMAP_OFFSET0 + 0x8 ), 0}},
    {r_tex0_l4_offset,      1, {(FGTU_MIPMAP_OFFSET0 + 0xC ), 0}},
    {r_tex0_l5_offset,      1, {(FGTU_MIPMAP_OFFSET0 + 0x10), 0}},
    {r_tex0_l6_offset,      1, {(FGTU_MIPMAP_OFFSET0 + 0x14), 0}},
    {r_tex0_l7_offset,      1, {(FGTU_MIPMAP_OFFSET0 + 0x18), 0}},
    {r_tex0_l8_offset,      1, {(FGTU_MIPMAP_OFFSET0 + 0x1C), 0}},
    {r_tex0_l9_offset,      1, {(FGTU_MIPMAP_OFFSET0 + 0x20), 0}},
    {r_tex0_l10_offset,     1, {(FGTU_MIPMAP_OFFSET0 + 0x24), 0}},
    {r_tex0_l11_offset,     1, {(FGTU_MIPMAP_OFFSET0 + 0x28), 0}},
    {r_tex0_min_level,      1, {FGTU_T_MIN_L0,                0}},
    {r_tex0_max_level,      1, {FGTU_T_MAX_L0,                0}},
    {r_tex0_base_addr,      1, {FGTU_TBADD0,                  0}},
    {r_tex1_ctrl,           1, {(FGTU_TSTA0  + 0x50),                  0}},    
    {r_tex1_usize,          1, {(FGTU_USIZE0 + 0x50),                  0}},    
    {r_tex1_vsize,          1, {(FGTU_VSIZE0 + 0x50),                  0}},    
    {r_tex1_psize,          1, {(FGTU_WSIZE0 + 0x50),                  0}},    
    {r_tex1_l1_offset,      1, {( FGTU_MIPMAP_OFFSET0 + 0x50),         0}},   
    {r_tex1_l2_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x4 ) + 0x50), 0}},   
    {r_tex1_l3_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x8 ) + 0x50), 0}},   
    {r_tex1_l4_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0xC ) + 0x50), 0}},   
    {r_tex1_l5_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x10) + 0x50), 0}},   
    {r_tex1_l6_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x14) + 0x50), 0}},   
    {r_tex1_l7_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x18) + 0x50), 0}},   
    {r_tex1_l8_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x1C) + 0x50), 0}},   
    {r_tex1_l9_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x20) + 0x50), 0}},   
    {r_tex1_l10_offset,     1, {((FGTU_MIPMAP_OFFSET0 + 0x24) + 0x50), 0}},   
    {r_tex1_l11_offset,     1, {((FGTU_MIPMAP_OFFSET0 + 0x28) + 0x50), 0}},   
    {r_tex1_min_level,      1, {(FGTU_T_MIN_L0 + 0x50),                0}},
    {r_tex1_max_level,      1, {(FGTU_T_MAX_L0 + 0x50),                0}},
    {r_tex1_base_addr,      1, {(FGTU_TBADD0   + 0x50),                0}},    
    {r_tex2_ctrl,           1, {(FGTU_TSTA0  + 0xA0),                  0}}, 
    {r_tex2_usize,          1, {(FGTU_USIZE0 + 0xA0),                  0}}, 
    {r_tex2_vsize,          1, {(FGTU_VSIZE0 + 0xA0),                  0}}, 
    {r_tex2_psize,          1, {(FGTU_WSIZE0 + 0xA0),                  0}}, 
    {r_tex2_l1_offset,      1, {( FGTU_MIPMAP_OFFSET0 + 0xA0),         0}},
    {r_tex2_l2_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x4 ) + 0xA0), 0}},
    {r_tex2_l3_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x8 ) + 0xA0), 0}},
    {r_tex2_l4_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0xC ) + 0xA0), 0}},
    {r_tex2_l5_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x10) + 0xA0), 0}},
    {r_tex2_l6_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x14) + 0xA0), 0}},
    {r_tex2_l7_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x18) + 0xA0), 0}},
    {r_tex2_l8_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x1C) + 0xA0), 0}},
    {r_tex2_l9_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x20) + 0xA0), 0}},
    {r_tex2_l10_offset,     1, {((FGTU_MIPMAP_OFFSET0 + 0x24) + 0xA0), 0}},
    {r_tex2_l11_offset,     1, {((FGTU_MIPMAP_OFFSET0 + 0x28) + 0xA0), 0}},
    {r_tex2_min_level,      1, {(FGTU_T_MIN_L0 + 0xA0),                0}}, 
    {r_tex2_max_level,      1, {(FGTU_T_MAX_L0 + 0xA0),                0}}, 
    {r_tex2_base_addr,      1, {(FGTU_TBADD0   + 0xA0),                0}}, 
    {r_tex3_ctrl,           1, {(FGTU_TSTA0  + 0xF0),                  0}}, 
    {r_tex3_usize,          1, {(FGTU_USIZE0 + 0xF0),                  0}}, 
    {r_tex3_vsize,          1, {(FGTU_VSIZE0 + 0xF0),                  0}}, 
    {r_tex3_psize,          1, {(FGTU_WSIZE0 + 0xF0),                  0}}, 
    {r_tex3_l1_offset,      1, {( FGTU_MIPMAP_OFFSET0 + 0xF0),         0}},
    {r_tex3_l2_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x4 ) + 0xF0), 0}},
    {r_tex3_l3_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x8 ) + 0xF0), 0}},
    {r_tex3_l4_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0xC ) + 0xF0), 0}},
    {r_tex3_l5_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x10) + 0xF0), 0}},
    {r_tex3_l6_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x14) + 0xF0), 0}},
    {r_tex3_l7_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x18) + 0xF0), 0}},
    {r_tex3_l8_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x1C) + 0xF0), 0}},
    {r_tex3_l9_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x20) + 0xF0), 0}},
    {r_tex3_l10_offset,     1, {((FGTU_MIPMAP_OFFSET0 + 0x24) + 0xF0), 0}},
    {r_tex3_l11_offset,     1, {((FGTU_MIPMAP_OFFSET0 + 0x28) + 0xF0), 0}},
    {r_tex3_min_level,      1, {(FGTU_T_MIN_L0 + 0xF0),                0}}, 
    {r_tex3_max_level,      1, {(FGTU_T_MAX_L0 + 0xF0),                0}}, 
    {r_tex3_base_addr,      1, {(FGTU_TBADD0   + 0xF0),                0}}, 
    {r_tex4_ctrl,           1, {(FGTU_TSTA0  + 0x140),                  0}}, 
    {r_tex4_usize,          1, {(FGTU_USIZE0 + 0x140),                  0}}, 
    {r_tex4_vsize,          1, {(FGTU_VSIZE0 + 0x140),                  0}}, 
    {r_tex4_psize,          1, {(FGTU_WSIZE0 + 0x140),                  0}}, 
    {r_tex4_l1_offset,      1, {( FGTU_MIPMAP_OFFSET0 + 0x140),         0}},
    {r_tex4_l2_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x4 ) + 0x140), 0}},
    {r_tex4_l3_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x8 ) + 0x140), 0}},
    {r_tex4_l4_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0xC ) + 0x140), 0}},
    {r_tex4_l5_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x10) + 0x140), 0}},
    {r_tex4_l6_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x14) + 0x140), 0}},
    {r_tex4_l7_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x18) + 0x140), 0}},
    {r_tex4_l8_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x1C) + 0x140), 0}},
    {r_tex4_l9_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x20) + 0x140), 0}},
    {r_tex4_l10_offset,     1, {((FGTU_MIPMAP_OFFSET0 + 0x24) + 0x140), 0}},
    {r_tex4_l11_offset,     1, {((FGTU_MIPMAP_OFFSET0 + 0x28) + 0x140), 0}},
    {r_tex4_min_level,      1, {(FGTU_T_MIN_L0 + 0x140),                0}}, 
    {r_tex4_max_level,      1, {(FGTU_T_MAX_L0 + 0x140),                0}}, 
    {r_tex4_base_addr,      1, {(FGTU_TBADD0   + 0x140),                0}}, 
    {r_tex5_ctrl,           1, {(FGTU_TSTA0  + 0x190),                  0}}, 
    {r_tex5_usize,          1, {(FGTU_USIZE0 + 0x190),                  0}}, 
    {r_tex5_vsize,          1, {(FGTU_VSIZE0 + 0x190),                  0}}, 
    {r_tex5_psize,          1, {(FGTU_WSIZE0 + 0x190),                  0}}, 
    {r_tex5_l1_offset,      1, {( FGTU_MIPMAP_OFFSET0 + 0x190),         0}},
    {r_tex5_l2_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x4 ) + 0x190), 0}},
    {r_tex5_l3_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x8 ) + 0x190), 0}},
    {r_tex5_l4_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0xC ) + 0x190), 0}},
    {r_tex5_l5_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x10) + 0x190), 0}},
    {r_tex5_l6_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x14) + 0x190), 0}},
    {r_tex5_l7_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x18) + 0x190), 0}},
    {r_tex5_l8_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x1C) + 0x190), 0}},
    {r_tex5_l9_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x20) + 0x190), 0}},
    {r_tex5_l10_offset,     1, {((FGTU_MIPMAP_OFFSET0 + 0x24) + 0x190), 0}},
    {r_tex5_l11_offset,     1, {((FGTU_MIPMAP_OFFSET0 + 0x28) + 0x190), 0}},
    {r_tex5_min_level,      1, {(FGTU_T_MIN_L0 + 0x190),                0}}, 
    {r_tex5_max_level,      1, {(FGTU_T_MAX_L0 + 0x190),                0}}, 
    {r_tex5_base_addr,      1, {(FGTU_TBADD0   + 0x190),                0}}, 
    {r_tex6_ctrl,           1, {(FGTU_TSTA0  + 0x1E0),                 0}}, 
    {r_tex6_usize,          1, {(FGTU_USIZE0 + 0x1E0),                 0}}, 
    {r_tex6_vsize,          1, {(FGTU_VSIZE0 + 0x1E0),                 0}}, 
    {r_tex6_psize,          1, {(FGTU_WSIZE0 + 0x1E0),                 0}}, 
    {r_tex6_l1_offset,      1, {( FGTU_MIPMAP_OFFSET0 + 0x1E0),         0}},
    {r_tex6_l2_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x4 ) + 0x1E0), 0}},
    {r_tex6_l3_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x8 ) + 0x1E0), 0}},
    {r_tex6_l4_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0xC ) + 0x1E0), 0}},
    {r_tex6_l5_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x10) + 0x1E0), 0}},
    {r_tex6_l6_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x14) + 0x1E0), 0}},
    {r_tex6_l7_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x18) + 0x1E0), 0}},
    {r_tex6_l8_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x1C) + 0x1E0), 0}},
    {r_tex6_l9_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x20) + 0x1E0), 0}},
    {r_tex6_l10_offset,     1, {((FGTU_MIPMAP_OFFSET0 + 0x24) + 0x1E0), 0}},
    {r_tex6_l11_offset,     1, {((FGTU_MIPMAP_OFFSET0 + 0x28) + 0x1E0), 0}},
    {r_tex6_min_level,      1, {(FGTU_T_MIN_L0 + 0x1E0),               0}}, 
    {r_tex6_max_level,      1, {(FGTU_T_MAX_L0 + 0x1E0),               0}}, 
    {r_tex6_base_addr,      1, {(FGTU_TBADD0   + 0x1E0),               0}}, 
    {r_tex7_ctrl,           1, {(FGTU_TSTA0  + 0x230),                 0}}, 
    {r_tex7_usize,          1, {(FGTU_USIZE0 + 0x230),                 0}}, 
    {r_tex7_vsize,          1, {(FGTU_VSIZE0 + 0x230),                 0}}, 
    {r_tex7_psize,          1, {(FGTU_WSIZE0 + 0x230),                 0}}, 
    {r_tex7_l1_offset,      1, {( FGTU_MIPMAP_OFFSET0 + 0x230),         0}},
    {r_tex7_l2_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x4 ) + 0x230), 0}},
    {r_tex7_l3_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x8 ) + 0x230), 0}},
    {r_tex7_l4_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0xC ) + 0x230), 0}},
    {r_tex7_l5_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x10) + 0x230), 0}},
    {r_tex7_l6_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x14) + 0x230), 0}},
    {r_tex7_l7_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x18) + 0x230), 0}},
    {r_tex7_l8_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x1C) + 0x230), 0}},
    {r_tex7_l9_offset,      1, {((FGTU_MIPMAP_OFFSET0 + 0x20) + 0x230), 0}},
    {r_tex7_l10_offset,     1, {((FGTU_MIPMAP_OFFSET0 + 0x24) + 0x230), 0}},
    {r_tex7_l11_offset,     1, {((FGTU_MIPMAP_OFFSET0 + 0x28) + 0x230), 0}},
    {r_tex7_min_level,      1, {(FGTU_T_MIN_L0 + 0x230),               0}}, 
    {r_tex7_max_level,      1, {(FGTU_T_MAX_L0 + 0x230),               0}}, 
    {r_tex7_base_addr,      1, {(FGTU_TBADD0   + 0x230),               0}}, 
    {r_color_key1,          1, {FGTU_CKEY1,     0}},
    {r_color_key2,          1, {FGTU_CKEY2,     0}},
    {r_color_key_yuv,       1, {FGTU_CKYUV,     0}},
    {r_color_key_mask,      1, {FGTU_CKMASK,    0}},
    {r_pallete_addr,        1, {FGTU_PALETTE_ADDR,     0}},
    {r_pallete_entry,       1, {FGTU_PALETTE_IN,       0}},
    {r_vtxtex0_ctrl,        1, {FGTU_VTSTA,            0}},
    {r_vtxtex0_base_addr,   1, {FGTU_VTBADDR,          0}},
    {r_vtxtex1_ctrl,        1, {(FGTU_VTSTA   + 0x8),  0}},
    {r_vtxtex1_base_addr,   1, {(FGTU_VTBADDR + 0x8),  0}},
    {r_vtxtex2_ctrl,        1, {(FGTU_VTSTA   + 0x10), 0}},
    {r_vtxtex2_base_addr,   1, {(FGTU_VTBADDR + 0x10), 0}},
    {r_vtxtex3_ctrl,        1, {(FGTU_VTSTA   + 0x18), 0}},
    {r_vtxtex3_base_addr,   1, {(FGTU_VTBADDR + 0x18), 0}}
};

const default_reg pf_default_regs[] =
 {
    {r_scissor_xcord,       1, {FGPF_SCISSOR_X, 0}},
    {r_scissor_ycord,       1, {FGPF_SCISSOR_Y, 0}},
    {r_alpha,               1, {FGPF_ALPHAT,    0}},
    {r_frontface_stencil,   1, {FGPF_FRONTST,   0}},
    {r_backface_stencil,    1, {FGPF_BACKST,    0}},
    {r_depth,               1, {FGPF_DEPTHT,    0}},
    {r_blend_color,         1, {FGPF_CCLR,      0}},
    {r_blend,               1, {FGPF_BLEND,     0}},
    {r_logic_op,            1, {FGPF_LOGOP,     0}},
    {r_color_mask,          1, {FGPF_CBMSK,     0}},
    {r_depth_mask,          1, {FGPF_DBMSK,     0}},
    {r_colorbuf_ctrl,       1, {FGPF_FBCTL,     0}},
    {r_depthbuf_addr,       1, {FGPF_DBADDR,    0}},
    {r_colorbuf_addr,       1, {FGPF_CBADDR,    0}},
    {r_colorbuf_width,      1, {FGPF_FBW,       0}}
};

/****************************************************************************
 *  FUNCTIONS
 ****************************************************************************/
void         fglSysTransferToPort   (unsigned int* p_source_data, volatile unsigned int* p_slaveport, unsigned int num_dwords);
void         fglSysTransferToPort   (unsigned int* p_source_data, unsigned int num_dwords);
unsigned int fglSysReservePortAlloc (unsigned int  request_slots, unsigned int preferred_min);

void         fglSwapBuffer          (unsigned int uSelect);

unsigned int fglWriteVertexShaderConstFloat   ( unsigned int offset, unsigned int size, float *pdata );
unsigned int fglWriteFragmentShaderConstFloat ( unsigned int offset, unsigned int size, float *pdata );

void fglDumpContext(const char *pFileName);


#endif  /* __SYS_UTILITY_H__ */

