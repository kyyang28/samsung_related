/*
* FPGA Test Vector for FIMG-3DSE ver 1.x Developed by Graphics Team
*
* Copyright 2007 by Mobie neXt Generation Technology, Samsung Electronics, Inc.,
* San#24, Nongseo-Dong, Giheung-Gu, Yongin, Korea. All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung.
*/
/**
* @file fimg3d_test.h
* @brief file defines the test vector and table which test for FIMG-3DSE ver 1.2.
*
* @author Thomas, Kim (cheolkyoo.kim@samsung.com)
* @version 1.2
*/

#ifndef _FIMG3D_TEST_H_
#define _FIMG3D_TEST_H_

typedef enum
{
	FIMGPT_RGB16_555,            
	FIMGPT_RGB16_565,            
	FIMGPT_ARGB16_4444,          
	FIMGPT_ARGB16_1555,          
	FIMGPT_XRGB32_0888,	         
	FIMGPT_ARGB32_8888          
} SurfacePixelFmt ;

typedef enum
{
    BMP_FILE = 1,
    PPM_FILE,
    NO_USE
} FBDumpFileFmt;

typedef enum
{
    SEMIHOST_PROJECT_RELATIVE = 1,
    SEMIHOST_ABSOLUTE_PATH,
    DIRECT_ACCESS_MMC
} TexFilePath;


struct Context3D
{
    bool    bShadeMode;
    bool    bIsAllTest;
    bool    bIsSpecificTest;
    bool    bIsUseXmlConfig;
    bool    bSwapBackBuffer;		
    	
    float	X;
    float	Y;	
    float	Width;
    float	Height;
    float	Near;
    float	Far;	
    int		FBOffsize;
    //float   ProjMat[16];
    unsigned int nNumOfData;
    unsigned int nNumOfVertices;
    unsigned int FrontFBAddr;
    unsigned int BackFBAddr;

    unsigned int uScreenPhyHSize;
    unsigned int uScreenPhyVSize;
    FBDumpFileFmt FBDumpFileFmt;
    TexFilePath  TexureFilePath;

    unsigned int uStartPointVector;

/*
    unsigned int uWindowWidthSize;
    unsigned int uWindowHeightSize;	
    unsigned int uWindowSurface;
    unsigned int uFrameSurface;
*/
};


/****************************************************************************
 *  ARM ASSEMBLER FUNCTION
 ****************************************************************************/
extern "C" void drvsys_clear_buf(
                    unsigned int     *buf, 
                    unsigned int     size, 
                    unsigned int     fill
                );


void TestEarth(void);


#endif /* _FIMG3D_TEST_H_ */
