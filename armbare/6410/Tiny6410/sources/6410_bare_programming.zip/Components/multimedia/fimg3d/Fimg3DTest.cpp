/*
* FPGA Test Vector for FIMG-3DSE ver 1.x Developed by Graphics Team
*
* Copyright 2007 by Mobie neXt Generation Technology, Samsung Electronics, Inc.,
* San#24, Nongseo-Dong, Giheung-Gu, Yongin, Korea. All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung.
*/
/**
* @file fimg3d_test.cpp
* @brief
*
* @author Thomas, Kim (cheolkyoo.kim@samsung.com)
* @version 1.2
*/

#include <stdio.h>
#include <string.h>

#include "system.h"
#include "library.h"
#include "fgl.h"
#include "Config.h"
#include "Fimg3DTest.h"


#include "timer.h"
#include "lcd.h"
#include "sdhc.h"
#include "fat.h"
#include "dma.h"
#include "intc.h"

static SDHC oSdhc;

char gFileName[256];
char gTexPathName[256];
char gObjPathName[256];
unsigned int g_nTestedVectorCount = 0;
unsigned int g_nTestFailCount     = 0;
unsigned int g_nTestSuccessCount  = 0;

struct Context3D  gFimgContext;

/****************************************************************************
 *  LOCAL FUNCTIONS
 ****************************************************************************/
#ifdef __cplusplus
extern "C"{
#endif

void FIMG3D_Test(void);

#ifdef __cplusplus
}
#endif


extern struct viewport_info g_stViewPortInfo = { 0.0, 0.0, 800.0, 480.0, 480.0, true };
extern struct fbctrl_info   g_stFbctrlInfo   = { 0, 0, FBF_ARGB8888, false, false };
  

int LoadTextureImage(const char *filename);
int LoadGeometryData(const char *filename);


void FIMG3D_Test(void)
{
	u32 uDoubleBufAddr;
	
	CSPACE eBpp = RGB24;

	LCD_SetPort();
	LCD_InitLDI(MAIN);
	LCD_InitDISPC(eBpp, FIMG_COLOR_BUFFER, WIN0, true);
	LCD_GetDoubleBufAddr(&uDoubleBufAddr, 0, WIN0);
	LCD_GetDoubleBufAddr(&uDoubleBufAddr, 1, WIN0);
	LCD_SetActiveFrameBuf(0, WIN0);
	LCD_EnableAutoBuf(1, WIN0); // 0: Normal Double Buffering 1: Auto Double Buffering
	LCD_SetWinOnOff(1, WIN0);
	LCD_Start();
    strcpy(gTexPathName, "../Components/multimedia/fimg3d/textures/");
    strcpy(gObjPathName, "../Components/multimedia/fimg3d/models/");

	fgl_soft_reset();
	
	// initialize FIMG3D-SE
    fgl_viewport        ( &g_stViewPortInfo );
    fgl_depth_range     ( 0.0, 1.0 );
    fgl_clip_plan       ( 0, 800, 0, 480 );
    fgl_colorbuf        ( &g_stFbctrlInfo );    	
    fgl_colorbuf_base   ( FIMG_COLOR_BUFFER );
    fgl_framebuf_stride ( 800 );
	
	gFimgContext.bShadeMode      = true;
 	gFimgContext.bIsAllTest      = false;
	gFimgContext.bIsUseXmlConfig = false;
 	gFimgContext.uScreenPhyHSize = 800;
	gFimgContext.uScreenPhyVSize = 480;
	gFimgContext.FBDumpFileFmt   = BMP_FILE;
	gFimgContext.TexureFilePath  = DIRECT_ACCESS_MMC;

	gFimgContext.uStartPointVector = 0;
	gFimgContext.bIsSpecificTest = false;

    
	UART_Printf("\nThis is Test Routine for FIMG-3DSE v1.5\n");
	
    LoadTextureImage("Earth.tex");
    LoadGeometryData("Earth.dat");
	
	TestEarth();
	
	UART_Printf("\nTestEarth is done!\n");

	LCD_SetWinOnOff(0, WIN0);
}


int LoadTextureImage(const char *filename)
{
    u32 uSizeRead = 0;

	UART_Printf("\nTexture image load at 0x%08X. wait...", FIMG_TEXTURE_MEMORY);

    if(gFimgContext.TexureFilePath == SEMIHOST_PROJECT_RELATIVE)
    {
    	strcpy(gFileName, gTexPathName);
    	strcat(gFileName, filename);
    	LoadFromFile(gFileName, FIMG_TEXTURE_MEMORY);
    	UART_Printf("\n%s texture file loading done.", gFileName);
    }
    else if(gFimgContext.TexureFilePath == DIRECT_ACCESS_MMC)
    {
	    if (!SDHC_OpenMediaWithMode(4, SDHC_POLLING_MODE, SDHC_HCLK, 4, SDHC_CHANNEL_1, &oSdhc)) {
	    	UART_Printf("\nError: OpenMedia() failed.");
	    }

	    if (!FAT_LoadFileSystem(&oSdhc)) {
	    	UART_Printf("\nError: LoadFileSystem() failed.");
	    }

		FAT_ReadFile3(filename, FIMG_TEXTURE_MEMORY, &uSizeRead, &oSdhc);
		
    	if(uSizeRead == 0) {
    		UART_Printf("\nError: Texture image file load fail");
    	}

		FAT_UnloadFileSystem(&oSdhc);
		SDHC_CloseMedia(&oSdhc);

    	UART_Printf("\n%s texture file loading done.", filename);
    }
    else if(gFimgContext.TexureFilePath == SEMIHOST_ABSOLUTE_PATH) {
    	strcpy(gFileName, gTexPathName);
    	strcat(gFileName, filename);
    	LoadFromFile(gFileName, FIMG_TEXTURE_MEMORY);
        UART_Printf("\n%s texture file loading done.", gFileName);
    }
    else {
        UART_Printf("\n%sError: The location of texture images is not correct.");
        return (-1);
    }

    return 0;
}

int LoadGeometryData(const char *filename)
{
    u32 uSizeRead = 0;
    unsigned int uCopyDestAddr = FIMG_GEOMETRY_MEMORY;

	UART_Printf("\nGeometry data load at 0x%08X. wait...", FIMG_GEOMETRY_MEMORY);

    if(gFimgContext.TexureFilePath == SEMIHOST_PROJECT_RELATIVE)
    {
    	strcpy(gFileName, gObjPathName);
    	strcat(gFileName, filename);
    	LoadFromFile(gFileName, FIMG_GEOMETRY_MEMORY);
    	UART_Printf("\n%s geometry data loading done.", gFileName);
    }
    else if(gFimgContext.TexureFilePath == DIRECT_ACCESS_MMC)
    {
	    if (!SDHC_OpenMediaWithMode(4, SDHC_POLLING_MODE, SDHC_HCLK, 4, SDHC_CHANNEL_1, &oSdhc)) {
	    	UART_Printf("\nError: OpenMedia() failed.");
	    }

	    if (!FAT_LoadFileSystem(&oSdhc)) {
	    	UART_Printf("\nError: LoadFileSystem() failed.");
	    }
		FAT_ReadFile3(filename, uCopyDestAddr, &uSizeRead, &oSdhc);

	    if(uSizeRead == 0) {
	    	UART_Printf("\nError: golden image file load fail");
        }

    	FAT_UnloadFileSystem(&oSdhc);
    	SDHC_CloseMedia(&oSdhc);
    	
    	UART_Printf("\n%s geometry data loading done.", filename);
    }
    else if(gFimgContext.TexureFilePath == SEMIHOST_ABSOLUTE_PATH) {
    	strcpy(gFileName, gObjPathName);
    	strcat(gFileName, filename);
    	LoadFromFile(gFileName, FIMG_GEOMETRY_MEMORY);
        UART_Printf("\n%s geometry data file loading done.", gFileName);
    }
    else {
        UART_Printf("\n%sError: The location of geometry data is not correct.");
        return (-1);
    }

    return 0;
}

