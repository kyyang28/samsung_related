/**
 * Samsung Project
 * Copyright (c) 2008 Mobile XG, Samsung Electronics, Inc.
 * All right reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file	fgl.h
 * @brief	This is the header file for fgl library.
 * @author	Cheolkyoo Kim
 * @version	1.5
 */

#if !defined(__FIMG_H__)
#define __FIMG_H__

#include "fglconfig.h"
#include <assert.h>
#include <stdbool.h>

#if defined __cplusplus
extern "C" {
#endif

/****************************************************************************
 *  FIMG-3DSE REGISTER
 ****************************************************************************/
/* GLOBAL REGISTER */                                      /* rw   reset(initial) */
#define FGGB_PIPESTATE                 (FIMG_BASE+0x0)     /* R    0x0        */
#define rFGGB_PIPESTATE               *(volatile uint32 *)(FIMG_BASE+0x0)
#define FGGB_CACHECTL                  (FIMG_BASE+0x4)     /* RW   0x0        */
#define FGGB_RESET                     (FIMG_BASE+0x8)     /* W    0x0        */
#define FGGB_VERSION                   (FIMG_BASE+0x10)    /* R    0x02000000 */
#define FGGB_INTPENDING                (FIMG_BASE+0x40)    /* RW   0x0        */
#define FGGB_INTMASK                   (FIMG_BASE+0x44)    /* RW   0x0        */
#define FGGB_PIPEMASK                  (FIMG_BASE+0x48)    /* RW   0x0        */
#define FGGB_PIPETGTSTATE              (FIMG_BASE+0x4C)    /* RW   0x0        */
#define FGGB_PIPEINTSTATE              (FIMG_BASE+0x50)    /* R    0x0        */
#define rFGGB_PIPEINTSTATE            *(volatile uint32 *)(FIMG_BASE+0x50)
/* PROBE WATCH POINTS FOR FIMG-3DSE V2.0 */
#define FGWP_DEBUG_ENABLE              (FIMG_BASE+0x200)   /* R    na         */
#define FGWP_IN_HI_GRP0                (FIMG_BASE+0x204)   /* R    na         */
#define FGWP_IN_HI_GRP1                (FIMG_BASE+0x208)   /* R    na         */
#define FGWP_IN_VC_VS                  (FIMG_BASE+0x20C)   /* R    na         */
#define FGWP_IN_PE                     (FIMG_BASE+0x210)   /* R    na         */
#define FGWP_IN_TSE_RA                 (FIMG_BASE+0x214)   /* R    na         */
#define FGWP_IN_PS0                    (FIMG_BASE+0x218)   /* R    na         */
#define FGWP_IN_PS1                    (FIMG_BASE+0x21C)   /* R    na         */
#define FGWP_IN_VTU_TU                 (FIMG_BASE+0x220)   /* R    na         */
#define FGWP_IN_TCACHE                 (FIMG_BASE+0x224)   /* R    na         */
#define FGWP_IN_PF                     (FIMG_BASE+0x228)   /* R    na         */
#define FGWP_IN_CZCACHE                (FIMG_BASE+0x22C)   /* R    na         */
#define FGWP_IN_AXIRB                  (FIMG_BASE+0x230)   /* R    na         */
#define FGWP_IN_DMA                    (FIMG_BASE+0x234)   /* R    na         */
/* HOST INTERFACE REGISTER */
#define FGHI_DWSPACE                   (FIMG_BASE+0x8000)  /* R    0x0        */
#define rFGHI_DWSPACE                  *(volatile uint32 *)(FIMG_BASE+0x8000)
#define FGHI_DWENTRY                   (FIMG_BASE+0xC000)  /* W    na         */
#define FGHI_DWENTRY_SIZE              0x2000
#define FGHI_CONTROL                   (FIMG_BASE+0x8008)  /* RW   0x0        */
#define FGHI_IDXOFFSET                 (FIMG_BASE+0x800C)  /* RW   0x1        */
#define FGHI_VBADDR                    (FIMG_BASE+0x8010)  /* RW   0x0        */
#define FGHI_VBDATA                    (FIMG_BASE+0xE000)  /* RW   0x0        */
#define FGHI_VBDATA_BURST_BSIZE         0x2000             /* 8Kbyte          */
#define FGHI_VBDATA_BURST_WSIZE         0x800              /* 2K words        */
#define FGHI_ATTRIB                    (FIMG_BASE+0x8040)  /* RW   0x800000E4 */
#define FGHI_ATTRIB_VBCTRL             (FIMG_BASE+0x8080)  /* RW   0x0        */
#define FGHI_ATTRIB_VBBASE             (FIMG_BASE+0x80C0)  /* RW   0x0        */
/*VERTEX SHADER REGISTER */
#define FGVS_INSTMEM                   (FIMG_BASE+0x10000) /* RW   na         */
#define FGVS_CFLOAT                    (FIMG_BASE+0x14000) /* RW   na         */
#define FGVS_CINT                      (FIMG_BASE+0x18000) /* RW   na         */
#define FGVS_CBOOL                     (FIMG_BASE+0x18400) /* RW   na         */
#define FGVS_CONFIG                    (FIMG_BASE+0x1C800) /* W    0x0        */
#define FGVS_STATUS                    (FIMG_BASE+0x1C804) /* R    0x0        */
#define rFGVS_STATUS                   *(volatile uint32 *)(FIMG_BASE+0x1C804)
#define FGVS_PCRANGE                   (FIMG_BASE+0x20000) /* RW   0x1FF000   */
#define FGVS_ATTRIBNUM                 (FIMG_BASE+0x20004) /* RW   0x10001    */
#define FGVS_INATTRIBINDEX0            (FIMG_BASE+0x20008) /* W    0x3020100  */
#define FGVS_INATTRIBINDEX1            (FIMG_BASE+0x2000C) /* W    0x7060504  */
#define FGVS_INATTRIBINDEX2            (FIMG_BASE+0x20010) /* W    0xB0A0908  */
#define FGVS_OUTATTRIBINDEX0           (FIMG_BASE+0x20014) /* W    0x3020100  */
#define FGVS_OUTATTRIBINDEX1           (FIMG_BASE+0x20018) /* W    0x7060504  */
#define FGVS_OUTATTRIBINDEX2           (FIMG_BASE+0x2001C) /* W    0xB0A0908  */
/* PRIMITIVE ENGINE REGISTER */
#define FGPE_VERTEX_CONTEXT            (FIMG_BASE+0x30000) /* RW   0x0        */
#define FGPE_VIEWPORT_OX               (FIMG_BASE+0x30004) /* RW   0x0        */
#define FGPE_VIEWPORT_OY               (FIMG_BASE+0x30008) /* RW   0x0        */
#define FGPE_VIEWPORT_HALF_PX          (FIMG_BASE+0x3000C) /* RW   0x0        */
#define FGPE_VIEWPORT_HALF_PY          (FIMG_BASE+0x30010) /* RW   0x0        */
#define FGPE_DEPTHRANGE_HALF_F_SUB_N   (FIMG_BASE+0x30014) /* RW   0x3F000000 */
#define FGPE_DEPTHRANGE_HALF_F_ADD_N   (FIMG_BASE+0x30018) /* RW   0x3F000000 */
/* RASTER REGISTER */
#define FGRA_PIXSAMP                   (FIMG_BASE+0x38000) /* RW   0x0        */
#define FGRA_DOFFEN                    (FIMG_BASE+0x38004) /* RW   0x0        */
#define FGRA_DOFFFACTOR                (FIMG_BASE+0x38008) /* RW   0x0        */
#define FGRA_DOFFUNITS                 (FIMG_BASE+0x3800C) /* RW   0x0        */
#define FGRA_DOFFRIN                   (FIMG_BASE+0x38010) /* RW   0x34000001 */
#define FGRA_BFCULL                    (FIMG_BASE+0x38014) /* RW   0x0        */
#define FGRA_YCLIP                     (FIMG_BASE+0x38018) /* RW   0x0        */
#define FGRA_LODCTL                    (FIMG_BASE+0x3C000) /* RW   0x0        */
#define FGRA_XCLIP                     (FIMG_BASE+0x3C004) /* RW   0x0        */
#define FGRA_PWIDTH                    (FIMG_BASE+0x3801C) /* RW   0x3F800000 */
#define FGRA_PSIZE_MIN                 (FIMG_BASE+0x38020) /* RW   0x3F800000 */
#define FGRA_PSIZE_MAX                 (FIMG_BASE+0x38024) /* RW   0x45000000 */
#define FGRA_COORDREPLACE              (FIMG_BASE+0x38028) /* RW   0x0        */
#define FGRA_LWIDTH                    (FIMG_BASE+0x3802C) /* RW   0x3F800000 */
/* FRAGMENT SHADER REGISTER */
#define FGPS_INSTMEM                   (FIMG_BASE+0x40000) /* W    na         */
#define FGPS_CFLOAT                    (FIMG_BASE+0x44000) /* W    na         */
#define FGPS_CINT                      (FIMG_BASE+0x48000) /* W    na         */
#define FGPS_CBOOL                     (FIMG_BASE+0x48400) /* W    na         */
#define FGPS_EXEMODE                   (FIMG_BASE+0x4C800) /* RW   0x0        */
#define FGPS_PCSTART                   (FIMG_BASE+0x4C804) /* RW   0x0        */
#define FGPS_PCEND                     (FIMG_BASE+0x4C808) /* RW   0x1FF      */
#define FGPS_PCCOPY                    (FIMG_BASE+0x4C80C) /* RW   0x0        */
#define FGPS_ATTRIBNUM                 (FIMG_BASE+0x4C810) /* RW   0x8        */
#define FGPS_IBSTATUS                  (FIMG_BASE+0x4C814) /* R    0x0        */
#define rFGPS_IBSTATUS                 *(volatile uint32 *)(FIMG_BASE+0x4C814)
/* TEXTURE UNITS REGISTER */
#define FGTU_TSTA0                     (FIMG_BASE+0x60000) /* RW   0x8000000  */
#define FGTU_USIZE0                    (FIMG_BASE+0x60004) /* RW   0x0        */
#define FGTU_VSIZE0                    (FIMG_BASE+0x60008) /* RW   0x0        */
#define FGTU_WSIZE0                    (FIMG_BASE+0x6000C) /* RW   0x0        */
#define FGTU_MIPMAP_OFFSET0            (FIMG_BASE+0x60010) /* RW   0x0        */
#define FGTU_T_MIN_L0                  (FIMG_BASE+0x6003C) /* RW   0x0        */
#define FGTU_T_MAX_L0                  (FIMG_BASE+0x60040) /* RW   0x0        */
#define FGTU_TBADD0                    (FIMG_BASE+0x60044) /* RW   0x0        */
#define FGTU_CKEY1                     (FIMG_BASE+0x60280) /* RW   0x0        */
#define FGTU_CKEY2                     (FIMG_BASE+0x60284) /* RW   0x0        */
#define FGTU_CKYUV                     (FIMG_BASE+0x60288) /* RW   0x0        */
#define FGTU_CKMASK                    (FIMG_BASE+0x6028C) /* RW   0x0        */
#define FGTU_PALETTE_ADDR              (FIMG_BASE+0x60290) /* W    0x0        */
#define FGTU_PALETTE_IN                (FIMG_BASE+0x60294) /* W    0x0        */
#define FGTU_VTSTA                     (FIMG_BASE+0x602C0) /* RW   0x0        */
#define FGTU_VTBADDR                   (FIMG_BASE+0x602C4) /* RW   0x0        */
/* PER-FRAGMENT REGISTER */
#define FGPF_SCISSOR_X                 (FIMG_BASE+0x70000) /* RW   0x0        */
#define FGPF_SCISSOR_Y                 (FIMG_BASE+0x70004) /* RW   0x0        */
#define FGPF_ALPHAT                    (FIMG_BASE+0x70008) /* RW   0x0        */
#define FGPF_FRONTST                   (FIMG_BASE+0x7000C) /* RW   0x0        */
#define FGPF_BACKST                    (FIMG_BASE+0x70010) /* RW   0x0        */
#define FGPF_DEPTHT                    (FIMG_BASE+0x70014) /* RW   0x0        */
#define FGPF_CCLR                      (FIMG_BASE+0x70018) /* RW   0x0        */
#define FGPF_BLEND                     (FIMG_BASE+0x7001C) /* RW   0x0        */
#define FGPF_LOGOP                     (FIMG_BASE+0x70020) /* RW   0x0        */
#define FGPF_CBMSK                     (FIMG_BASE+0x70024) /* RW   0x0        */
#define FGPF_DBMSK                     (FIMG_BASE+0x70028) /* RW   0x0        */
#define FGPF_FBCTL                     (FIMG_BASE+0x7002C) /* RW   0x0        */
#define FGPF_DBADDR                    (FIMG_BASE+0x70030) /* RW   0x0        */
#define FGPF_CBADDR                    (FIMG_BASE+0x70034) /* RW   0x0        */
#define FGPF_FBW                       (FIMG_BASE+0x70038) /* RW   0x0        */


/***********************************************************************
	@USAGE
	WRITE
		if you want to write SFR by 32-bits, then
			outw(SFR_ADDRESS, (uint32)WDATA);
		if by 16-bits, then
			outs(SFR_ADDRESS, (unsigned short int)WDATA);
		if by 8-bits, then
			outb(SFR_ADDRESS, (unsigned char)WDATA);
	READ
		if you read SFR by 32-bits, then
			(uint32)RDATA = inw(SFR_ADDRESS);
		if by 16-bits, then
			(unsigned short int)RDATA = ins(SFR_ADDRESS);
		if by 8-bits, then
			(unsigned char)RDATA = inb(SFR_ADDRESS);
*************************************************************************/

typedef volatile unsigned char 	*vbptr;
typedef volatile unsigned short *vsptr;
typedef volatile unsigned int 	*vwptr;
typedef volatile float			*vfptr;

#define READREGB(Port)		(*((vbptr) (Port)))
#define READREGPB(Port, Y)	(Y =*((vbptr) (Port)))
#define WRITEREGB(Port, X)	(*((vbptr) (Port)) = (unsigned char) (X))

#define READREGS(Port)		(*((vsptr) (Port)))
#define READREGPS(Port, Y)	(Y =*((vsptr) (Port)))
#define WRITEREGS(Port, X)	(*((vsptr) (Port)) = (unsigned short) (X))

#define READREG(Port)		(*((vwptr) (Port)))
#define READREGP(Port, Y)	(Y =*((vwptr) (Port)))
#define WRITEREG(Port, X)	(*((vwptr) (Port)) = (unsigned int) (X))

#define READREGF(Port)		(*((vfptr) (Port)))
#define READREGPF(Port, Y)	(Y =*((vfptr) (Port)))
#define WRITEREGF(Port, X)	(*((vfptr) (Port)) = (float) (X))


// ----------------------------------------------------------------------
// Control Block Data Structure
// ----------------------------------------------------------------------

/* Pipeline status flag */
enum { PSF_HI = 0xF, PSF_VS = 0x1F, PSF_PE = 0x11F, PSF_RA = 0x71F, PSF_FS = 0x171F, PSF_ALL = 0x1171F };
/* Cache flag */
enum { CF_ZC = 0x3, CF_CC = 0x30, CF_TC = 0x300, CF_VC = 0x1000, CF_ALL = 0x1333 };

union pipeline_status {
    struct {
        unsigned int HF:1;
        unsigned int HI:1;
        unsigned int HVF:1;
        unsigned int VC:1;
        unsigned int VS:1;
        unsigned int reserve0:3;
        unsigned int PE:1;
        unsigned int TSE:1;
        unsigned int RA:1;
        unsigned int reserve1:1;
        unsigned int PS:1;
        unsigned int reserve2:3;
        unsigned int PF:1;
        unsigned int reserve3:15;
    } bit;
    unsigned int word;
};

// ----------------------------------------------------------------------
// Host Interface Data Structure
// ----------------------------------------------------------------------

enum { IDT_UINT = 0, IDT_USHORT = 1, IDT_UBYTE = 3 };

enum { 
	ADT_BYTE,
	ADT_SHORT,
	ADT_INT,
	ADT_FIXED,
	ADT_UBYTE,
	ADT_USHORT,
	ADT_UINT,
	ADT_FLOAT,
	ADT_NBYTE,
	ADT_NSHORT,
	ADT_NINT,
	ADT_NFIXED,
	ADT_NUBYTE,
	ADT_NUSHORT,
	ADT_NUINT
};

enum { FIRST = 0, SECOND = 1, THIRD = 2, FOURTH = 3 };

struct host_interface_info {
	fglenum 	idx_type;
	uint32      vertex_shader_out;
	bool        vtxbuf;
	bool        autoinc;
	bool        vtxcache;
};

struct attribute_info {
	fglenum     x;
	fglenum     y;
	fglenum     z;
	fglenum     w;
	uint32      component;
	fglenum	    dtype;
	bool 	    islast;
};

// ----------------------------------------------------------------------
// Primitive Engine Data Structure
// ----------------------------------------------------------------------
enum {
	TRIANGLES       = 0x80,
	TRIANGLE_FAN    = 0x40,
	TRIANGLE_STRIP  = 0x20,
	LINES           = 0x10,
	LINE_LOOP       = 0x8,
	LINE_STRIP      = 0x4,
	POINTS          = 0x2,
	POINT_SPRITE    = 0x1
};

struct vertex_context {
	fglenum     type;
	// Excluding position, the number of output of vertex shader.
	uint32      vertex_shader_out;		
	// i-th lsb is set if i-th varying needs flat interpolation
	uint32      flat_color_pos;
	bool 		point_size;		
};

struct viewport_info {
    int32       x; 
    int32       y; 
    uint32      width; 
    uint32      height; 
    uint32      win_height;    
    bool        flip;
};

// ----------------------------------------------------------------------
// Raster Engine Data Structure
// ----------------------------------------------------------------------

union lodctrl {
    struct {
        unsigned int ATTRIB0:3;
        unsigned int ATTRIB1:3;
        unsigned int ATTRIB2:3;
        unsigned int ATTRIB3:3;
        unsigned int ATTRIB4:3;
        unsigned int ATTRIB5:3;
        unsigned int ATTRIB6:3;
        unsigned int ATTRIB7:3;
        unsigned int reserve:8;
    } bit;
    unsigned int word;
};

enum { CENTER, LEFTTOP };
enum { BACKFACE, FRONTFACE, FRONTBACK = 3 };
enum { LOD = 1, DDX = 2, DDY = 4 };

// ----------------------------------------------------------------------
// Texture Units Data Structure
// ----------------------------------------------------------------------

// Need a test for struct padding
#if 1

struct texture_info {
	fglenum		textype;
	fglenum	    ckey;
	bool		use_expansion;
	bool        rgba_order;
	fglenum     palfmt;
	fglenum 	texmfmt;
	fglenum	    umode;
	fglenum	    vmode;
	fglenum	    wmode;
	bool		non_parametric;
	bool		use_magfilter;
	bool		use_minfilter;
	fglenum     mipmap_filter;
	
	uint32      usize;
	uint32      vsize;
	uint32      psize;
	uint32      address;
};

#else

struct texture_info {
	fglenum		textype;
	fglenum	    ckey;
	fglenum     palfmt;
	fglenum 	texmfmt;
	fglenum	    umode;
	fglenum	    vmode;
	fglenum	    wmode;
	fglenum     mipmap_filter;
	
	uint32      usize;
	uint32      vsize;
	uint32      psize;
	uint32      address;
	
	bool		use_expansion;
	bool        rgba_order;
	bool		non_parametric;
	bool		use_magfilter;
	bool		use_minfilter;
};

#endif

struct vtxtex_info {	
	fglenum     umode;
	fglenum     vmode;
	uint32   	usize;
	uint32  	vsize;
	uint32      base;
};

/* Texture type */
enum { TEX_2D = 1, TEX_CUBE, TEX_3D };
/* Texel format */
enum {
	TFMT_ARGB1555,
	TFMT_RGB565,
	TFMT_ARGB4444,
	TFMT_DEPTH24,
	TFMT_IA88,
	TFMT_I8,
	TFMT_ARGB8888,
	TFMT_1BPP,
	TFMT_2BPP,
	TFMT_4BPP,
	TFMT_8BPP,
	TFMT_S3TC,
	TFMT_Y1VY0U,
	TFMT_VY1UY0,
	TFMT_Y1UY0V,
	TFMT_UY1VY0
};
/* Palette format */
enum { PAL_ARGB1555, PAL_RGB565, PAL_ARGB4444, PAL_ARGB8888 };
/* Texture wrap mode */
enum { TWM_REPEAT, TWM_FLIP, TWM_CLAMP };
enum { CKEY0 = 0, CKEY1 = 1, CKEY2 = 3 };
/* Texture filter */
enum { TFLR_NONE, TF_NEAREST, TF_LINEAR };


// ----------------------------------------------------------------------
// Per-fragment Unit Data Structure
// ----------------------------------------------------------------------

struct stencil_info {
	fglenum         face;
	fglenum 		zpass;
	fglenum 		zfail;
	fglenum 		sfail;
	uint32 		    mask; 
	uint32 		    ref;
	fglenum 	    func;
};

struct blend_info {
	uint32 	       color;
	fglenum 	   cequa;
	fglenum 	   aequa;
	fglenum 	   dalpha; 
	fglenum 	   dcolor;
	fglenum 	   salpha; 
	fglenum 	   scolor;
};

struct fbctrl_info {
	uint32         threshold;
	uint32         alpha; 
	fglenum        format;
	bool           opaque; 
	bool	       dither;
};

/* Comparison function */
enum { CF_NEVER, CF_ALWAYS, CF_LESS, CF_LEQUAL, CF_EQUAL, CF_GREATER, CF_GEQUAL, CF_NOTEQUAL };
/* Stencil operation function */
enum { SOP_KEEP, SOP_ZERO, SOP_REPLACE, SOP_INCR, SOP_DECR, SOP_INVERT, SOP_INCRWRAP, SOP_DECRWRAP };
/* Blend equation function */
enum { BEQ_ADD, BEQ_SUBTRACT, BEQ_REV_SUBTRACT, BEQ_MIN, BEQ_MAX };
/* Color buffer pixel format*/
enum { FBF_RGB555, FBF_RGB565, FBF_ARGB4444, FBF_ARGB1555, FBF_ARGB0888, FBF_ARGB8888 };
/* Blend function */
enum {                               /*     source      destination  */
    	BF_ZERO,                     /*     ok          ok(default) */
    	BF_ONE,                      /*     ok(default) ok */
    	BF_SRC_COLOR,                /*     ok          ok */
    	BF_ONE_MINUS_SRC_COLOR,      /*     ok          ok */
    	BF_DST_COLOR,                /*     ok          ok */
    	BF_ONE_MINUS_DST_COLOR,      /*     ok          ok */
    	BF_SRC_ALPHA,                /*     ok          ok */
    	BF_ONE_MINUS_SRC_ALPHA,      /*     ok          ok */
    	BF_DST_ALPHA,                /*     ok          ok */
    	BF_ONE_MINUS_DST_ALPHA,      /*     ok          ok */
    	BF_CONSTANT_COLOR,           /*     ok          ok */
    	BF_ONE_MINUS_CONSTANT_COLOR, /*     ok          ok */
    	BF_CONSTANT_ALPHA,           /*     ok          ok */
    	BF_ONE_MINUS_CONSTANT_ALPHA, /*     ok          ok */
    	BF_SRC_ALPHA_SATURATE        /*     ok          n/a */
};
/* Logic op function */
enum { LOP_CLEAR, LOP_AND,  LOP_AND_REVERSE, LOP_COPY,  LOP_AND_INVERTED, LOP_NOOP,
	   LOP_XOR,   LOP_OR,   LOP_NOR,         LOP_EQUIV, LOP_INVERT,       LOP_OR_REVERSE,
	   LOP_COPY_INVERTED,   LOP_OR_INVERTED, LOP_NAND,  LOP_SET };


// ----------------------------------------------------------------------
// Shader Data Structure
// ----------------------------------------------------------------------

enum { ACCSSIBLE, EXECUTE };

struct shader_hdr
{
	uint32	    magic;
	uint32	    version;
	uint32	    header;
	uint32      in_tbl;
	uint32	    out_tbl;
	uint32	    sampler;
	uint32	    instruct;
	uint32	    const_float;
	uint32	    const_int;
	uint32	    const_bool;
	uint32	    reserved[6]; 
};

struct shader_bin_hdr
{
    uint32      magic;
    uint32      compiler;
    uint32      header;
    uint32      hwver;
	uint32	    instruct;
	uint32	    const_float;
	uint32	    const_int;
	uint32	    const_bool;
    uint32      dcl_btype_tbl[4];
    uint32      dcl_array_tbl[4];
    uint32      dcl_string_tbl;
    uint32      body;
};

// ----------------------------------------------------------------------
// Control Register-level API
// ----------------------------------------------------------------------
FGLAPI fgl_pipeline_status  ( uint32 * flag );
FGLAPI fgl_pipeline_isempty ( const uint32 flag );
FGLAPI fgl_flush_cache      ( const uint32 flag );
FGLAPI fgl_soft_reset       ( void );
FGLAPI fgl_version          ( uint32 * major, uint32 * minor );
FGLAPI fgl_clear_pending_int ( void );
FGLAPI fgl_get_pending_int   ( uint32 * state );
FGLAPI fgl_enable_int        ( void );
FGLAPI fgl_disable_int       ( void );
FGLAPI fgl_interrupt_mask    ( const uint32 flag ); 
FGLAPI fgl_interrupt_target  ( const uint32 flag ); 
FGLAPI fgl_interrupt_status  ( uint32 * status ); 


// ----------------------------------------------------------------------
// Host Interface Register-level API
// ----------------------------------------------------------------------
FGLAPI fgl_get_empty_slots  ( uint32 * slots );
FGLAPI fgl_transfer_fifo    ( void * src, uint32 size );
FGLAPI fgl_host_interface   ( void * hostinfo );
FGLAPI fgl_index_offset     ( const uint32 offset );
FGLAPI fgl_attribute        ( const uint32 count, void * attrib );
FGLAPI fgl_transfer_vtxbuf  ( void * vbdata, uint32 words );
FGLAPI fgl_vtxbuf_attribute ( const uint32 index, const uint32 stride, const uint32 count, const uint32 base );


// ----------------------------------------------------------------------
// Vertex Shader Register-level API
// ----------------------------------------------------------------------
FGLAPI fgl_vs_pc         ( const uint32 start, const uint32 end, const bool endignore );
FGLAPI fgl_vs_inattrib   ( const uint32 size );
int32  fgl_load_vs       ( const uint32 *program );
//uint32 fgl_write_cfmem   ( uint32 offset, uint32 size, float *data );

// ----------------------------------------------------------------------
// Fragment Shader Register-level API
// ----------------------------------------------------------------------
int32  fgl_execute_mode ( fglenum mode );
FGLAPI fgl_fs_pc        ( const uint32 start, const uint32 end, bool endignore );
FGLAPI fgl_fs_inattrib  ( const uint32 size );
int32  fgl_load_fs      ( const uint32 * program );

// ----------------------------------------------------------------------
// Orion Shader Compiler Register-level API
// ----------------------------------------------------------------------
int32  fgl_load_binary  ( void * binary );

            					   
// ----------------------------------------------------------------------
// Primitive Engine Register-level API
// ----------------------------------------------------------------------
FGLAPI fgl_vertex      ( void * context );
FGLAPI fgl_viewport    ( void * viewport );
FGLAPI fgl_depth_range ( const float near, const float far );	


// ----------------------------------------------------------------------
// Raster Engine Register-level API
// ----------------------------------------------------------------------
FGLAPI fgl_pixel_sampos ( const fglenum pos );
FGLAPI fgl_disable_doffset ( void );
FGLAPI fgl_doffset      ( const float factor, const float units);
FGLAPI fgl_doffset_r    ( const float rval );
FGLAPI fgl_disable_cullface ( void );
FGLAPI fgl_cull_face    ( const bool clockwise, const fglenum mode );
FGLAPI fgl_clip_plan    ( const uint32 left, const uint32 right, const uint32 bottom, const uint32 top );
FGLAPI fgl_lodctrl      ( const uint32 lod );
FGLAPI fgl_point_width  ( const float width );
FGLAPI fgl_psize_minmax ( const float min, const float max );
FGLAPI fgl_replace_coord( const uint32 coord );
FGLAPI fgl_line_width   ( const float width );


// ----------------------------------------------------------------------
// Texture Units Register-level API
// ----------------------------------------------------------------------
FGLAPI fgl_texture       ( const uint32 unit, void * texinfo );
FGLAPI fgl_mipmap_level  ( const uint32 uint, const uint32 min, const uint32 max); 
FGLAPI fgl_ckey          ( const uint32 unit, const uint32 red, const uint32 green, const uint32 blue );
FGLAPI fgl_ckey_yuv      ( const uint32 u /*cb*/, const uint32 v/*cr*/ );
FGLAPI fgl_ckey_mask     ( const uint32 mask );
FGLAPI fgl_load_palettet ( const void * palette, const fglenum format, const uint32 size );
FGLAPI fgl_vtxtex        ( const uint32 unit, void * vtxtex );


// ----------------------------------------------------------------------
// Per-fragment Unit Register-level API
// ----------------------------------------------------------------------
FGLAPI fgl_scissor         ( const int32 x, const int32 y, const int32 width, const int32 height );
FGLAPI fgl_disable_scissor ( void );
FGLAPI fgl_alpha           ( const fglenum func, const uint32 ref );
FGLAPI fgl_disable_alpha   ( void );
FGLAPI fgl_stencil         ( void * stencilinfo );
FGLAPI fgl_disable_stencil ( void );
FGLAPI fgl_depth           ( const fglenum func);
FGLAPI fgl_disable_depth   ( void );
FGLAPI fgl_blend           ( void * blendinfo );
FGLAPI fgl_disable_blend   ( void );                     
FGLAPI fgl_blend_color     ( const uint32 r, const uint32 g, const uint32 b, const uint32 a );
FGLAPI fgl_logicop         ( const fglenum opcode );
FGLAPI fgl_disable_logicop ( void );
FGLAPI fgl_color_mask      ( const bool r, const bool g, const bool b, const bool a );
FGLAPI fgl_stencil_depth_mask ( const uint32 fsmask, const uint32 bsmask, const bool dmask );
FGLAPI fgl_colorbuf        ( void * fbinfo );
FGLAPI fgl_depthbuf_base   ( const uint32 base );
FGLAPI fgl_colorbuf_base   ( const uint32 base );
FGLAPI fgl_framebuf_stride ( const uint32 stride );


#if defined __cplusplus
}
#endif

#endif	/* __FIMG_H__ */

