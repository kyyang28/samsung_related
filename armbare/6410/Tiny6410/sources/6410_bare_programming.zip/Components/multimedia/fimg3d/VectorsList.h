/*
* FPGA Test Vector for FIMG-3DSE ver 1.x Developed by Graphics Team
*
* Copyright 2007 by Mobie neXt Generation Technology, Samsung Electronics, Inc.,
* San#24, Nongseo-Dong, Giheung-Gu, Yongin, Korea. All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung.
*/
/**
* @file test_list.h
* @brief
*
* @author Thomas, Kim (cheolkyoo.kim@samsung.com)
* @version 1.2
*/

#ifndef _VECTORS_LIST_H_
#define _VECTORS_LIST_H_

#ifdef FIMG_VERA_SIM
// HI
   #include "BurstTransfer.cpp"
	#include "VtxCache.cpp"
	#include "VBMixedIdx.cpp"
	#include "VBAutoIncre.cpp"
	#include "VBIdxTrans.cpp"
	#include "VtxDataType.cpp"

// VS
    #include "Lighting.cpp"
    #include "Transform.cpp"
    #include "DisplaceVtx.cpp"
// PE
    #include "Tri.cpp"
    #include "TriFan.cpp"
    #include "TriStrip.cpp"
    #include "ClipTri.cpp"
    #include "ClipTriFan0.cpp"
    #include "ClipTriFan1.cpp"
    #include "ClipTriStrip.cpp"
    #include "ClipTriStrip_onlyPosition.cpp"
    #include "NWTriFan0.cpp"
    #include "NWTriFan1.cpp"
    #include "NWTriStrip.cpp"
    #include "Viewport.cpp"
	#include "PositionRandom.cpp"
    #include "CullClippedStrip.cpp"
    #include "CullFlatShadedStrip.cpp"
    #include "allcaseTri.cpp"
    #include "allcaseTriFan.cpp"
    #include "allcaseTriStrip.cpp"
    #include "allcaseTri_Flat.cpp"
    #include "allcaseTriFan_Flat.cpp"
    #include "allcaseTriStrip_Flat.cpp"
// RA
    #include "SmallTri.cpp"
    #include "SamplingPos.cpp"
    #include "DepthOffset.cpp"
    #include "BackfaceCull.cpp"
    #include "XYClipping.cpp"
    #include "Line.cpp"
    #include "LineLoop.cpp"
    #include "LineStrip.cpp"
    #include "Point.cpp"
    #include "PointSprite.cpp"
    #include "VaryingVariables.cpp"
// PS
    #include "ProgramCtrl.cpp"
    #include "BumpMap.cpp"
    #include "Fog.cpp"
    #include "MultiTex.cpp"
    #include "Imaging.cpp"
// PF
    #include "Scissor.cpp"
    #include "Alpha.cpp"
    #include "Stencil.cpp"
    #include "Depth.cpp"
    #include "Blend.cpp"
    #include "LogicOp.cpp"
    #include "ColorWriteMask.cpp"
    #include "DepthWriteMask.cpp"
    #include "FrameBufFmt.cpp"
    #include "StencilCompFunc.cpp"
// TU
    #include "TexFmt2D.cpp"
    #include "TexFmt3D8888.cpp"
    #include "TexCubemap.cpp"
    #include "MipmapFmt8888.cpp"
    #include "TexUVMode.cpp"
    #include "TexLOD.cpp"
    #include "TexFmts3tc.cpp"
// MODEL
    #include "Pawn.cpp"
    #include "Teapot.cpp"
    #include "Venus.cpp"
    #include "Bunny.cpp"
    #include "Cow.cpp"
    #include "Dragon.cpp"
 
int FrameBufferCtrl(void);
int Texture2DFormat(void);
#else // FIMG_VERA_SIM

//Function declarations
int SFRegRwTest(void);

// HI
int BurstTransfer(void); 
int VtxCache(void); 
int VBMixedIdx(void); 
int VBAutoIncre(void); 
int VBIdxTrans(void); 
int VtxDataType(void); 
// VS
int Lighting(void);
int Transform(void);
int DisplaceVtx(void);
// PE
int Tri(void);
int TriFan(void);
int TriStrip(void);
int ClipTri(void);
int ClipTriFan0(void);
int ClipTriFan1(void);
int ClipTriStrip(void);
int ClipTriStrip_onlyPosition(void);
int NWTriFan0(void);
int NWTriFan1(void);
int NWTriStrip(void);
int Viewport(void);
int PositionRandom(void);
int CullClippedStrip(void);
int CullFlatShadedStrip(void);
int allcaseTri(void);
int allcaseTriFan(void);
int allcaseTriStrip(void);
int allcaseTri_Flat(void);
int allcaseTriFan_Flat(void);
int allcaseTriStrip_Flat(void);
// RA
int Point(void);
int Line(void);
int LineLoop(void);
int LineStrip(void);
int PointSprite(void);
int SmallTri(void);
int SamplingPos(void);
int DepthOffset(void);
int BackfaceCull(void);
int XYClipping(void);
int VaryingVariables(void);
// PS
int ProgramCtrl(void);
int BumpMap(void);
int Fog(void);
int MultiTex(void);
int Imaging(void);
// TU
int Texture2DFormat(void);
int TexFmt2D(FGL_TexelFormat format, unsigned int offset);
int MipmapFmt8888(void); 
int TexCubemap(void);
int TexFmt3D8888(void);
int TexUVMode(void);
int TexLOD(void);
int TexFmts3tc(void);
// PF
int Scissor(void);
int Alpha(void);
int Stencil(void);
int StencilCompFunc(void);
int Depth(void);
int Blend(void);
int LogicOp(void);
int ColorWriteMask(void);
int DepthWriteMask(void);
int FrameBufferCtrl(void);
int FrameBufFmt(FGL_PixelFormat fmt);
// MODEL
int Pawn(void);
int Teapot(void);
int Venus(void);
int Bunny(void);
int Cow(void);
int Dragon(void);


#endif // FIMG_VERA_SIM

const TestVectorList Vectors[] =
{
#ifndef FIMG_VERA_SIM
    {   1,	FIMG_HOST_INTERFACE, 	"V150_HI_BD_0001", 	BurstTransfer,	"BurstTransfer",	0,				            "Bishop.dat"},
    {   2,	FIMG_HOST_INTERFACE, 	"V150_HI_BD_0002", 	VtxCache,     	"VtxCache",     	0,							0},
    {   3,	FIMG_HOST_INTERFACE, 	"V150_HI_BD_0003", 	VBMixedIdx,   	"VBMixedIdx",   	0,							0},
    {   4,	FIMG_HOST_INTERFACE, 	"V150_HI_BD_0004", 	VBAutoIncre,  	"VBAutoIncre",  	0,							0},
    {   5,	FIMG_HOST_INTERFACE, 	"V150_HI_BD_0005", 	VBIdxTrans,   	"VBIdxTrans",   	0,							0},
    {   6,	FIMG_HOST_INTERFACE, 	"V150_HI_BD_0006", 	VtxDataType,  	"VtxDataType",  	0,							0},
#endif
    {   7,	FIMG_VERTEX_SHADER, 	"V150_VS_BD_0001", 	Lighting,     	"Lighting",     	0,                      	0},
    {   8,	FIMG_VERTEX_SHADER, 	"V150_VS_BD_0002", 	Transform,    	"Transform",    	"TranformTexFmt1555.in",	0},
    {   9,	FIMG_VERTEX_SHADER, 	"V150_VS_BD_0003", 	DisplaceVtx,  	"DisplaceVtx",  	"DisplaceVtxFmt8888.in",	"Flag.dat"},
    {  10,	FIMG_PRIMITIVE_ENGINE, 	"V150_PE_BD_0001", 	Tri,          	"Tri",              0,							0},
    {  11,	FIMG_PRIMITIVE_ENGINE, 	"V150_PE_BD_0002", 	TriFan,       	"TriFan",           0,							0},
    {  12,	FIMG_PRIMITIVE_ENGINE, 	"V150_PE_BD_0003", 	TriStrip,     	"TriStrip",         0,							0},
    {  13,	FIMG_PRIMITIVE_ENGINE, 	"V150_PE_BD_0004", 	ClipTri,      	"ClipTri",          0,							0},
    {  14,	FIMG_PRIMITIVE_ENGINE, 	"V150_PE_BD_0005", 	ClipTriFan0,  	"ClipTriFan0",      0,							0},
    {  15,	FIMG_PRIMITIVE_ENGINE, 	"V150_PE_BD_0006", 	ClipTriFan1,  	"ClipTriFan1",      0,							0},
    {  16,	FIMG_PRIMITIVE_ENGINE, 	"V150_PE_BD_0007", 	ClipTriStrip, 	"ClipTriStrip",     0,							0},
    {  17,	FIMG_PRIMITIVE_ENGINE, 	"V150_PE_BD_0008", 	NWTriFan0,    	"NWTriFan0",        0,							0},
    {  18,	FIMG_PRIMITIVE_ENGINE, 	"V150_PE_BD_0009", 	NWTriFan1,    	"NWTriFan1",        0,							0},
    {  19,	FIMG_PRIMITIVE_ENGINE, 	"V150_PE_BD_0010", 	NWTriStrip,   	"NWTriStrip",       0,							0},
    /*{  20,	FIMG_PRIMITIVE_ENGINE, 	"V150_PE_BD_0011", 	Viewport,     	"Viewport",         0,							0},*/
	{  21,	FIMG_PRIMITIVE_ENGINE, 	"V150_PE_BD_0012", 	PositionRandom,	     "PositionRandom",       0,					0},
    {  22,	FIMG_PRIMITIVE_ENGINE, 	"V150_PE_BD_0013", 	CullFlatShadedStrip, "CullFlatStrip",        0,     			0},
    {  23,	FIMG_PRIMITIVE_ENGINE, 	"V150_PE_BD_0014", 	CullClippedStrip,    "CullClippedStrip",     0,				    0},
    {  24,	FIMG_PRIMITIVE_ENGINE, 	"V150_PE_BD_0015", 	ClipTriStrip_onlyPosition, 	"ClipTriStrip_onlyPosition", 0,		0},
    /*{  25,	FIMG_PRIMITIVE_ENGINE, 	"V150_PE_BD_0016", 	allcaseTri, 	      "allcaseTri",          0,					0},
    {  26,	FIMG_PRIMITIVE_ENGINE, 	"V150_PE_BD_0017", 	allcaseTriFan, 	      "allcaseTriFan",       0,					0},
    {  27,	FIMG_PRIMITIVE_ENGINE, 	"V150_PE_BD_0018", 	allcaseTriStrip, 	  "allcaseTriStrip",     0,					0},
    {  28,	FIMG_PRIMITIVE_ENGINE, 	"V150_PE_BD_0019", 	allcaseTri_Flat, 	  "allcaseTri_Flat",     0,					0},
    {  29,	FIMG_PRIMITIVE_ENGINE, 	"V150_PE_BD_0020", 	allcaseTriFan_Flat,   "allcaseTriFan_Flat",  0,					0},
    {  30,	FIMG_PRIMITIVE_ENGINE, 	"V150_PE_BD_0021", 	allcaseTriStrip_Flat, "allcaseTriStrip_Flat",0,					0},*/
    {  31,	FIMG_RASTER_ENGINE,		"V150_RA_BD_0001", 	SmallTri,     	"SmallTri",         0,          				0},
    {  32,	FIMG_RASTER_ENGINE,		"V150_RA_BD_0002", 	SamplingPos,  	"SamplingPos",      0,          				0},
    {  33,	FIMG_RASTER_ENGINE,		"V150_RA_BD_0003", 	DepthOffset, 	"DepthOffset",      0,          				"Sphere.dat"},
    {  34,	FIMG_RASTER_ENGINE,		"V150_RA_BD_0004", 	BackfaceCull, 	"BackfaceCull",     0,          				0},
    {  35,	FIMG_RASTER_ENGINE,		"V150_RA_BD_0005", 	XYClipping,   	"XYClipping",       0,          				0},
    {  36,	FIMG_RASTER_ENGINE,		"V150_RA_BD_0006", 	Line,         	"Line",             0,          				0},
    {  37,	FIMG_RASTER_ENGINE,		"V150_RA_BD_0007", 	LineLoop,     	"LineLoop",         0,          				0},
    {  38,	FIMG_RASTER_ENGINE,		"V150_RA_BD_0008", 	LineStrip,    	"LineStrip",        0,          				0},
    {  39,	FIMG_RASTER_ENGINE,		"V150_RA_BD_0009", 	Point,        	"Point",            0,          				0},
    {  40,	FIMG_RASTER_ENGINE,		"V150_RA_BD_0010", 	PointSprite,  	"PointSprite",      "flash.dds",			    "PointSprite.dat"},
    /*{  41,	FIMG_RASTER_ENGINE,		"V150_RA_BD_0011", 	VaryingVariables, "VaryingVariables",      0,			        0},*/
    {  42,	FIMG_FRAGMENT_SHADER,	"V150_FS_BD_0001", 	ProgramCtrl,  	"ProgramCtrl",      "ProgramCtrl.in",    		0},
    {  43,	FIMG_FRAGMENT_SHADER,	"V150_FS_BD_0002", 	BumpMap,      	"BumpMap",          "BumpMap.in",        		0},
    {  44,	FIMG_FRAGMENT_SHADER,	"V150_FS_BD_0003", 	Fog,          	"Fog",              "Earth.dds",         		"Fog.dat"},
    {  45,	FIMG_FRAGMENT_SHADER,	"V150_FS_BD_0004", 	MultiTex,     	"MultiTex",         "Earth.tex",       		    "Earth.dat"},
    {  46,	FIMG_FRAGMENT_SHADER,	"V150_FS_BD_0005", 	Imaging,      	"Imaging",          "ImagingFmt8888.in", 		0},
    {  47,	FIMG_TEXTURE_UNIT,		0, 	                Texture2DFormat,"Texture2DFormat",  "TexFmt2D.in",              0},
    {  48,	FIMG_TEXTURE_UNIT,		"V150_TU_BD_0002", 	TexFmt3D8888,   "TexFmt3D8888",     "TexFmt3D8888.in",          0},
    {  49,	FIMG_TEXTURE_UNIT,		"V150_TU_BD_0003", 	TexCubemap,     "TexCubemap",       "TexCubemapARGB888.raw",    "Cubemap.dat"},
    {  50,	FIMG_TEXTURE_UNIT,		"V150_TU_BD_0004", 	MipmapFmt8888,  "MipmapFmt8888",    "MipmapFmt8888.in",         0},
    {  51,	FIMG_TEXTURE_UNIT,		"V150_TU_BD_0005", 	TexUVMode,      "TexUVMode",        "TexUVMode.in",             0},
    {  52,	FIMG_TEXTURE_UNIT,		"V150_TU_BD_0006", 	TexLOD,         "TexLOD",           "TexLOD.dds",               0},
    {  53,	FIMG_TEXTURE_UNIT,		"V150_TU_BD_0007", 	TexFmts3tc,     "TexFmts3tc",       "TexFmts3tc.in",            0},
    {  54,	FIMG_PERFRAGMENT_UNIT, 	"V150_PF_BD_0001", 	Scissor,        "Scissor",          0,							0},
    {  55,	FIMG_PERFRAGMENT_UNIT, 	"V150_PF_BD_0002", 	Alpha,          "Alpha",            0,							0},
    {  56,	FIMG_PERFRAGMENT_UNIT, 	"V150_PF_BD_0003", 	Stencil,        "Stencil",          0,							0},
    {  57,	FIMG_PERFRAGMENT_UNIT, 	"V150_PF_BD_0004", 	Depth,          "Depth",            0,							0},
    {  58,	FIMG_PERFRAGMENT_UNIT, 	"V150_PF_BD_0005", 	Blend,          "Blend",            0,							0},
    {  59,	FIMG_PERFRAGMENT_UNIT, 	"V150_PF_BD_0006", 	LogicOp,        "LogicOp",          0,							0},
    {  60,	FIMG_PERFRAGMENT_UNIT, 	"V150_PF_BD_0007", 	ColorWriteMask, "ColorWriteMask",   0,							0},
    {  61,	FIMG_PERFRAGMENT_UNIT, 	"V150_PF_BD_0008", 	DepthWriteMask, "DepthWriteMask",   0,							0},
    /*{  62,	FIMG_PERFRAGMENT_UNIT, 	0, 	                FrameBufferCtrl,"FrameBufFmt",      0,							0},*/
    {  63,	FIMG_PERFRAGMENT_UNIT, 	"V150_PF_BD_0010", 	StencilCompFunc,"StencilCompFunc",  0,							0},
    {  64,	FIMG_ALL_PIPELINE, 		"V150_MD_BD_0001", 	Pawn,           "Pawn",				0, 				            "Pawn.dat"	},
    {  65,	FIMG_ALL_PIPELINE, 		"V150_MD_BD_0002", 	Teapot,         "Teapot",   		0, 				            "Teapot.dat"},
    {  66,	FIMG_ALL_PIPELINE, 		"V150_MD_BD_0003", 	Venus,          "Venus",    		0, 				            "Venus.dat"	},
    {  67,	FIMG_ALL_PIPELINE, 		"V150_MD_BD_0004", 	Bunny,          "Bunny", 			0, 				            "Bunny.dat"	},
    {  68,	FIMG_ALL_PIPELINE, 		"V150_MD_BD_0005", 	Cow,            "Cow", 		    	0, 				            "Cow.dat"	},
    {  69,	FIMG_ALL_PIPELINE, 		"V150_MD_BD_0006", 	Dragon,         "Dragon",			0, 				            "Dragon.dat"},
    {   0,	FIMG_NONE_BLOCK, 		0,                  0, 				0, 					0, 							0}
};

#endif /* _VECTORS_LIST_H_ */
